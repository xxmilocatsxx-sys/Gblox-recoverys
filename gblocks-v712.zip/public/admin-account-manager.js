(() => {
  const $=id=>document.getElementById(id);
  const esc=s=>String(s??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;");
  const status=(text,good=false)=>{const el=$("adminPanelAccountsStatus");if(el){el.textContent=text;el.className="status "+(good?"ok":"danger")}};
  async function request(url,opts={}){const r=await fetch(url,{credentials:"same-origin",cache:"no-store",...opts});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||("Request failed (HTTP "+r.status+")."));return d}
  async function load(){
    const box=$("adminPanelAccountsList");if(!box)return;
    try{
      const d=await request("/api/admin/admin-accounts");
      const accounts=Array.isArray(d.accounts)?d.accounts:[];
      box.innerHTML=accounts.length?'<table><thead><tr><th>Administrator</th><th>Created</th><th>Status</th><th>Action</th></tr></thead><tbody>'+accounts.map(a=>'<tr><td><strong>'+esc(a.username)+'</strong>'+(a.is_current?' <span class="pill">Current account</span>':'')+'<div class="muted small">'+esc(a.admin_id)+'</div></td><td>'+esc(a.created_at?new Date(a.created_at).toLocaleString():"—")+'</td><td>'+esc(a.terminated?"Terminated":a.banned?"Banned":"Active")+'</td><td>'+(a.is_current?'<span class="muted small">Sign in as another account to remove this one.</span>':'<button class="red" type="button" data-delete-admin="'+esc(a.admin_id)+'" data-admin-name="'+esc(a.username)+'">Delete Account</button>')+'</td></tr>').join("")+'</tbody></table>':'<div class="muted">No administrator-panel accounts found.</div>';
      status("Loaded "+accounts.length+" administrator-panel account(s).",true);
    }catch(e){box.innerHTML='<div class="danger">Unable to load administrator accounts: '+esc(e.message)+'</div>';status(e.message||"Could not load administrator accounts.");}
  }
  async function signOut(event){
    if(event){event.preventDefault();event.stopPropagation();}
    const btn=$("adminSignOut");if(btn)btn.disabled=true;
    status("Signing out…",true);
    try{
      const result=await request("/api/admin/sign-out",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});
      if(!result.signedOut)throw new Error("The server did not confirm sign-out.");
      try{sessionStorage.clear();}catch{}
      // Immediately switch the visible UI to the login state; don't rely on a soft refresh.
      const top=$("topStatus");if(top){top.textContent="Signed out. Sign in again to continue.";top.className="status danger";}
      const controls=$("adminControls"),login=$("adminLogin");
      if(controls)controls.style.display="none";
      if(login)login.style.display="block";
      const user=$("adminLoginUsername"),pass=$("adminLoginPassword");
      if(user)user.value="";if(pass)pass.value="";
      if(btn){btn.textContent="Signed Out";btn.disabled=true;}
      // Replace the URL without reloading into a stale authenticated page.
      history.replaceState(null,"","/admin.html?logged_out="+Date.now());
    }catch(e){status("Sign out failed: "+e.message);if(btn)btn.disabled=false;}
  }
  document.addEventListener("click",async e=>{
    const btn=e.target.closest("[data-delete-admin]");
    if(!btn)return;
    const id=btn.getAttribute("data-delete-admin"),name=btn.getAttribute("data-admin-name")||"this account";
    if(!confirm("Delete the separate administrator-panel account "+name+"? This cannot be undone. Its active sessions will be revoked."))return;
    const typed=prompt('Type DELETE ADMIN ACCOUNT to confirm deleting "'+name+'".');
    if(typed!=="DELETE ADMIN ACCOUNT"){status("Deletion cancelled: confirmation text did not match.");return;}
    btn.disabled=true;
    try{const d=await request("/api/admin/admin-accounts",{method:"DELETE",headers:{"Content-Type":"application/json"},body:JSON.stringify({admin_id:id,confirmation:typed})});status(d.message||("Deleted "+name+"."),true);await load();}
    catch(err){status(err.message||"Could not delete account.");btn.disabled=false;}
  });
  $("refreshAdminPanelAccounts")?.addEventListener("click",load);
  $("adminSignOut")?.addEventListener("click",event=>{event.preventDefault();event.stopPropagation();if(confirm("Sign out of the GBlocks Administrator Panel?"))void signOut(event)});
  window.loadAdminPanelAccounts=load;
  document.addEventListener("DOMContentLoaded",load);
  void load();
})();