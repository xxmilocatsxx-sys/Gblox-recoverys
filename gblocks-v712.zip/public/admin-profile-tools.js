async function loadGblocksAdminTools(box,targetId,isUnavailable,targetUsername){
  try{
    const r=await fetch("/api/admin/profile-actions",{credentials:"include",cache:"no-store"});
    if(!r.ok)return;
    const d=await r.json();
    if(!d.isAdmin)return;
    const wrap=document.createElement("div");
    wrap.className="admin-tools";
    wrap.style.flexWrap="wrap";
    wrap.style.gap="8px";
    wrap.innerHTML='<button class="admin-more" type="button" aria-label="Admin actions">•••</button><button class="admin-more moderation-checker-open" type="button" aria-label="Open moderation checker" style="width:auto;padding:0 12px;font-size:13px">🛡️ Moderation Checker</button><div class="admin-menu"></div><div class="moderation-checker-panel" hidden style="flex-basis:100%;padding:14px;border:1px solid var(--border);border-radius:12px;background:var(--panel,#111);text-align:left"></div>';
    const menu=wrap.querySelector(".admin-menu");
    const checkerButton=wrap.querySelector(".moderation-checker-open");
    const checkerPanel=wrap.querySelector(".moderation-checker-panel");
    const safe=v=>String(v??"").replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));
    checkerButton.onclick=async()=>{
      checkerPanel.hidden=false;
      checkerPanel.innerHTML="<b>Moderation Checker</b><p>Loading recorded moderation and activity…</p>";
      try{
        const query=targetId?"user_id="+encodeURIComponent(targetId):"username="+encodeURIComponent(targetUsername||"");
        const response=await fetch("/api/admin/moderation-checker?"+query,{credentials:"include",cache:"no-store"});
        const data=await response.json();
        if(!response.ok)throw new Error(data.error||"Could not load moderation records.");
        const p=data.profile||{};
        const activity=Array.isArray(data.activity)?data.activity:[];
        const bios=Array.isArray(data.moderation_history)?data.moderation_history:[];
        const names=Array.isArray(data.username_history)?data.username_history:[];
        checkerPanel.innerHTML="<h3>🛡️ Moderation Checker</h3><p><b>"+safe(p.display_name||p.username)+"</b> (@"+safe(p.username)+")<br>User ID: <code>"+safe(p.user_id)+"</code><br>Bio: "+safe(p.bio||"(empty)")+"<br>Status: "+safe(p.terminated?"Terminated":p.banned?"Banned":"Active")+" · Bio review: "+safe(p.bio_moderation_status||"not_reviewed")+"</p><h4>Recorded Activity / Audit Events ("+activity.length+")</h4>"+(activity.length?"<div style='overflow:auto'><table><tr><th>Action</th><th>Actor</th><th>Reason</th><th>Time</th></tr>"+activity.map(x=>"<tr><td>"+safe(x.action)+"</td><td>"+safe(x.actor_username||"System")+"</td><td style='white-space:normal'>"+safe(x.reason||"")+"</td><td>"+safe(x.created_at||"")+"</td></tr>").join("")+"</table></div>":"<p>No recorded audit events.</p>")+"<h4>Bio Moderation History ("+bios.length+")</h4>"+(bios.length?"<div style='overflow:auto'><table><tr><th>Action</th><th>Original Bio</th><th>Result</th><th>Moderator</th><th>Reason / Time</th></tr>"+bios.map(x=>"<tr><td>"+safe(x.action)+"</td><td style='white-space:normal'>"+safe(x.original_bio||"")+"</td><td style='white-space:normal'>"+safe(x.resulting_bio||"")+"</td><td>"+safe(x.actor_admin_username||"System")+"</td><td style='white-space:normal'>"+safe(x.reason||"")+"<br>"+safe(x.created_at||"")+"</td></tr>").join("")+"</table></div>":"<p>No bio moderation history.</p>")+"<h4>Previous Usernames ("+names.length+")</h4>"+(names.length?"<p>"+names.map(x=>safe(x.username)+" ("+safe(x.changed_at||"unknown date")+")").join("<br>")+"</p>":"<p>No previous usernames recorded.</p>")+"<p class='muted'>"+safe(data.activity_note||"Only recorded events are shown; this is not a full page-view history.")+"</p>";
      }catch(error){checkerPanel.innerHTML="<b>Moderation Checker</b><p>"+safe(error.message||"Could not load records.")+"</p>";}
    };
    const add=(label,action,cls)=>{const b=document.createElement("button");b.type="button";b.textContent=label;b.className=cls||"";b.onclick=()=>gblocksAdminAction(action,targetId,menu,targetUsername);menu.appendChild(b);};
    if(isUnavailable)add("Unban account","unban");
    else{
      add("Ban account","ban","danger");
      add("Terminate account - Account Deleted","terminate","danger");
      add("Time ban account - Ban a user for time","timeban","time");
    }
    box.parentNode.insertBefore(wrap,box);
    wrap.querySelector(".admin-more").onclick=e=>{e.stopPropagation();menu.classList.toggle("open");};
    document.addEventListener("click",e=>{if(!wrap.contains(e.target))menu.classList.remove("open");});
  }catch(e){}
}
async function gblocksAdminAction(action,targetId,menu,targetUsername){
  menu.classList.remove("open");
  targetId=String(targetId||"").trim();
  targetUsername=String(targetUsername||"").trim();
  if(!targetId&&!targetUsername){alert("Target player account could not be identified. Refresh the profile and try again.");return;}
  let note="",moderator_note="",ends_at="";
  if(action==="ban"||action==="terminate"){
    note=prompt(action==="terminate"?"Reason for termination:":"Reason for ban:","");
    if(note===null)return;
    moderator_note=prompt("Moderator note (Discord moderation log only):","");
    if(moderator_note===null)return;
    if(!moderator_note.trim()){alert("A moderator note is required.");return;}
  }
  if(action==="timeban"){
    const value=prompt("Enter the ban end date and time. The ban starts immediately. Example: 2026-09-23 18:00","");
    if(value===null)return;
    const end=new Date(value);
    if(!Number.isFinite(end.getTime())||end.getTime()<=Date.now()){alert("Please enter a future end time.");return;}
    ends_at=end.toISOString();
    moderator_note=prompt("Moderator note (Discord moderation log only):","");
    if(moderator_note===null)return;
    if(!moderator_note.trim()){alert("A moderator note is required.");return;}
  }
  try{
    const r=await fetch("/api/admin/profile-actions",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({target_user_id:targetId,username:targetUsername,action,note,moderator_note,ends_at})});
    const d=await r.json().catch(()=>({}));
    if(!r.ok)throw new Error(d.error||"Admin action failed.");
    alert(d.message||"Admin action completed.");
    location.reload();
  }catch(e){alert(e.message||"Admin action failed.");}
}