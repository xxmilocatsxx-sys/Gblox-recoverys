(function(){
 "use strict";
 var gameId=new URLSearchParams(location.search).get("id");
 if(!gameId||!document.getElementById("world"))return;
 var elapsed=0, timer=null, lastMessage="";
 function reward(action){
  fetch("/api/gifts/reward",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:action,game_id:gameId,minute:elapsed})})
   .then(function(r){return r.json().then(function(d){return {ok:r.ok,data:d}})})
   .then(function(x){if(x.ok&&x.data.claimed){var box=document.getElementById("message");if(box)box.textContent=x.data.message+" Gift balance: "+x.data.balance;lastMessage=x.data.message;}})
   .catch(function(){});
 }
 function start(){reward("daily");if(timer)clearInterval(timer);timer=setInterval(function(){if(document.visibilityState!=="visible")return;elapsed++;reward("play_minute");},60000);}
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",start,{once:true});else start();
 addEventListener("pagehide",function(){if(timer)clearInterval(timer);});
})();