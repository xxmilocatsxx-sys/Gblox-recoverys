(()=> {
const $=id=>document.getElementById(id);
if(!$("massModerationCard")) return;
let accounts=[], selected=new Set();
const endpoint="/api/admin/moderation-tools";
const say=(id,t,ok=false)=>{const e=$(id);if(e){e.textContent=t;e.className="status "+(ok?"ok":"danger");}};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function call(body,method="POST"){
 const r=await fetch(endpoint,{method,credentials:"same-origin",cache:"no-store",headers:{"Content-Type":"application/json"},...(body?{body:JSON.stringify(body)}:{})});
 const d=await r.json().catch(()=>({}));
 if(!r.ok)throw Error(d.error||"Request failed.");
 return d;
}
function render(){
 const term=$("massPlayerSearch").value.toLowerCase().trim();
 const list=accounts.filter(a=>(a.username+" "+a.display_name+" "+a.user_id).toLowerCase().includes(term));
 $("massPlayerList").innerHTML=list.length?'<table><tr><th>Select</th><th>Username</th><th>Status</th></tr>'+list.map(a=>'<tr><td><input type="checkbox" data-id="'+esc(a.user_id)+'" '+(selected.has(String(a.user_id))?"checked":"")+' style="width:auto"></td><td>@'+esc(a.username)+'</td><td>'+esc(a.moderation_status||"active")+'</td></tr>').join("")+'</table>':'<div class="muted">No matching accounts.</div>';
 $("linkedPrimary").innerHTML='<option value="">Select primary account…</option>'+accounts.map(a=>'<option value="'+esc(a.user_id)+'">@'+esc(a.username)+'</option>').join("");
 $("massPlayerList").querySelectorAll("[data-id]").forEach(e=>e.onchange=()=>{if(e.checked)selected.add(String(e.dataset.id));else selected.delete(String(e.dataset.id));say("massModerationStatus",selected.size+" account(s) selected.",true);});
}
async function loadPlayers(){try{const d=await call(null,"GET");accounts=d.accounts||[];render();say("massModerationStatus",accounts.length+" accounts loaded.",true);}catch(e){say("massModerationStatus",e.message);}}
$("massRefreshPlayers").onclick=loadPlayers;
$("massPlayerSearch").oninput=render;
$("massSelectAll").onclick=()=>{const t=$("massPlayerSearch").value.toLowerCase().trim();accounts.filter(a=>(a.username+" "+a.display_name+" "+a.user_id).toLowerCase().includes(t)).forEach(a=>selected.add(String(a.user_id)));render();say("massModerationStatus",selected.size+" selected.",true);};
$("massClearSelection").onclick=()=>{selected.clear();render();say("massModerationStatus","Selection cleared.",true);};
const unbanButton=$("massUnbanButton");
if(unbanButton)unbanButton.onclick=async()=>{
 const ids=[...selected];
 if(!ids.length)return say("massModerationStatus","Select the ClaudeBot test accounts you want to restore.");
 const chosen=accounts.filter(a=>ids.includes(String(a.user_id)));
 const invalid=chosen.filter(a=>!/^ClaudeBot(?:_\d+)?$/i.test(String(a.username||"")));
 if(invalid.length)return say("massModerationStatus","For safety, bulk restore only accepts generated ClaudeBot accounts. Remove: "+invalid.map(a=>"@"+a.username).join(", "));
 if(!confirm("Restore "+ids.length+" selected ClaudeBot test accounts to Active? This will clear their ban/termination status and create audit + Discord UNBAN logs."))return;
 try{
  const allResults=[],batchSize=10;
  for(let start=0;start<ids.length;start+=batchSize){
   const d=await call({action:"mass_unban",user_ids:ids.slice(start,start+batchSize)});
   allResults.push(...(d.results||[]));
   const failures=allResults.filter(x=>!x.ok);
   say("massModerationStatus","Restore progress: "+Math.min(start+batchSize,ids.length)+"/"+ids.length+". Restored: "+allResults.filter(x=>x.ok).length+". Failures: "+failures.length,failures.length===0);
  }
  const failures=allResults.filter(x=>!x.ok);
  say("massModerationStatus","Restore finished: "+allResults.filter(x=>x.ok).length+" restored; "+failures.length+" failed. Discord logs sent: "+(allResults.length? "check server result":"0")+". "+(failures.length?failures.map(x=>"@"+(x.username||x.user_id)+": "+(x.error||"failed")).join("; "):""),failures.length===0);
  selected.clear();await loadPlayers();
 }catch(e){say("massModerationStatus","Restore failed: "+e.message);}
};
$("massBanButton").onclick=async()=>{
 const ids=[...selected],reason=$("massBanReason").value.trim(),days=Number($("massBanDuration").value);
 if(!ids.length)return say("massModerationStatus","Select at least one account.");
 if(!reason)return say("massModerationStatus","A reason is required.");
 if(!confirm("Confirm ban for "+ids.length+" selected accounts? Reason: "+reason+" Duration: "+(days?days+" days":"permanent")+"."))return;
 try{
  const batchSize=10, allResults=[];let totalRequested=0;
  for(let start=0;start<ids.length;start+=batchSize){
   const batch=ids.slice(start,start+batchSize);
   const d=await call({action:"mass_ban",user_ids:batch,reason,duration_days:days});
   allResults.push(...(d.results||[]));totalRequested+=d.requested||batch.length;
   const successes=allResults.filter(x=>x.ok).length,failures=allResults.filter(x=>!x.ok);
   say("massModerationStatus","Progress: "+Math.min(start+batch.length,ids.length)+"/"+ids.length+" accounts. Successes: "+successes+". Failures: "+failures.length+(failures.length?" — "+failures.map(x=>"@"+(x.username||x.user_id)+": "+(x.error||"failed")).join("; "):""),failures.length===0);
   if(start+batchSize<ids.length) await new Promise(resolve=>setTimeout(resolve,2800));
  }
  const failures=allResults.filter(x=>!x.ok),successes=allResults.filter(x=>x.ok);
  say("massModerationStatus","Finished: "+allResults.length+" account results. Successes: "+successes.length+". Failures: "+failures.length+(failures.length?" — "+failures.map(x=>"@"+(x.username||x.user_id)+": "+(x.error||"failed")).join("; "):""),failures.length===0);
  await loadPlayers();
 }catch(e){say("massModerationStatus",e.message+" If this happened during a large batch, refresh the list and retry only accounts not already marked successful.");}
};
$("massTerminateButton").onclick=async()=>{
 const ids=[...selected],reason=$("massBanReason").value.trim();
 if(!ids.length)return say("massModerationStatus","Select at least one account to terminate.");
 if(!reason)return say("massModerationStatus","A reason is required.");
 if(!confirm("TERMINATE "+ids.length+" selected accounts? This is permanent account moderation and will revoke their sessions. Reason: "+reason))return;
 try{
  const allResults=[],batchSize=10;
  for(let start=0;start<ids.length;start+=batchSize){
   const batch=ids.slice(start,start+batchSize);
   const d=await call({action:"mass_terminate",user_ids:batch,reason});
   allResults.push(...(d.results||[]));
   const failures=allResults.filter(x=>!x.ok);
   say("massModerationStatus","Termination progress: "+Math.min(start+batch.length,ids.length)+"/"+ids.length+". Successes: "+allResults.filter(x=>x.ok).length+". Failures: "+failures.length,failures.length===0);
   if(start+batchSize<ids.length)await new Promise(resolve=>setTimeout(resolve,2800));
  }
  const failures=allResults.filter(x=>!x.ok);
  say("massModerationStatus","Termination finished: "+allResults.filter(x=>x.ok).length+" succeeded; "+failures.length+" failed."+(failures.length?" — "+failures.map(x=>"@"+(x.username||x.user_id)+": "+(x.error||"failed")).join("; "):""),failures.length===0);
  await loadPlayers();
 }catch(e){say("massModerationStatus","Termination error: "+e.message);}
};
$("terminateLinkedButton").onclick=async()=>{
 const id=$("linkedPrimary").value,reason=$("linkedTerminateReason").value.trim();
 if(!id||!reason)return say("linkedModerationStatus","Select an account and enter a reason.");
 try{const preview=await call({action:"terminate_linked",user_ids:[id],reason,preview:true});const labels=(preview.targets||[]).map(x=>"@"+x.username).join(", ");if(!confirm("Terminate these linked accounts: "+labels+"?"))return;const d=await call({action:"terminate_linked",user_ids:[id],reason});say("linkedModerationStatus","Processed "+d.processed+". Successes: "+d.successes+". Failures: "+(d.failures||[]).length+((d.failures||[]).length?" — "+d.failures.map(x=>"@"+(x.username||x.user_id)+": "+(x.error||"failed")).join("; "):""),!!d.ok);await loadPlayers();}catch(e){say("linkedModerationStatus",e.message);}
};
async function loadIps(){
 try{const d=await call({action:"ip_list"}),items=d.restrictions||[];$("ipRestrictionList").innerHTML=items.length?'<table><tr><th>IP</th><th>Reason</th><th>Expires</th><th></th></tr>'+items.map(x=>'<tr><td>'+esc(x.ip_label)+'</td><td>'+esc(x.reason)+'</td><td>'+esc(x.expires_at||"Never")+'</td><td><button data-remove="'+esc(x.ip_label)+'" class="gray">Remove</button></td></tr>').join("")+'</table>':'<div class="muted">No active IP restrictions.</div>';
 $("ipRestrictionList").querySelectorAll("[data-remove]").forEach(b=>b.onclick=async()=>{if(!confirm("Remove this IP restriction?"))return;try{await call({action:"ip_unban",ip:b.dataset.remove,reason:"Removed by administrator"});await loadIps();say("ipRestrictionStatus","IP restriction removed.",true);}catch(e){say("ipRestrictionStatus",e.message);}});
 }catch(e){say("ipRestrictionStatus",e.message);}
}
$("ipRestrictionAdd").onclick=async()=>{const ip=$("ipRestrictionAddress").value.trim(),reason=$("ipRestrictionReason").value.trim(),expiry=$("ipRestrictionExpiry").value;if(!ip||!reason)return say("ipRestrictionStatus","Enter an IP address and reason.");if(!confirm("Restrict sign-in and sign-up from "+ip+"? Shared networks may be affected."))return;try{const d=await call({action:"ip_ban",ip,reason,expires_at:expiry?new Date(expiry).toISOString():""});say("ipRestrictionStatus","Restricted. Revoked sessions: "+d.affectedSessionsRevoked+". "+d.warning,true);await loadIps();}catch(e){say("ipRestrictionStatus",e.message);}};
$("ipRestrictionRefresh").onclick=loadIps;
loadPlayers();loadIps();
})();