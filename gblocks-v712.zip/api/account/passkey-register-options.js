import { db } from "hatchable";

export const access = "public";
export const methods = ["POST"];

function b64url(bytes) {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function randomBytes(n) { const a = new Uint8Array(n); crypto.getRandomValues(a); return a; }
async function sha256(s) { return crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)); }

export default async function (req, res) {
  const body = req.body || {};
  const session = req.cookies?.groblox_session;
  if (!session) return res.status(401).json({ error: "Sign in with your GBLOCKS password first to set up a passkey." });
  const tokenHash = b64url(new Uint8Array(await sha256(session)));
  const { rows } = await db.query("SELECT p.user_id, p.username, p.display_name, p.role, p.banned FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1", [tokenHash]);
  const user = rows[0];
  if (!user) return res.status(401).json({ error: "Your session has expired. Log in again." });
  if (user.banned) return res.status(403).json({ error: "This account is banned." });

  const challenge = b64url(randomBytes(32));
  const id = b64url(randomBytes(18));
  await db.query("DELETE FROM passkey_challenges WHERE expires_at<NOW()", []);
  await db.query("INSERT INTO passkey_challenges (id,challenge,user_id,purpose,expires_at) VALUES ($1,$2,$3,'register',NOW()+INTERVAL '5 minutes')", [id, challenge, user.user_id]);

  const userId = new TextEncoder().encode(user.user_id);
  res.json({
    challenge,
    rp: { name: "GBLOCKS", id: "gblocks.hatchable.site" },
    user: { id: b64url(userId), name: user.username, displayName: user.display_name },
    pubKeyCredParams: [{ type: "public-key", alg: -7 }],
    timeout: 120000,
    authenticatorSelection: { residentKey: "required", requireResidentKey: true, userVerification: "required" },
    attestation: "none"
  });
}