import { db } from "hatchable";
export const access="public";
export const methods=["GET"];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function tokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function getCookie(req,name){
  const parsed=req.cookies?.[name];
  if(parsed!==undefined&&parsed!==null&&String(parsed)!=="")return String(parsed);
  const headers=req.headers||{};
  const raw=String(headers.cookie||headers.Cookie||"");
  for(const part of raw.split(";")){
    const i=part.indexOf("=");
    if(i<0)continue;
    if(part.slice(0,i).trim()!==name)continue;
    const value=part.slice(i+1).trim();
    try{return decodeURIComponent(value)}catch{return value}
  }
  return null;
}
export default async function(req,res){
  res.setHeader("Cache-Control","no-store, no-cache, must-revalidate, private");
  res.setHeader("Pragma","no-cache");
  // Accept either cookie name: older GBLOX pages may still carry gblocks_session.
  const raw=getCookie(req,"groblox_session")||getCookie(req,"gblocks_session");
  if(!raw)return res.json({signedIn:false,user:null});
  const th=await tokenHash(raw);
  const standardHash=btoa(String.fromCharCode(...new Uint8Array(await crypto.subtle.digest("SHA-256",enc.encode(raw)))));
  const q=await db.query("SELECT p.user_id,p.user_number,p.username,p.display_name,p.role,p.verified,p.banned,p.terminated,p.temp_ban_until,p.ban_note FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE (s.token_hash=$1 OR s.token_hash=$2) AND s.expires_at>NOW() LIMIT 1",[th,standardHash]);
  if(!q.rows[0])return res.json({signedIn:false,user:null});
  const u=q.rows[0];
  u.public_id = "GBlocks User #" + String(u.user_number);
  if(u.banned && u.temp_ban_until && new Date(u.temp_ban_until)<=new Date() && !u.terminated){
    await db.query("UPDATE profiles SET banned=false,temp_ban_until=NULL,ban_note='' WHERE user_id=$1 AND banned=true AND temp_ban_until<=NOW()",[u.user_id]);
    await db.query("UPDATE gblocks_players SET moderation_status='active',temp_ban_until=NULL,moderation_note='' WHERE user_id=$1 AND moderation_status='banned' AND temp_ban_until<=NOW()",[u.user_id]).catch(()=>{});
    u.banned=false;
    u.temp_ban_until=null;
  }
  const activeBan=!!u.banned&&(!u.temp_ban_until||new Date(u.temp_ban_until)>new Date());
  if(u.terminated)return res.json({signedIn:true,user:u,moderated:true,moderation_status:"terminated",redirect:"/moderation.html"});
  if(activeBan)return res.json({signedIn:true,user:u,moderated:true,moderation_status:"banned",redirect:"/moderation.html"});
  return res.json({signedIn:true,user:u});
}