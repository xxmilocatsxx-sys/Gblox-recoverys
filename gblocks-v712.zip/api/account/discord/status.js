import { db } from "hatchable";
import { currentPlayer, hashText, cookieValue, syncVerifiedRole, removeVerifiedRole } from "../../../lib/discord.js";
export const access="public";
export const methods=["GET","POST"];
export default async function(req,res){
 const player=await currentPlayer(req);
 if(!player)return res.status(401).json({error:"Log in to GBLOX first."});
 if(req.method==="GET"){
  const q=await db.query("SELECT discord_user_id,discord_username,verified_at,linked_at,role_status,role_error FROM gblox_discord_links WHERE user_id=$1 AND revoked_at IS NULL LIMIT 1",[player.user_id]);
  const row=q.rows[0];
  // Reconcile the Discord role whenever the linked-account status is checked.
  if(row) await syncVerifiedRole(row.discord_user_id);
  const bot=await db.query("SELECT is_bot FROM profiles WHERE user_id=$1 LIMIT 1",[player.user_id]);
  const isBot=bot.rows[0]?.is_bot===true;
  const policy=await db.query("SELECT deadline_at FROM gblox_account_link_policy WHERE id=1 LIMIT 1");
  return res.json({linked:!!row,is_bot:isBot,discord_exempt:isBot,discord:row?{user_id:row.discord_user_id,username:row.discord_username,verified_at:row.verified_at,linked_at:row.linked_at,role_status:row.role_status,role_error:row.role_error}:null,deadline_at:isBot?null:(policy.rows[0]?.deadline_at||null)});
 }
 const origin=String(req.headers?.origin||"");if(origin&&origin!=="https://gblocks.hatchable.site")return res.status(403).json({error:"Cross-origin request blocked."});
 const action=String(req.body?.action||"");
 const link=await db.query("SELECT discord_user_id FROM gblox_discord_links WHERE user_id=$1 AND revoked_at IS NULL LIMIT 1",[player.user_id]);
 if(action==="retry-role"){
  if(!link.rows[0])return res.status(404).json({error:"No active Discord link was found."});
  const result=await syncVerifiedRole(link.rows[0].discord_user_id);
  return res.json({ok:true,role_status:result.status,message:result.status==="assigned"?"Verified role assigned.":result.status==="not_in_server"?"Join the official GBLOX Discord server, then retry.":result.status==="not_configured"?"Discord bot, server, or role configuration is missing.":"Role assignment failed; an administrator can review the error."});
 }
 if(action==="unlink"){
  const credential=await db.query("SELECT 1 FROM account_credentials WHERE user_id=$1 UNION ALL SELECT 1 FROM passkey_credentials WHERE user_id=$1 LIMIT 1",[player.user_id]);
  if(!credential.rows.length)return res.status(409).json({error:"Set up a password or passkey before unlinking Discord so you can still recover your account."});
  if(!link.rows[0])return res.status(400).json({error:"Discord is not currently linked."});
  const removed=await removeVerifiedRole(link.rows[0].discord_user_id);
  await db.query("UPDATE gblox_discord_links SET revoked_at=NOW(),role_status='unlinked',role_error=$2 WHERE user_id=$1 AND revoked_at IS NULL",[player.user_id,removed.status==="failed"?removed.error:null]);
  await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES('discord_unlinked',$1,$2,$1,$2,'Player unlinked Discord identity','{}'::jsonb)",[player.user_id,player.username]);
  res.setHeader("Cache-Control","no-store");
  return res.json({ok:true,linked:false,message:"Discord was unlinked. This Discord identity remains reserved to this account to prevent account-link swapping."});
 }
 return res.status(400).json({error:"Unsupported Discord account action."});
}