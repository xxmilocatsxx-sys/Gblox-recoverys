import { db } from "hatchable";
import { discordConfig, currentPlayer, hashText, randomToken, sessionCookie, cookieValue, syncVerifiedRole } from "../../../lib/discord.js";
export const access="public";
export const methods=["GET"];
export default async function(req,res){
 const code=String(req.query?.code||""),state=String(req.query?.state||""),error=String(req.query?.error||"");
 const cookieState=cookieValue(req,"gblox_discord_oauth_state");
 const clearStateCookie="gblox_discord_oauth_state=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax";res.setHeader("Set-Cookie",clearStateCookie);
 if(error)return res.redirect("/login.html?discord=cancelled");
 if(!code||!state||!cookieState||state!==cookieState)return res.redirect("/login.html?discord=invalid_state");
 const stateHash=await hashText(state);
 const sr=await db.query("DELETE FROM gblox_discord_oauth_states WHERE state_hash=$1 AND created_at>NOW()-INTERVAL '15 minutes' RETURNING mode,user_id",[stateHash]);
 const flow=sr.rows[0];if(!flow)return res.redirect("/login.html?discord=expired");
 let cfg;try{cfg=await discordConfig()}catch{return res.redirect("/login.html?discord=setup_required");}
 try{
  const form=new URLSearchParams({client_id:cfg.clientId,client_secret:cfg.clientSecret,grant_type:"authorization_code",code,redirect_uri:cfg.redirectUri});
  const tokenRes=await fetch("https://discord.com/api/v10/oauth2/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded",Accept:"application/json"},body:form.toString()});
  const tokenData=await tokenRes.json().catch(()=>({}));
  if(!tokenRes.ok||!tokenData.access_token)return res.redirect("/login.html?discord=token_failed");
  const userRes=await fetch("https://discord.com/api/v10/users/@me",{headers:{Authorization:"Bearer "+tokenData.access_token,Accept:"application/json"}});
  const discord=await userRes.json().catch(()=>({}));
  if(!userRes.ok||!/^\d{17,20}$/.test(String(discord.id||"")))return res.redirect("/login.html?discord=identity_failed");
  const discordId=String(discord.id),discordName=String(discord.username||"").slice(0,100);
  const linked=await db.query("SELECT l.user_id,p.username,p.display_name,p.banned,p.terminated,p.deactivated_at FROM gblox_discord_links l JOIN profiles p ON p.user_id=l.user_id WHERE l.discord_user_id=$1 AND l.revoked_at IS NULL LIMIT 1",[discordId]);
  if(flow.mode==="link"){
   const player=await currentPlayer(req);
   if(!player||String(player.user_id)!==String(flow.user_id))return res.redirect("/login.html?discord=session_changed");
   const existing=await db.query("SELECT user_id FROM gblox_discord_links WHERE discord_user_id=$1",[discordId]);
   if(existing.rows[0]&&String(existing.rows[0].user_id)!==String(player.user_id))return res.redirect("/settings.html?discord=already_linked");
   const already=await db.query("SELECT discord_user_id FROM gblox_discord_links WHERE user_id=$1",[player.user_id]);
   if(already.rows[0]&&already.rows[0].discord_user_id!==discordId)return res.redirect("/settings.html?discord=another_linked");
   await db.query("INSERT INTO gblox_discord_links(discord_user_id,user_id,discord_username) VALUES($1,$2,$3) ON CONFLICT(discord_user_id) DO UPDATE SET discord_username=EXCLUDED.discord_username,verified_at=NOW(),revoked_at=NULL WHERE gblox_discord_links.user_id=EXCLUDED.user_id",[discordId,player.user_id,discordName]);
   await syncVerifiedRole(discordId);
   return res.redirect("/settings.html?discord=linked");
  }
  if(linked.rows[0]){
   const p=linked.rows[0];
   if(p.deactivated_at)return res.redirect("/account-deactivated.html?username="+encodeURIComponent(p.username));
   const raw=randomToken(),th=await hashText(raw);
   await db.query("INSERT INTO account_sessions(token_hash,user_id,expires_at) VALUES($1,$2,NOW()+INTERVAL '30 days')",[th,p.user_id]);
   await db.query("INSERT INTO login_history(user_id) VALUES($1)",[p.user_id]);
   await db.query("UPDATE profiles SET last_seen_at=NOW() WHERE user_id=$1",[p.user_id]);
   await syncVerifiedRole(discordId);
   const legacyHash=btoa(String.fromCharCode(...new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(raw)))));
   await db.query("INSERT INTO gblocks_sessions(token_hash,user_id,expires_at) SELECT $1,user_id,NOW()+INTERVAL '30 days' FROM gblocks_players WHERE user_id=$2 ON CONFLICT (token_hash) DO NOTHING",[legacyHash,p.user_id]);
   res.setHeader("Set-Cookie",[clearStateCookie,sessionCookie("groblox_session",raw,2592000),sessionCookie("gblocks_session",raw,2592000)]);
   if(p.terminated||p.banned)return res.redirect("/moderation.html");
   return res.redirect("/");
  }
  if(flow.mode==="login"&&linked.rows[0])return res.redirect("/");
  const ticket=randomToken(),ticketHash=await hashText(ticket);
  await db.query("DELETE FROM gblox_discord_pending WHERE expires_at<NOW()");
  const conflict=await db.query("SELECT discord_user_id FROM gblox_discord_links WHERE discord_user_id=$1",[discordId]);
  if(conflict.rows.length)return res.redirect("/login.html?discord=already_linked");
  await db.query("INSERT INTO gblox_discord_pending(ticket_hash,discord_user_id,discord_username,expires_at) VALUES($1,$2,$3,NOW()+INTERVAL '15 minutes') ON CONFLICT(discord_user_id) DO UPDATE SET ticket_hash=EXCLUDED.ticket_hash,discord_username=EXCLUDED.discord_username,expires_at=EXCLUDED.expires_at",[ticketHash,discordId,discordName]);
  res.setHeader("Set-Cookie",[clearStateCookie,sessionCookie("gblox_discord_pending",ticket,900)]);
  return res.redirect("/signup.html?discord=verified");
 }catch(e){
  console.error("Discord OAuth callback failed:",String(e?.message||e).slice(0,250));
  return res.redirect("/login.html?discord=failed");
 }
}