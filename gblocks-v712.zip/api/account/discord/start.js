import { db } from "hatchable";
import { discordConfig, currentPlayer, hashText, randomToken, cookieValue } from "../../../lib/discord.js";
export const access="public";
export const methods=["GET"];
export default async function(req,res){
 const mode=String(req.query?.mode||"login");
 if(!["signup","login","link"].includes(mode))return res.status(400).json({error:"Invalid Discord sign-in mode."});
 const player=mode==="link"?await currentPlayer(req):null;
 if(mode==="link"&&!player)return res.status(401).json({error:"Log in to GBLOX before linking Discord."});
 let cfg;try{cfg=await discordConfig()}catch{return res.status(503).json({error:"Discord sign-in is not configured yet. An administrator must finish the Discord Developer Portal setup."});}
 if(!cfg.clientId||!cfg.clientSecret)return res.redirect((mode==="signup"?"/signup.html":"/login.html")+"?discord=setup_required");
 const state=randomToken(),stateHash=await hashText(state);
 await db.query("DELETE FROM gblox_discord_oauth_states WHERE created_at<NOW()-INTERVAL '15 minutes'");
 await db.query("INSERT INTO gblox_discord_oauth_states(state_hash,mode,user_id) VALUES($1,$2,$3)",[stateHash,mode,player?.user_id||null]);
 const url=new URL("https://discord.com/oauth2/authorize");
 url.searchParams.set("client_id",cfg.clientId);url.searchParams.set("redirect_uri",cfg.redirectUri);url.searchParams.set("response_type","code");url.searchParams.set("scope","identify");url.searchParams.set("state",state);
 res.setHeader("Cache-Control","no-store");
 res.setHeader("Set-Cookie","gblox_discord_oauth_state="+encodeURIComponent(state)+"; Path=/; Max-Age=900; HttpOnly; Secure; SameSite=Lax");
 return res.redirect(url.toString());
}