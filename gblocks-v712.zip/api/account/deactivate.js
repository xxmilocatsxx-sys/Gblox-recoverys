import { db } from "hatchable";
export const access="public";
export const methods=["GET","POST"];
const enc=new TextEncoder();
async function hash(t,urlSafe=true){const raw=btoa(String.fromCharCode(...new Uint8Array(await crypto.subtle.digest("SHA-256",enc.encode(String(t))))));return urlSafe?raw.split("+").join("-").split("/").join("_").replace(/=+$/,""):raw;}
function cookie(req,name){const c=String(req.headers?.cookie||"").match(new RegExp("(?:^|;\\s*)"+name+"=([^;]+)"));return c?decodeURIComponent(c[1]):"";}
async function me(req){
 const legacy=cookie(req,"groblox_session");
 if(legacy){const q=await db.query("SELECT s.user_id,p.username,p.display_name,p.terminated,p.banned,'legacy' AS session_type FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await hash(legacy,true)]);if(q.rows[0])return q.rows[0];}
 const modern=req.headers?.["x-gblocks-session"]||cookie(req,"gblocks_session");
 if(modern){const q=await db.query("SELECT s.user_id,p.username,p.display_name,(p.moderation_status='terminated') AS terminated,(p.moderation_status='banned') AS banned,'modern' AS session_type FROM gblocks_sessions s JOIN gblocks_players p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await hash(String(modern),false)]);if(q.rows[0])return q.rows[0];}
 return null;
}
export default async function(req,res){
 const u=await me(req);if(!u)return res.status(401).json({error:"Not signed in."});
 if(u.terminated)return res.status(403).json({error:"This account is terminated."});
 if(u.banned)return res.status(403).json({error:"This account is banned and cannot be deactivated or reactivated from this screen."});
 const state=await db.query("SELECT COALESCE(p.deactivated_at,g.deactivated_at) AS deactivated_at,COALESCE(p.recovery_deadline,g.recovery_deadline) AS recovery_deadline,COALESCE(p.legacy_status,g.legacy_status,'active') AS legacy_status FROM profiles p FULL JOIN gblocks_players g ON g.user_id=p.user_id WHERE COALESCE(p.user_id,g.user_id)=$1 LIMIT 1",[u.user_id]);
 if(!state.rows[0])return res.status(404).json({error:"GBlocks account record not found."});
 if(req.method==="GET")return res.json({ok:true,deactivated:!!state.rows[0].deactivated_at,...state.rows[0]});
 const action=String(req.body?.action||"deactivate");
 if(action==="deactivate"){
  if(state.rows[0].deactivated_at)return res.json({ok:true,deactivated:true,message:"Account already deactivated.",redirect:"/account-deactivated.html"});
  const names=await db.query("SELECT username,display_name FROM profiles WHERE user_id=$1 UNION ALL SELECT username,display_name FROM gblocks_players WHERE user_id=$1 LIMIT 1",[u.user_id]);
  const identity=names.rows[0]||u;
  const audit=await db.query("INSERT INTO gblocks_account_deactivation_history(user_id,action,username_snapshot,display_name_snapshot,deactivated_at,recovery_deadline) VALUES($1,'deactivated',$2,$3,NOW(),NOW()+INTERVAL '2 years') RETURNING deactivated_at,recovery_deadline",[u.user_id,identity.username||"",identity.display_name||identity.username||""]);
  await db.query("UPDATE profiles SET deactivated_at=NOW(),recovery_deadline=NOW()+INTERVAL '2 years',legacy_status='deactivated',legacy_reviewed_at=NULL WHERE user_id=$1",[u.user_id]);
  await db.query("UPDATE gblocks_players SET deactivated_at=NOW(),recovery_deadline=NOW()+INTERVAL '2 years',legacy_status='deactivated',legacy_bot_enabled=false,legacy_reviewed_at=NULL,updated_at=NOW() WHERE user_id=$1",[u.user_id]);
  await db.query("DELETE FROM account_sessions WHERE user_id=$1",[u.user_id]);
  await db.query("DELETE FROM gblocks_sessions WHERE user_id=$1",[u.user_id]);
  res.setHeader("Set-Cookie",["groblox_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax","gblocks_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax"]);
  res.setHeader("Cache-Control","no-store");
  return res.json({ok:true,deactivated:true,message:"Account Deactivated. You can reactivate this at any time.",recovery_deadline:audit.rows[0]?.recovery_deadline||null,redirect:"/account-deactivated.html"});
 }
 if(action==="reactivate"){
  return res.status(409).json({error:"For security, sign in with your username and password on the Account Deactivated page to reactivate this account.",redirect:"/account-deactivated.html"});
 }
 return res.status(400).json({error:"Unknown account action."});
}