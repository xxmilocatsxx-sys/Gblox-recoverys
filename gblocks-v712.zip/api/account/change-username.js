import { db } from "hatchable";
import { checkUsername } from "../../lib/username-policy.js";
export const access="public";
export const methods=["POST"];

const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function tokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function getCookie(req,name){const c=String(req.headers?.cookie||"");const m=c.match(new RegExp("(?:^|;\\s*)"+name+"=([^;]*)"));return m?m[1]:null}

const USERNAME_COST=600;

export default async function(req,res){
  const cookieHeader=String(req.headers?.cookie||"");
  const gblocksRaw=getCookie(req,"gblocks_session");
  const legacyRaw=getCookie(req,"groblox_session");

  // GBlocks accounts use the gblocks_* tables/session. Keep the legacy path below for older accounts.
  if(gblocksRaw){
    const tokenHashValue=await tokenHash(gblocksRaw);
    const q=await db.query("SELECT p.user_id,p.username,p.display_name,p.moderation_status,p.gobux,p.username_history,c.username AS credential_username FROM gblocks_sessions s JOIN gblocks_players p ON p.user_id=s.user_id LEFT JOIN gblocks_credentials c ON c.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[tokenHashValue]);
    const account=q.rows[0];
    if(!account)return res.status(401).json({error:"Not signed in."});
    if(account.moderation_status==="terminated")return res.status(403).json({error:"This account is terminated."});
    if(account.moderation_status==="banned")return res.status(403).json({error:"This account is temporarily banned."});

    const newName=String(req.body?.username||"").trim();
    if(!/^[A-Za-z0-9_]{3,24}$/.test(newName))return res.status(400).json({error:"Username must be 3–24 characters using letters, numbers, or underscores."});
    if((newName.match(/_/g)||[]).length>1)return res.status(400).json({error:"Normal player usernames can contain at most one underscore."});
    const usernamePolicy=checkUsername(newName);
    if(usernamePolicy.flagged)return res.status(400).json({error:"That username is not allowed: "+usernamePolicy.reason});

    const currentName=String(account.username||account.credential_username||"");
    const history=Array.isArray(account.username_history)?account.username_history:[];
    const currentFold=currentName.toLowerCase();
    if(newName.toLowerCase()===currentFold){
      return res.json({ok:true,noChange:true,oldUsername:currentName,newUsername:currentName,cost:0,balance:Number(account.gobux||0),history});
    }

    const taken=await db.query("SELECT 1 FROM gblocks_players WHERE lower(username)=lower($1) AND user_id<>$2 UNION SELECT 1 FROM gblocks_credentials WHERE lower(username)=lower($1) AND user_id<>$2 UNION SELECT 1 FROM username_history WHERE lower(username)=lower($1) AND user_id<>$2 UNION SELECT 1 FROM username_reservations WHERE lower(username)=lower($1) AND reserved_for_user_id<>$2 LIMIT 1",[newName,account.user_id]);
    if(taken.rows.length)return res.status(409).json({error:"That username is already used or reserved by another account."});

    const balance=Number(account.gobux||0);
    if(balance<USERNAME_COST)return res.status(402).json({error:"Not enough Gobux. Username changes cost 600 Gobux.",cost:USERNAME_COST,balance});

    const newHistory=[...history,currentName];
    await db.query("UPDATE gblocks_players SET username=$1,display_name=$1,gobux=gobux-$2,username_history=$3::jsonb WHERE user_id=$4 AND gobux >= $2",[newName,USERNAME_COST,JSON.stringify(newHistory),account.user_id]);
    await db.query("UPDATE gblocks_credentials SET username=$1,updated_at=NOW() WHERE user_id=$2",[newName,account.user_id]);
    await db.query("UPDATE profiles SET username=$1,display_name=$1 WHERE user_id=$2",[newName,account.user_id]).catch(()=>{});
    await db.query("INSERT INTO username_history(username,user_id) VALUES($1,$2)",[currentName,account.user_id]);
    await db.query("INSERT INTO username_reservations(username,reserved_for_user_id,reason) VALUES($1,$2,$3) ON CONFLICT(username) DO UPDATE SET reserved_for_user_id=EXCLUDED.reserved_for_user_id,reason=EXCLUDED.reason",[currentName,account.user_id,"username_history"]);
    return res.json({ok:true,oldUsername:currentName,newUsername:newName,cost:USERNAME_COST,balance:balance-USERNAME_COST,history:newHistory});
  }

  const raw=legacyRaw;
  if(!raw)return res.status(401).json({error:"Not signed in."});

  const q=await db.query(
    "SELECT p.user_id,p.username,p.banned,p.terminated FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()",
    [await tokenHash(raw)]
  );
  const account=q.rows[0];
  if(!account)return res.status(401).json({error:"Not signed in."});
  if(account.terminated)return res.status(403).json({error:"This account is terminated."});
  if(account.banned)return res.status(403).json({error:"This account is temporarily banned."});

  const newName=String(req.body?.username||"").trim();
  if(!/^[A-Za-z0-9_]{3,24}$/.test(newName))return res.status(400).json({error:"Username must be 3–24 characters using letters, numbers, or underscores."});
  if((newName.match(/_/g)||[]).length>1)return res.status(400).json({error:"Normal player usernames can contain at most one underscore."});
  const usernamePolicy=checkUsername(newName);
  if(usernamePolicy.flagged)return res.status(400).json({error:"That username is not allowed: "+usernamePolicy.reason});
  // The signed-in owner is allowed to keep their own username, including capitalization differences.
  if(newName.toLowerCase()===String(account.username).toLowerCase()){
    const balanceRow=await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1",[account.user_id]);
    const balance=Number(balanceRow.rows[0]?.balance||0);
    const ownHistory=(await db.query("SELECT username FROM username_history WHERE user_id=$1 ORDER BY changed_at ASC,id ASC",[account.user_id])).rows.map(r=>r.username);
    return res.json({ok:true,noChange:true,oldUsername:account.username,newUsername:account.username,cost:0,balance,history:ownHistory.concat([account.username])});
  }

  const taken=await db.query(
    "SELECT 1 FROM profiles WHERE LOWER(username)=LOWER($1) AND user_id<>$2 UNION SELECT 1 FROM username_history WHERE LOWER(username)=LOWER($1) AND user_id<>$2 UNION SELECT 1 FROM username_reservations WHERE LOWER(username)=LOWER($1) AND reserved_for_user_id<>$2",
    [newName,account.user_id]
  );
  if(taken.rows.length)return res.status(409).json({error:"That username is already used or reserved by another account."});

  const historyRows=await db.query(
    "SELECT username FROM username_history WHERE user_id=$1 ORDER BY changed_at ASC,id ASC",
    [account.user_id]
  );
  const history=historyRows.rows.map(r=>r.username);

  // Check funds before changing username/history records so a failed payment cannot partially update the account.
  const funds=await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1",[account.user_id]);
  const available=Number(funds.rows[0]?.balance||0);
  const infinite=Boolean(funds.rows[0]?.gobux_infinite);
  if(!infinite && available<USERNAME_COST)return res.status(402).json({error:"Not enough Gobux. Username changes cost 600 Gobux.",cost:USERNAME_COST,balance:available});

  const tx=await db.transaction([
    {sql:"SELECT username,banned,terminated FROM profiles WHERE user_id=$1 FOR UPDATE",params:[account.user_id]},
    {sql:"UPDATE gobux_accounts SET balance=CASE WHEN gobux_infinite THEN balance ELSE balance-$1 END,updated_at=NOW() WHERE user_id=$2 AND (gobux_infinite OR balance >= $1) RETURNING balance,gobux_infinite",params:[USERNAME_COST,account.user_id]},
    {sql:"INSERT INTO username_history (username,user_id) VALUES ($1,$2)",params:[account.username,account.user_id]},
    {sql:"INSERT INTO username_reservations (username,reserved_for_user_id,reason) VALUES ($1,$2,$3) ON CONFLICT (username) DO UPDATE SET reserved_for_user_id=EXCLUDED.reserved_for_user_id,reason=EXCLUDED.reason",params:[account.username,account.user_id,"username_history"]},
    {sql:"UPDATE profiles SET username=$1,display_name=$1 WHERE user_id=$2",params:[newName,account.user_id]}
  ]);

  const balanceResult=tx?.results?.[1]?.rows?.[0];
  if(!balanceResult)return res.status(402).json({error:"Not enough Gobux. Username changes cost 600 Gobux.",cost:USERNAME_COST});

  const balance=Number(balanceResult.balance);
  return res.json({
    ok:true,
    oldUsername:account.username,
    newUsername:newName,
    cost:USERNAME_COST,
    balance,
    history:[...history,account.username]
  });
}