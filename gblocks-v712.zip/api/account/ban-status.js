import { db } from 'hatchable';
export const access = 'public';
export const methods = ['GET'];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
async function hash(t){return b64(await crypto.subtle.digest('SHA-256',enc.encode(t)))}
export default async function(req,res){
  const raw=req.cookies?.groblox_session || String(req.headers?.cookie||'').match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1] || null;
  if(!raw)return res.json({signedIn:false,banned:false});
  const q=await db.query("SELECT p.user_id,p.username,p.display_name,p.banned,p.terminated,p.temp_ban_until,p.ban_note FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await hash(raw)]);
  const u=q.rows[0];
  if(!u)return res.json({signedIn:false,banned:false});
  if(u.terminated)return res.json({signedIn:true,terminated:true,banned:false,userId:String(u.user_id),username:u.username,displayName:u.display_name,banNote:u.ban_note||'',tempBanUntil:u.temp_ban_until});
  const now=new Date();
  const active=!!u.banned && (!u.temp_ban_until || new Date(u.temp_ban_until)>now);
  const reactivationReady=!!u.banned && !!u.temp_ban_until && new Date(u.temp_ban_until)<=now;
  res.json({signedIn:true,banned:active,reactivationReady,userId:String(u.user_id),username:u.username,displayName:u.display_name,banNote:u.ban_note||'',tempBanUntil:u.temp_ban_until});
}