import { db } from "hatchable";
import { checkBio } from "../lib/moderation-policy.js";

export const access = "public";
export const methods = ["GET", "POST"];

const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
async function tokenHash(token) { return b64(await crypto.subtle.digest("SHA-256", enc.encode(token))); }
function sessionCookie(req) { return String(req.headers?.cookie || "").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1] || null; }

async function caller(req) {
  const token = sessionCookie(req);
  if (!token) return null;
  const q = await db.query("SELECT p.user_id,p.username,p.display_name,p.bio,p.banned,p.terminated FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()", [await tokenHash(token)]);
  return q.rows[0] || null;
}

const allowedThemes = new Set(["system", "light", "dark"]);
const allowedVisibility = new Set(["public", "private"]);
const socialKeys = ["youtube", "discord", "tiktok", "instagram", "x", "website"];

function cleanSocials(input) {
  const source = input && typeof input === "object" ? input : {};
  const out = {};
  for (const key of socialKeys) {
    const value = String(source[key] || "").trim().slice(0, 200);
    if (value) out[key] = value;
  }
  return out;
}

export default async function(req, res) {
  const user = await caller(req);
  if (!user) return res.status(401).json({ error: "Log in to open your settings." });
  if (user.terminated) return res.status(403).json({ error: "This GBLOCKS account has been terminated." });
  if (user.banned) return res.status(403).json({ error: "This GBLOCKS account is banned." });

  if (req.method === "GET") {
    const settings = await db.query("SELECT birthday,gender,app_theme,accent_color,profile_theme,reduced_motion,social_accounts,profile_visibility,birthday_visibility,social_visibility FROM user_settings WHERE user_id=$1", [user.user_id]);
    const history = await db.query("SELECT logged_in_at FROM login_history WHERE user_id=$1 ORDER BY logged_in_at DESC LIMIT 20", [user.user_id]);
    const row = settings.rows[0] || {};
    return res.json({
      ok: true,
      account: { username: user.username, display_name: user.display_name, bio: user.bio },
      settings: {
        birthday: row.birthday || "",
        gender: row.gender || "",
        app_theme: row.app_theme || "system",
        accent_color: row.accent_color || "blue",
        profile_theme: row.profile_theme || "neon",
        reduced_motion: Boolean(row.reduced_motion),
        social_accounts: row.social_accounts || {},
        profile_visibility: row.profile_visibility || "public",
        birthday_visibility: row.birthday_visibility || "private",
        social_visibility: row.social_visibility || "public"
      },
      login_history: history.rows.map(x => x.logged_in_at)
    });
  }

  const body = req.body && typeof req.body === "object" ? req.body : {};
  const gender=String(body.gender||"").trim().toLowerCase();
  if(!["male","female"].includes(gender)) return res.status(400).json({error:"Choose Male or Female for your account gender."});
  const displayName = String(body.display_name ?? user.display_name ?? user.username).trim().slice(0, 40);
  if (displayName.toLowerCase() === 'builder' && String(user.user_id) !== 'c66afd7c-03ea-42bc-b771-69b836f7049f') return res.status(409).json({ error: 'The display name Builder is reserved for the official GBlocks Builder account.' });
  const bio = String(body.bio ?? user.bio ?? "").trim().slice(0, 160);
  let moderatedBio=bio;
  let bioDeleted=false;
  const localBioCheck=checkBio(bio);
  if(localBioCheck.flagged){ moderatedBio='[Content Deleted]'; bioDeleted=true; }
  const theme = allowedThemes.has(String(body.app_theme)) ? String(body.app_theme) : "system";
  const accentColor = new Set(["blue","red","cyan","purple"]).has(String(body.accent_color)) ? String(body.accent_color) : "blue";
  const profileTheme = new Set(["neon","classic","minimal"]).has(String(body.profile_theme)) ? String(body.profile_theme) : "neon";
  const reducedMotion = body.reduced_motion === true || String(body.reduced_motion) === "true";
  const profileVisibility = allowedVisibility.has(String(body.profile_visibility)) ? String(body.profile_visibility) : "public";
  const birthdayVisibility = allowedVisibility.has(String(body.birthday_visibility)) ? String(body.birthday_visibility) : "private";
  const socialVisibility = allowedVisibility.has(String(body.social_visibility)) ? String(body.social_visibility) : "public";
  const birthday = body.birthday ? String(body.birthday).trim() : null;
  if (birthday && !/^\d{4}-\d{2}-\d{2}$/.test(birthday)) return res.status(400).json({ error: "Birthday must use YYYY-MM-DD format." });
  if (birthday && birthday > new Date().toISOString().slice(0, 10)) return res.status(400).json({ error: "Birthday cannot be in the future." });

  const socials = cleanSocials(body.social_accounts);
  const profileRow = await db.query("SELECT avatar FROM profiles WHERE user_id=$1", [user.user_id]);
  let avatar = profileRow.rows[0]?.avatar && typeof profileRow.rows[0].avatar === "object" ? profileRow.rows[0].avatar : {};
  const custom = avatar.custom && typeof avatar.custom === "object" ? { ...avatar.custom } : {};
  const previousGender=custom.gender;
  custom.gender=gender;
  if(gender==="female"){
    if(!custom.hair || custom.hair==="none") custom.hair="brown";
    if(!custom.shirt || custom.shirt==="#b91c1c") custom.shirt="#a855f7";
  }else if(previousGender==="female"){
    if(custom.hair==="brown") custom.hair="none";
    if(custom.shirt==="#a855f7") custom.shirt="#b91c1c";
  }
  custom.items=custom.items&&typeof custom.items==="object"?custom.items:{};
  avatar={...avatar,custom,gender};
  await db.query("UPDATE profiles SET display_name=$1,bio=$2,avatar=$3,gender=$4,bio_deleted_by_moderation=$5,bio_moderation_status=$6,bio_moderation_last_reviewed_at=NOW() WHERE user_id=$7", [displayName, moderatedBio, JSON.stringify(avatar), gender, bioDeleted, bioDeleted ? 'content_deleted' : 'reviewed', user.user_id]);
  await db.query("UPDATE gblocks_players SET display_name=$1,bio=$2,avatar=$3,gender=$4,bio_deleted_by_moderation=$5 WHERE user_id=$6", [displayName, moderatedBio, JSON.stringify(avatar), gender, bioDeleted, user.user_id]);
  await db.query(
    "INSERT INTO user_settings (user_id,birthday,gender,app_theme,accent_color,profile_theme,reduced_motion,social_accounts,profile_visibility,birthday_visibility,social_visibility,updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,now()) ON CONFLICT (user_id) DO UPDATE SET birthday=$2,gender=$3,app_theme=$4,accent_color=$5,profile_theme=$6,reduced_motion=$7,social_accounts=$8,profile_visibility=$9,birthday_visibility=$10,social_visibility=$11,updated_at=now()",
    [user.user_id, birthday, gender, theme, accentColor, profileTheme, reducedMotion, JSON.stringify(socials), profileVisibility, birthdayVisibility, socialVisibility]
  );

  return res.json({ ok: true, bio_deleted: bioDeleted, moderation_message: bioDeleted ? "Your bio was removed for violating GBlocks content rules." : null, account: { username: user.username, display_name: displayName, bio: moderatedBio }, settings: { birthday: birthday || "", gender, app_theme: theme, accent_color: accentColor, profile_theme: profileTheme, reduced_motion: reducedMotion, social_accounts: socials, profile_visibility: profileVisibility, birthday_visibility: birthdayVisibility, social_visibility: socialVisibility } });
}