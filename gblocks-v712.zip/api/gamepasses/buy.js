import { db } from "hatchable";
export const access="public";
export const methods=["POST"];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function hash(v){return b64(await crypto.subtle.digest("SHA-256",enc.encode(v)))}
function cookie(req,name){if(req.cookies?.[name])return String(req.cookies[name]);const c=String(req.headers?.cookie||"");const m=c.match(new RegExp("(?:^|;\\s*)"+name+"=([^;]*)"));return m?decodeURIComponent(m[1]):null}
async function viewer(req){const raw=cookie(req,"gblocks_session")||cookie(req,"groblox_session");if(!raw)return null;const h=await hash(raw);const table=cookie(req,"gblocks_session")?"gblocks_sessions":"account_sessions";const q=await db.query(`SELECT p.user_id,p.username,p.banned,p.terminated FROM ${table} s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1`,[h]);return q.rows[0]||null}
export default async function(req,res){
 const u=await viewer(req);if(!u)return res.status(401).json({error:"Log in to buy a gamepass."});if(u.banned||u.terminated)return res.status(403).json({error:"This account cannot buy gamepasses."});
 const id=String(req.body?.gamepass_id||"").trim();if(!id)return res.status(400).json({error:"Choose a gamepass."});
 const pass=(await db.query("SELECT gp.*,p.username AS owner_username,p.banned AS owner_banned,p.terminated AS owner_terminated FROM gamepasses gp JOIN profiles p ON p.user_id=gp.owner_user_id WHERE gp.id=$1 AND gp.active=true LIMIT 1",[id])).rows[0];
 if(!pass)return res.status(404).json({error:"Gamepass not found."});
 if(pass.owner_user_id===u.user_id)return res.status(400).json({error:"You cannot buy your own gamepass."});
 if(pass.owner_banned||pass.owner_terminated)return res.status(403).json({error:"This creator's account is not active."});
 const prior=await db.query("SELECT id FROM gamepass_purchases WHERE gamepass_id=$1 AND buyer_user_id=$2",[id,u.user_id]);if(prior.rows.length)return res.status(409).json({error:"You already own this gamepass."});
 const acct=(await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1 LIMIT 1",[u.user_id])).rows[0];
 if(!acct||(!acct.gobux_infinite&&Number(acct.balance||0)<Number(pass.price)))return res.status(400).json({error:"You do not have enough Gobux."});
 const forwarded=String(req.headers?.["x-forwarded-for"]||req.headers?.["cf-connecting-ip"]||"").split(",")[0].trim();
 const ipHash=forwarded?await hash("gblox-gamepass-ip-v1:"+forwarded):null;
 const transactionId="gpp_"+crypto.randomUUID().replace(/-/g,"");
 // Debit buyer, credit 70% to creator, and record the completed ownership.
 if(!acct.gobux_infinite){const debit=await db.query("UPDATE gobux_accounts SET balance=balance-$1,updated_at=NOW() WHERE user_id=$2 AND balance >= $1 RETURNING balance",[pass.price,u.user_id]);if(!debit.rows.length)return res.status(409).json({error:"Balance changed; refresh and try again."});}
 await db.query("INSERT INTO gobux_accounts(user_id,balance,gobux_infinite) VALUES($1,0,false) ON CONFLICT(user_id) DO NOTHING",[pass.owner_user_id]);
 const sellerShare=Math.floor(Number(pass.price)*0.7);
 await db.query("UPDATE gobux_accounts SET balance=balance+$1,updated_at=NOW() WHERE user_id=$2",[sellerShare,pass.owner_user_id]);
 await db.query("INSERT INTO gamepass_purchases(id,gamepass_id,buyer_user_id,seller_user_id,price,buyer_ip_hash) VALUES($1,$2,$3,$4,$5,$6)",[transactionId,id,u.user_id,pass.owner_user_id,pass.price,ipHash]);
 await db.query("INSERT INTO gobux_transactions(transaction_id,user_id,counterparty_user_id,direction,amount,source_type,status) VALUES($1,$2,$3,'out',$4,'gamepass_purchase','completed'),($5,$3,$2,'in',$6,'gamepass_sale','completed')",[transactionId,u.user_id,pass.owner_user_id,pass.price,transactionId+"_seller",sellerShare]).catch(()=>{});
 // Anti-alt rule: when three distinct buyer accounts from the same IP have bought
 // passes from this same creator, terminate only the newest suspected buyer; never the receiving creator.
 let altTerminated=false;
 if(ipHash){
  const cluster=await db.query("SELECT DISTINCT gp.buyer_user_id,p.username,p.created_at FROM gamepass_purchases gp JOIN profiles p ON p.user_id=gp.buyer_user_id WHERE gp.seller_user_id=$1 AND gp.buyer_ip_hash=$2 ORDER BY p.created_at DESC LIMIT 3",[pass.owner_user_id,ipHash]);
  if(cluster.rows.length>=3){
   // Terminate the newest-created suspected buyer account in the cluster, not the recipient/main.
   const suspected=cluster.rows[0];
   const reason="Gamepass anti-alting: three distinct accounts from the same detected network bought gamepasses from the same recipient. Recipient account was not penalized.";
   await db.query("UPDATE profiles SET terminated=true,banned=false,verified=false,ban_note=$1,bio='[Content Deleted]' WHERE user_id=$2",[reason,suspected.buyer_user_id]);
   await db.query("UPDATE gblocks_players SET moderation_status='terminated',moderation_note=$1,bio='[content Deleted]' WHERE user_id=$2",[reason,suspected.buyer_user_id]).catch(()=>{});
   await db.query("INSERT INTO username_history(username,user_id) SELECT username,user_id FROM profiles WHERE user_id=$1 AND NOT EXISTS(SELECT 1 FROM username_history h WHERE h.user_id=$1 AND LOWER(h.username)=LOWER(profiles.username))",[suspected.buyer_user_id]).catch(()=>{});
   await db.query("INSERT INTO username_reservations(username,reserved_for_user_id,reason) SELECT username,user_id,'terminated_account' FROM profiles WHERE user_id=$1 ON CONFLICT(username) DO NOTHING",[suspected.buyer_user_id]).catch(()=>{});
   await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES('TERMINATE',$1,$2,'system','GBLOX Anti-Alting',$3,$4::jsonb)",[suspected.buyer_user_id,suspected.username,reason,JSON.stringify({rule:"same_ip_three_buyers_one_recipient",recipient_user_id:pass.owner_user_id,ip_hash:ipHash,gamepass_id:id,detected_buyer_ids:cluster.rows.map(x=>x.buyer_user_id)})]).catch(()=>{});
   altTerminated=String(suspected.buyer_user_id)===String(u.user_id);
  }
 }
 return res.json({ok:true,purchased:true,gamepass_id:id,price:Number(pass.price),creator_earned:sellerShare,altTerminated,message:altTerminated?"Purchase recorded, but this account was terminated under the anti-alting rule. The recipient account was not penalized.":"Gamepass purchased successfully."});
}