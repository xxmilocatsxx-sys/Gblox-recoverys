import { db } from 'hatchable';
import { checkUsername } from '../lib/username-policy.js';

export const access = 'public';
export const methods = ['GET'];

const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/g,'');
async function tokenHash(t){ return b64(await crypto.subtle.digest('SHA-256', enc.encode(t))); }
function sessionToken(req){
  const c=String(req.headers?.cookie||'');
  return c.match(/(?:^|;\s*)gblocks_session=([^;]*)/)?.[1] || c.match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1] || null;
}
async function caller(req){
  const c=String(req.headers?.cookie||'');
  const gblocks=c.match(/(?:^|;\s*)gblocks_session=([^;]*)/)?.[1]||null;
  if(gblocks){
    const {rows}=await db.query("SELECT p.user_id FROM gblocks_sessions s JOIN gblocks_players p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await tokenHash(gblocks)]);
    return rows[0]?{...rows[0],role:'user',source:'gblocks'}:null;
  }
  const token=c.match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1]||null;
  if(!token)return null;
  const {rows}=await db.query("SELECT p.user_id,p.role FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()",[await tokenHash(token)]);
  return rows[0]?{...rows[0],source:'legacy'}:null;
}

export default async function (req, res) {
  const username = String(req.query?.username || '').trim();
  if (!username) return res.json({ available:false, valid:false, flagged:true, message:'Enter a username' });

  const me=await caller(req);
  const policy=checkUsername(username);
  // "GBLOCKS" is the official brand name: only an administrator may claim it.
  const adminBrandName=username.toLowerCase()==='gblocks' && me?.role==='administrator';
  if(policy.flagged && !adminBrandName){
    return res.json({ available:false, valid:false, flagged:true, message:policy.reason });
  }

  if(me?.source==='gblocks'){
    const {rows:taken}=await db.query("SELECT user_id,username FROM gblocks_players WHERE lower(username)=lower($1) LIMIT 1",[username]);
    if(taken.length){
      if(String(taken[0].user_id)===String(me.user_id)) return res.json({available:true,valid:true,flagged:false,owned:true,message:'This is your current username.'});
      return res.json({available:false,valid:true,flagged:false,message:'That username is already taken.'});
    }
    const {rows:historyTaken}=await db.query("SELECT user_id,username FROM gblocks_players WHERE EXISTS (SELECT 1 FROM jsonb_array_elements_text(username_history) h WHERE lower(h)=lower($1)) AND user_id<>$2 LIMIT 1",[username,me.user_id]);
    if(historyTaken.length)return res.json({available:false,valid:true,flagged:false,message:'That username is already used or reserved.'});
    const {rows:credentialTaken}=await db.query("SELECT user_id FROM gblocks_credentials WHERE lower(username)=lower($1) AND user_id<>$2 LIMIT 1",[username,me.user_id]);
    if(credentialTaken.length)return res.json({available:false,valid:true,flagged:false,message:'That username is already taken.'});
  }else{
    const {rows:taken}=await db.query('SELECT user_id,username FROM profiles WHERE lower(username) = $1 LIMIT 1',[username.toLowerCase()]);
    if(taken.length){
      if(me && String(taken[0].user_id)===String(me.user_id)) return res.json({available:true,valid:true,flagged:false,owned:true,message:'This is your current username.'});
      return res.json({available:false,valid:true,flagged:false,message:'That username is already taken.'});
    }
  }

  const {rows:reserved}=await db.query('SELECT reserved_for_user_id FROM username_reservations WHERE lower(username)=$1 LIMIT 1',[username.toLowerCase()]);
  if(reserved.length && String(reserved[0].reserved_for_user_id)!==String(me?.user_id||'')){
    return res.json({available:false,valid:true,flagged:false,message:'That username is reserved.'});
  }

  return res.json({available:true,valid:true,flagged:false,message:'Username is available!'});
}