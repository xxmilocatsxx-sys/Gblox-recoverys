import { db } from 'hatchable';
export const access = 'public';
export const methods = ['POST'];
const PRICE = 50000000;
const ITEMS = {
  'glitch-grenade': { name: 'Glitch Grenade', effect: 'Makes the game world flicker for 8 seconds.' },
  'fake-admin-panel': { name: 'Fake Admin Panel', effect: 'Opens a pretend villain control panel.' },
  'lag-blaster': { name: 'Lag Blaster', effect: 'Freezes NPCs in this game for 5 seconds.' },
  'red-screen': { name: 'Red Screen Override', effect: 'Turns the game screen red for 6 seconds.' }
};
const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
async function tokenHash(t){ return b64(await crypto.subtle.digest('SHA-256',enc.encode(t))); }
function getCookie(req,name){ if(req.cookies?.[name]) return String(req.cookies[name]); const c=String(req.headers?.cookie||''); const m=c.match(new RegExp('(?:^|;\\s*)'+name+'=([^;]*)')); return m?decodeURIComponent(m[1]):null; }
async function sessionUser(req){
 const g=getCookie(req,'gblocks_session'); const raw=g||getCookie(req,'groblox_session'); if(!raw)return null;
 const hash=await tokenHash(raw); const table=g?'gblocks_sessions':'account_sessions';
 const q=await db.query(`SELECT p.user_id,p.username,p.banned,p.terminated FROM ${table} s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1`,[hash]);
 const u=q.rows[0]; return u&&!u.banned&&!u.terminated?u:null;
}
export default async function(req,res){
 const user=await sessionUser(req); if(!user)return res.status(401).json({error:'Log in to buy fictional game items.'});
 const itemId=String(req.body?.item_id||''); const item=ITEMS[itemId]; if(!item)return res.status(400).json({error:'Unknown Cheats shop item.'});
 const owned=await db.query('SELECT 1 FROM cheats_shop_inventory WHERE user_id=$1 AND item_id=$2 LIMIT 1',[String(user.user_id),itemId]);
 if(owned.rows.length)return res.status(409).json({error:'You already own this item.'});
 try {
  await db.transaction([
   {sql:'INSERT INTO gobux_accounts (user_id,balance,gobux_infinite) VALUES ($1,0,false) ON CONFLICT (user_id) DO NOTHING',params:[String(user.user_id)]},
   {sql:'WITH debited AS (UPDATE gobux_accounts SET balance=balance-$1,updated_at=NOW() WHERE user_id=$2 AND gobux_infinite=FALSE AND balance >= $1 RETURNING user_id) SELECT 1 / CASE WHEN EXISTS (SELECT 1 FROM debited) THEN 1 ELSE 0 END AS debit_ok',params:[PRICE,String(user.user_id)]},
   {sql:'INSERT INTO cheats_shop_inventory (user_id,item_id) VALUES ($1,$2)',params:[String(user.user_id),itemId]}
  ]);
 } catch(e) {
  const msg=String(e||'').toLowerCase();
  if(msg.includes('duplicate')||msg.includes('unique'))return res.status(409).json({error:'You already own this item.'});
  if(msg.includes('division')||msg.includes('zero')||msg.includes('balance')||msg.includes('check'))return res.status(402).json({error:'You need 50,000,000 Gobux to buy this item.'});
  return res.status(500).json({error:'Purchase failed. Your Gobux was not charged.'});
 }
 const wallet=await db.query('SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1 LIMIT 1',[String(user.user_id)]);
 return res.json({ok:true,item_id:itemId,name:item.name,effect:item.effect,price:PRICE,balance:wallet.rows[0]?.gobux_infinite?'∞':Number(wallet.rows[0]?.balance||0),message:'Purchased for 50,000,000 Gobux. This effect exists only inside Cheats’ fictional game.'});
}