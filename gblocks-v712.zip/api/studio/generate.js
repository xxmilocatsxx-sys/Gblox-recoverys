import { db } from "hatchable";

export const access = "public";
export const methods = ["POST"];

const enc = new TextEncoder();
function cookie(req, name) {
  if (req.cookies?.[name]) return String(req.cookies[name]);
  const raw = String(req.headers?.cookie || "");
  const m = raw.match(new RegExp("(?:^|;\\s*)" + name + "=([^;]*)"));
  return m ? decodeURIComponent(m[1]) : "";
}
async function hashToken(token, urlSafe=false) {
  const bytes = await crypto.subtle.digest("SHA-256", enc.encode(token));
  let out = btoa(String.fromCharCode(...new Uint8Array(bytes)));
  if (!urlSafe) return out;
  return out.split("+").join("-").split("/").join("_").replace(/=+$/,"");
}
async function getBetaAccess(req) {
  const releaseQ = await db.query("SELECT released,phase FROM gblocks_studio_release WHERE id=1");
  const release = releaseQ.rows[0] || { released:false, phase:"development" };
  const platformMember = req.member;
  if (platformMember) {
    const isAdmin = platformMember.role === "admin" || platformMember.role === "administrator";
    const handle = platformMember.handle || platformMember.username || "";
    const memberUserId = platformMember.id || platformMember.user_id || "";
    let profileUserId = "";
    if (handle) {
      const profile = await db.query("SELECT user_id FROM profiles WHERE lower(username)=lower($1) LIMIT 1", [handle]);
      profileUserId = profile.rows[0]?.user_id || "";
    }
    const resolvedUserId = profileUserId || memberUserId;
    if (release.phase === "general" && resolvedUserId) return { user_id: resolvedUserId, username: handle || "player" };
    if (isAdmin && profileUserId) return { user_id: profileUserId, username: handle || "admin" };
    // If the collaborator identity isn't a GBlocks player profile, continue to
    // the app's own session cookies instead of creating an orphaned game.
  }
  const gblocksToken = String(req.headers?.["x-gblocks-session"] || req.headers?.["X-Gblocks-Session"] || cookie(req,"gblocks_session") || "").trim();
  const legacyToken = String(cookie(req,"groblox_session") || "").trim();
  let q = { rows: [] };
  if (gblocksToken) {
    const hashes = [await hashToken(gblocksToken,false),await hashToken(gblocksToken,true)];
    q = await db.query("SELECT p.user_id,p.username,p.role,ps.active AS premium_active,ps.is_permanent AS premium_permanent,ps.expires_at AS premium_expires_at FROM gblocks_sessions s JOIN profiles p ON p.user_id=s.user_id LEFT JOIN premium_subscriptions ps ON ps.user_id=p.user_id AND ps.active=true WHERE s.token_hash=ANY($1::text[]) AND s.expires_at>NOW() LIMIT 1",[hashes]);
  }
  if (!q.rows[0] && legacyToken) {
    const hashes = [await hashToken(legacyToken,true),await hashToken(legacyToken,false)];
    q = await db.query("SELECT p.user_id,p.username,p.role,ps.active AS premium_active,ps.is_permanent AS premium_permanent,ps.expires_at AS premium_expires_at FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id LEFT JOIN premium_subscriptions ps ON ps.user_id=p.user_id AND ps.active=true WHERE s.token_hash=ANY($1::text[]) AND s.expires_at>NOW() LIMIT 1",[hashes]);
  }
  if (!q.rows[0]) return null;
  const u=q.rows[0], admin=u.role==="admin"||u.role==="administrator";
  const premium=!!u.premium_active&&(!!u.premium_permanent||!!u.premium_expires_at&&new Date(u.premium_expires_at).getTime()>Date.now());
  if (release.phase!=="general"&&!admin&&!premium) return null;
  return {user_id:u.user_id,username:u.username};
}
function clean(value,max){return typeof value==="string"?value.trim().slice(0,max):"";}
function hashText(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0;}
function makePlan(prompt){
  const lower=prompt.toLowerCase(), seed=hashText(prompt.toLowerCase());
  const themes=[
    {name:"Sky Harbor",palette:"sky",colors:["#1689d7","#7bdcff","#f6c453"],materials:["Cloudstone blocks","Skyglass","Brass trim"],props:["Wind turbines","Dock beacons","Floating cargo pods"]},
    {name:"Mosswild",palette:"forest",colors:["#397b54","#9ecb72","#c18a55"],materials:["Moss blocks","Pine timber","River glass"],props:["Giant mushrooms","Lantern posts","Stone arches"]},
    {name:"Emberworks",palette:"volcanic",colors:["#c94d36","#ffad42","#4b2530"],materials:["Basalt blocks","Ember glass","Copper piping"],props:["Steam vents","Cooling tanks","Forge cranes"]},
    {name:"Moonbase Delta",palette:"lunar",colors:["#788ca8","#9fe9ee","#8a72d6"],materials:["Lunar alloy","Reinforced glass","Glow panels"],props:["Solar arrays","Airlocks","Research beacons"]},
    {name:"Coral Circuit",palette:"ocean",colors:["#168c9a","#45d6c4","#ff7c9d"],materials:["Reefstone","Aqua glass","Pearl alloy"],props:["Coral towers","Submarine docks","Bubble lamps"]}
  ];
  const theme=themes[seed%themes.length];
  const title=prompt.length>54?prompt.slice(0,51).trimEnd()+"…":prompt;
  const rooms=["Arrival hub","Main objective area","Side route","Resource room"];
  if(/shop|store|market/.test(lower))rooms.push("Trading arcade");
  if(/castle|fort|base|tower/.test(lower))rooms.push("Command keep");
  if(/park|forest|garden|island/.test(lower))rooms.push("Wildlife garden");
  if(/race|speed|car|track/.test(lower))rooms.push("Challenge course");
  if(/secret|hidden|underground/.test(lower))rooms.push("Secret vault");
  if(/roof|sky|floating/.test(lower))rooms.push("High-altitude lookout");
  const dims=36+(seed%2)*4;
  const blocks=rooms.slice(0,10).map((name,i)=>{
    const col=i%3,row=Math.floor(i/3),w=4+((seed>>(i%16))%3),h=4+((seed>>(i%11))%3);
    return {type:"room",name,x:3+col*8+(seed+i)%2,y:3+row*8+(seed>>i)%2,width:w,height:h,levels:1+((seed+i)%3),style:(seed+i)%5};
  });
  const floors=1+(seed%3);
  return {title,concept:"An original "+theme.name+"-inspired world built around your idea: "+prompt.slice(0,220),dimensions:{width:dims,depth:dims,height:8+floors*4},floors,theme,rooms,materials:theme.materials,props:theme.props,gameplay:["Explore distinct routes and landmarks","Find the main objective in "+rooms[1],"Discover optional side areas","Reach the elevated lookout or hidden area"],steps:["Lay out the unique world footprint and spawn plaza.","Build each room with its own dimensions and elevation.","Connect rooms using paths, bridges, and open routes.","Add theme-specific props, lighting, and landmarks.","Playtest navigation on mobile and desktop."],blocks};
}
export default async function(req,res){
  const beta=await getBetaAccess(req);
  if(!beta||!beta.user_id)return res.status(403).json({error:"GBlocks Studio is currently available to Beta Testers+ (Admins and active Premium members)."});
  const prompt=clean(req.body?.prompt,4000);
  if(!prompt)return res.status(400).json({error:"Describe the building or game area you want to create."});
  const plan=makePlan(prompt);
  const gameData={version:3,generatedBy:"GBlocks Studio",mode:"studio-generated",randomMap:true,mapVersion:3,seed:hashText(prompt.toLowerCase()),theme:plan.theme,spawn:{x:16,y:16},world:{width:plan.dimensions.width,height:plan.dimensions.depth},floors:plan.floors,rooms:plan.rooms,materials:plan.materials,props:plan.props,gameplay:plan.gameplay,steps:plan.steps,blocks:plan.blocks};
  const created=await db.query("INSERT INTO games(name,description,players,icon,kit,game_data,creator_id) VALUES($1,$2,$3,$4,$5,$6::jsonb,$7) RETURNING id,name",[plan.title,plan.concept,"0","🧱","Studio",JSON.stringify(gameData),beta.user_id]);
  const game=created.rows[0];
  return res.json({ok:true,source:"built-in-original-generator",created:true,game:{id:game.id,name:game.name,url:"/game.html?id="+encodeURIComponent(game.id),playUrl:"/gblocks-3d.html?game="+encodeURIComponent(game.id)},plan,gameData,note:"Your original world has been saved as a GBlocks game."});
}