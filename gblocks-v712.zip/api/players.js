import { db } from "hatchable";
export const access="public";
export const methods=["GET"];
const te=new TextEncoder();
const bytesToB64=bytes=>btoa(String.fromCharCode(...bytes));
function tokenFrom(req){let t=req.headers?.["x-gblocks-session"]||req.headers?.["X-Gblocks-Session"]||null;if(t)return String(t).trim();t=req.cookies?.gblocks_session||null;try{return decodeURIComponent(t||"")}catch{return t||""}}
async function hashToken(token){return bytesToB64(new Uint8Array(await crypto.subtle.digest("SHA-256",te.encode(token))))}
export default async function(req,res){
 const token=tokenFrom(req);if(!token)return res.status(401).json({error:"Not signed in."});
 const me=await db.query("SELECT user_id FROM gblocks_sessions WHERE token_hash=$1 AND expires_at>NOW() LIMIT 1",[await hashToken(token)]);
 if(!me.rows.length)return res.status(401).json({error:"Not signed in."});
 const q=await db.query(`SELECT gp.user_id,
  CASE WHEN gp.deactivated_at IS NOT NULL THEN 'Account Deactivated' ELSE gp.username END AS username,
  CASE WHEN gp.deactivated_at IS NOT NULL THEN 'Account Deactivated' ELSE gp.display_name END AS display_name,
  CASE WHEN gp.deactivated_at IS NOT NULL THEN '' ELSE gp.bio END AS bio,
  CASE WHEN gp.deactivated_at IS NOT NULL THEN '{}'::jsonb ELSE gp.avatar END AS avatar,
  CASE WHEN gp.deactivated_at IS NOT NULL THEN 0 ELSE gp.gobux END AS gobux,
  p.verified,p.role,p.creator_role,
  CASE WHEN gp.deactivated_at IS NOT NULL THEN NULL ELSE p.last_seen_at END AS last_seen_at,
  CASE WHEN gp.deactivated_at IS NOT NULL THEN false ELSE (p.always_online OR (p.last_seen_at IS NOT NULL AND p.last_seen_at>NOW()-INTERVAL '5 minutes')) END AS online,
  gp.created_at,(gp.deactivated_at IS NOT NULL) AS deactivated
  FROM gblocks_players gp LEFT JOIN profiles p ON p.user_id=gp.user_id
  WHERE gp.moderation_status='active' AND gp.user_id<>$1 ORDER BY gp.created_at ASC LIMIT 100`,[me.rows[0].user_id]);
 return res.json({players:q.rows.map(p=>p.deactivated?{...p,verified:false,role:"member",creator_role:null}:p)});
}