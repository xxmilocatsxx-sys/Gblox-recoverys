import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access="public";
export const methods=["POST"];

export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});

  const username=String(req.body?.username||"").trim();
  const rawDate=String(req.body?.joinDate||"").trim();
  if(!username||!rawDate)return res.status(400).json({error:"Username and join date are required."});

  // Accept both the admin panel's datetime-local value and a plain YYYY-MM-DD date.
  // A plain date is interpreted as UTC midnight so the displayed calendar date cannot
  // shift because the server/runtime happens to use a different timezone.
  const parsed=/^\d{4}-\d{2}-\d{2}$/.test(rawDate)
    ? new Date(rawDate+"T00:00:00.000Z")
    : new Date(rawDate);
  if(Number.isNaN(parsed.getTime()))return res.status(400).json({error:"Invalid join date."});
  if(parsed.getTime()>Date.now())return res.status(400).json({error:"Join date cannot be in the future."});

  // Username casing is significant in Gblocks. Prefer an exact match so
  // "tubers93" and "Tubers93" are treated as two different accounts.
  let target=await db.query(
    "SELECT user_id,username,created_at FROM profiles WHERE username=$1",
    [username]
  );

  // For convenience, allow case-insensitive lookup only when it identifies exactly
  // one account. Never silently choose one of multiple differently-cased usernames.
  if(target.rows.length===0){
    const insensitive=await db.query(
      "SELECT user_id,username,created_at FROM profiles WHERE LOWER(username)=LOWER($1)",
      [username]
    );
    if(insensitive.rows.length===1) target=insensitive;
    else if(insensitive.rows.length>1){
      return res.status(409).json({
        error:"Multiple usernames differ only by capitalization. Enter the exact username.",
        code:"AMBIGUOUS_USERNAME"
      });
    }
  }

  if(!target.rows[0])return res.status(404).json({error:"User not found."});
  const t=target.rows[0];
  const newJoinDate=parsed.toISOString();

  // Keep the profile update and audit entry together. The admin identity uses admin_id,
  // not user_id, so audit_logs.actor_user_id must remain null for these admin accounts.
  await db.transaction([
    {
      sql:"UPDATE profiles SET created_at=$1 WHERE user_id=$2",
      params:[newJoinDate,t.user_id]
    },
    {
      sql:"INSERT INTO audit_logs (action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES ($1,$2,$3,$4,$5,$6,$7)",
      params:[
        "JOIN_DATE_CHANGED",
        t.user_id,
        t.username,
        null,
        admin.username,
        "Administrator changed profile join date",
        {old_join_date:t.created_at,new_join_date:newJoinDate}
      ]
    }
  ]);

  const verify=await db.query("SELECT created_at FROM profiles WHERE user_id=$1",[t.user_id]);
  const saved=verify.rows[0]?.created_at;
  return res.json({ok:true,username:t.username,joinDate:saved||newJoinDate});
}