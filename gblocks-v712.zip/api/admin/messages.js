import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access="public";
export const methods=["GET","POST"];
export default async function(req,res){
 const admin=await adminCaller(req);if(!admin)return res.status(403).json({error:"Administrator access required."});
 if(req.method==="GET"){
  const q=await db.query("SELECT id,recipient_username,sender_username,subject,body,read_at,created_at FROM admin_messages WHERE LOWER(recipient_username)=LOWER($1) ORDER BY created_at DESC LIMIT 100",[admin.username]);
  return res.json({messages:q.rows,unread:q.rows.filter(x=>!x.read_at).length});
 }
 const username=String(req.body?.recipient_username||"").trim();
 const subject=String(req.body?.subject||"").trim().slice(0,160);
 const body=String(req.body?.body||"").trim().slice(0,3000);
 if(!username||!subject||!body)return res.status(400).json({error:"Recipient, subject and message are required."});
 const r=await db.query("INSERT INTO admin_messages(recipient_username,sender_username,subject,body) VALUES($1,$2,$3,$4) RETURNING id,created_at",[username,admin.username,subject,body]);
 return res.status(201).json({ok:true,id:r.rows[0].id});
}