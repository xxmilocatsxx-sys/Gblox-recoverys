import { admin, db } from "hatchable";

export const access = "admin";
export const methods = ["POST"];

const encoder = new TextEncoder();

async function hashPassword(password, saltBytes) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: saltBytes, iterations: 120000, hash: "SHA-256" },
    key,
    256,
  );
  return Array.from(new Uint8Array(bits)).map(b => b.toString(16).padStart(2, "0")).join("");
}

export default async function (req, res) {
  const allowed = await admin.require(req, res);
  if (!allowed) return;

  const username = String(req.body?.username ?? "").trim();
  const password = String(req.body?.password ?? "");

  if (!/^[A-Za-z0-9_]{3,24}$/.test(username)) {
    return res.status(400).json({ error: "Enter a valid GBLOCKS username." });
  }
  if (password.length < 8 || password.length > 128) {
    return res.status(400).json({ error: "Password must be 8–128 characters." });
  }

  const found = await db.query(
    "SELECT user_id, username FROM profiles WHERE LOWER(username)=LOWER($1)",
    [username],
  );
  if (!found.rows.length) {
    return res.status(404).json({ error: "That GBLOCKS account does not exist." });
  }

  const salt = crypto.getRandomValues(new Uint8Array(16));
  const saltText = Array.from(salt).map(b => b.toString(16).padStart(2, "0")).join("");
  const passwordHash = await hashPassword(password, salt);

  await db.transaction([
    {
      sql: "UPDATE profiles SET role='administrator', banned=false WHERE user_id=$1",
      params: [found.rows[0].user_id],
    },
    {
      sql: `INSERT INTO account_credentials (user_id,password_salt,password_hash,recovery_code_hash,updated_at)
            VALUES ($1,$2,$3,NULL,NOW())
            ON CONFLICT (user_id) DO UPDATE SET
              password_salt=EXCLUDED.password_salt,
              password_hash=EXCLUDED.password_hash,
              recovery_code_hash=NULL,
              updated_at=NOW()`,
      params: [found.rows[0].user_id, saltText, passwordHash],
    },
    { sql: "DELETE FROM account_sessions WHERE user_id=$1", params: [found.rows[0].user_id] },
    { sql: "DELETE FROM passkey_credentials WHERE user_id=$1", params: [found.rows[0].user_id] },
    { sql: "DELETE FROM passkey_challenges WHERE user_id=$1", params: [found.rows[0].user_id] },
  ]);

  res.json({ ok: true, username: found.rows[0].username, role: "administrator" });
}