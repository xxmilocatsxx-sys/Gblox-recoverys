import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";

export const access = "public";
export const methods = ["GET", "POST"];

export default async function(req, res) {
  const admin = await adminCaller(req);
  if (!admin) return res.status(401).json({ error: "Administrator login required.", code: "NOT_SIGNED_IN" });
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, private");

  if (req.method === "GET") {
    const rows = await db.query(`
      SELECT r.username, r.reserved_for_user_id AS user_id, r.reason, r.created_at,
             p.username AS current_username, p.terminated
      FROM username_reservations r
      JOIN profiles p ON p.user_id = r.reserved_for_user_id
      WHERE p.terminated = true
        AND (LOWER(r.reason) LIKE '%terminated%' OR LOWER(r.reason) LIKE '%termination%')
      ORDER BY r.created_at DESC
      LIMIT 250
    `);
    return res.json({ ok: true, usernames: rows.rows || [] });
  }

  const username = String(req.body?.username || "").trim();
  const reason = String(req.body?.reason || "").trim().slice(0, 500);
  const confirmation = String(req.body?.confirmation || "").trim();
  if (!username) return res.status(400).json({ error: "Enter the exact reserved username." });
  if (confirmation.toLowerCase() !== username.toLowerCase()) return res.status(400).json({ error: "Type the exact username to confirm release." });
  if (!reason) return res.status(400).json({ error: "A reason is required for the audit log." });

  const reservation = await db.query(`
    SELECT r.username, r.reserved_for_user_id AS user_id, r.reason, p.username AS current_username, p.terminated
    FROM username_reservations r
    JOIN profiles p ON p.user_id = r.reserved_for_user_id
    WHERE LOWER(r.username) = LOWER($1)
      AND p.terminated = true
      AND (LOWER(r.reason) LIKE '%terminated%' OR LOWER(r.reason) LIKE '%termination%')
    LIMIT 1
  `, [username]);
  if (!reservation.rows[0]) return res.status(404).json({ error: "No releasable terminated-account username reservation was found. Active accounts and ordinary username history cannot be released with this tool." });

  const item = reservation.rows[0];
  const otherOwner = await db.query(`
    SELECT user_id FROM profiles WHERE LOWER(username)=LOWER($1) AND user_id<>$2
    UNION
    SELECT user_id FROM gblocks_players WHERE LOWER(username)=LOWER($1) AND user_id<>$2
    LIMIT 1
  `, [item.username, String(item.user_id)]);
  if (otherOwner.rows.length) return res.status(409).json({ error: "That username is now used by another account. Nothing was changed." });

  await db.transaction([
    { sql: "DELETE FROM username_reservations WHERE LOWER(username)=LOWER($1) AND reserved_for_user_id=$2", params: [item.username, String(item.user_id)] },
    { sql: "DELETE FROM username_history WHERE LOWER(username)=LOWER($1) AND user_id=$2", params: [item.username, String(item.user_id)] },
    { sql: "UPDATE gblocks_players SET username_history=COALESCE((SELECT jsonb_agg(entry.value) FROM jsonb_array_elements_text(COALESCE(username_history,'[]'::jsonb)) AS entry(value) WHERE LOWER(entry.value)<>LOWER($1)),'[]'::jsonb) WHERE user_id=$2", params: [item.username, String(item.user_id)] },
    { sql: "INSERT INTO audit_logs (action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)", params: ["USERNAME_RELEASED", String(item.user_id), item.username, String(admin.admin_id || admin.user_id || ""), String(admin.username || "Administrator"), reason, JSON.stringify({ releasedUsername: item.username, reservationReason: item.reason, currentUsername: item.current_username })] }
  ]);

  return res.json({ ok: true, released: item.username, message: 'Released "' + item.username + '". It can now be claimed by an eligible account.', userId: String(item.user_id) });
}