import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access="public";
export const methods=["GET","POST","DELETE"];

export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(403).json({error:"Administrator access required."});

  if(req.method==="GET"){
    const q=await db.query("SELECT id,title,body,updated_at,updated_by FROM gblocks_announcements ORDER BY updated_at DESC LIMIT 1");
    return res.json({announcement:q.rows[0]||null});
  }

  if(req.method==="DELETE"){
    await db.query("DELETE FROM gblocks_announcements");
    return res.json({ok:true,announcement:null,message:"GBlocks announcement removed."});
  }

  const title=String(req.body?.title||"").trim().slice(0,120);
  const body=String(req.body?.body||"").trim().slice(0,2000);
  if(!title||!body)return res.status(400).json({error:"Announcement title and message are required."});

  const existing=await db.query("SELECT id FROM gblocks_announcements ORDER BY updated_at DESC LIMIT 1");
  if(existing.rows[0]){
    const u=await db.query(
      "UPDATE gblocks_announcements SET title=$1,body=$2,updated_at=NOW(),updated_by=$3 WHERE id=$4 RETURNING id,title,body,updated_at,updated_by",
      [title,body,admin.username,existing.rows[0].id]
    );
    return res.json({ok:true,announcement:u.rows[0],message:"GBlocks announcement updated."});
  }

  const q=await db.query(
    "INSERT INTO gblocks_announcements(title,body,updated_at,updated_by) VALUES($1,$2,NOW(),$3) RETURNING id,title,body,updated_at,updated_by",
    [title,body,admin.username]
  );
  return res.status(201).json({ok:true,announcement:q.rows[0],message:"GBlocks announcement published."});
}