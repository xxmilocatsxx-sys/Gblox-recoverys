import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access="public";
export const methods=["GET","POST"];
export default async function(req,res){
 const admin=await adminCaller(req);
 if(!admin)return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});
 if(req.method==="GET"){
  const q=await db.query(`SELECT COALESCE(p.user_id,g.user_id) AS user_id,
   p.user_number AS user_number,
   COALESCE(p.username,g.username) AS username,
   COALESCE(p.display_name,g.display_name) AS display_name,
   COALESCE(p.created_at,g.created_at) AS created_at,
   COALESCE(p.deactivated_at,g.deactivated_at) AS deactivated_at,
   COALESCE(p.recovery_deadline,g.recovery_deadline) AS recovery_deadline,
   COALESCE(p.legacy_status,g.legacy_status,'active') AS legacy_status,
   CASE WHEN COALESCE(p.recovery_deadline,g.recovery_deadline)<=NOW() THEN true ELSE false END AS eligible_for_legacy_review
   FROM profiles p FULL JOIN gblocks_players g ON g.user_id=p.user_id
   WHERE COALESCE(p.deactivated_at,g.deactivated_at) IS NOT NULL
   ORDER BY COALESCE(p.deactivated_at,g.deactivated_at) DESC`);
  return res.json({ok:true,accounts:q.rows});
 }
 const userId=String(req.body?.user_id||"").trim(),action=String(req.body?.action||"");
 if(!userId||action!=="mark_reviewed")return res.status(400).json({error:"Invalid review action."});
 const t=await db.query("SELECT COALESCE(p.username,g.username) AS username,COALESCE(p.display_name,g.display_name) AS display_name,COALESCE(p.deactivated_at,g.deactivated_at) AS deactivated_at,COALESCE(p.recovery_deadline,g.recovery_deadline) AS recovery_deadline FROM profiles p FULL JOIN gblocks_players g ON g.user_id=p.user_id WHERE COALESCE(p.user_id,g.user_id)=$1 LIMIT 1",[userId]);
 if(!t.rows[0]||!t.rows[0].deactivated_at)return res.status(404).json({error:"Deactivated account not found."});
 if(!t.rows[0].recovery_deadline||new Date(t.rows[0].recovery_deadline)>new Date())return res.status(409).json({error:"This account has not reached the two-year Legacy Review threshold."});
 await db.query("UPDATE profiles SET legacy_status='legacy_review',legacy_reviewed_at=NOW() WHERE user_id=$1",[userId]);
 await db.query("UPDATE gblocks_players SET legacy_status='legacy_review',legacy_reviewed_at=NOW(),updated_at=NOW() WHERE user_id=$1",[userId]);
 await db.query("INSERT INTO gblocks_account_deactivation_history(user_id,action,username_snapshot,display_name_snapshot,deactivated_at,recovery_deadline) VALUES($1,'legacy_reviewed',$2,$3,$4,$5)",[userId,t.rows[0].username||"",t.rows[0].display_name||"",t.rows[0].deactivated_at,t.rows[0].recovery_deadline]);
 return res.json({ok:true,message:"Account marked Eligible for Legacy Review. No account data was deleted."});
}