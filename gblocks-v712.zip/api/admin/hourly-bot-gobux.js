import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";

export const access = "public";
export const methods = ["GET", "POST"];

function sameOrigin(req) {
  const origin = String(req.headers?.origin || "");
  return !origin || origin === "https://gblocks.hatchable.site";
}

export default async function(req, res) {
  const actor = await adminCaller(req);
  if (!actor) return res.status(401).json({ error: "Administrator login required." });
  if (!sameOrigin(req)) return res.status(403).json({ error: "Cross-origin request blocked." });

  if (req.method === "POST") {
    const enabled = req.body?.enabled;
    if (typeof enabled !== "boolean") return res.status(400).json({ error: "enabled must be true or false." });
    await db.query(
      "UPDATE gobux_hourly_reward_settings SET enabled=$1,updated_by=$2,updated_at=NOW() WHERE id=1",
      [enabled, String(actor.username || actor.admin_id)]
    );
    await db.query(
      "INSERT INTO audit_logs (action,actor_user_id,actor_username,reason,details) VALUES ($1,$2,$3,$4,$5::jsonb)",
      [enabled ? "hourly_bot_gobux_enabled" : "hourly_bot_gobux_disabled", String(actor.admin_id || actor.user_id || ""), String(actor.username || ""), enabled ? "Enabled automatic hourly bot Gobux rewards" : "Disabled automatic hourly bot Gobux rewards", JSON.stringify({ enabled })]
    );
  } else if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed." });
  }

  const stateResult = await db.query(
    "SELECT enabled,reward_amount,updated_by,updated_at,created_at FROM gobux_hourly_reward_settings WHERE id=1"
  );
  const state = stateResult.rows[0];
  if (!state) return res.status(503).json({ error: "Hourly reward settings are not initialized." });

  const [last, next, history] = await Promise.all([
    db.query("SELECT MAX(completed_at) AS last_successful_payout FROM gobux_hourly_reward_runs WHERE status='completed'"),
    db.query("SELECT date_trunc('hour',NOW()) + CASE WHEN EXTRACT(MINUTE FROM NOW()) < 5 THEN INTERVAL '5 minutes' ELSE INTERVAL '1 hour 5 minutes' END AS next_scheduled_payout"),
    db.query("SELECT user_id,username,period_start,amount,status,transaction_id,created_at,credited_at FROM gobux_hourly_reward_ledger ORDER BY period_start DESC,username ASC LIMIT 50")
  ]);

  return res.json({
    ok: true,
    enabled: Boolean(state.enabled),
    reward_amount: String(state.reward_amount),
    updated_by: state.updated_by,
    updated_at: state.updated_at,
    last_successful_payout: last.rows[0]?.last_successful_payout || null,
    next_scheduled_payout: next.rows[0]?.next_scheduled_payout || null,
    history: history.rows
  });
}