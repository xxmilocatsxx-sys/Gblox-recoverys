import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";

export const access = "public";
export const methods = ["POST"];

export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({error:"Administrator username and password required",code:"NOT_SIGNED_IN"});
  const action=String(req.body?.action||"release_studio");
  if(action!=="release_studio" && action!=="beta_tester_update"){
    return res.status(400).json({error:"Unknown Studio release action."});
  }

  if(action==="release_studio"){
    const q=await db.query("SELECT release_number FROM gblocks_studio_release WHERE id=1");
    const releaseNumber=Number(q.rows[0]?.release_number||0)+1;
    await db.query(
      "UPDATE gblocks_studio_release SET released=true,phase='beta',release_number=$1,beta_update_count=0,updated_at=NOW() WHERE id=1",
      [releaseNumber]
    );
    return res.json({ok:true,released:true,phase:"beta",releaseNumber,betaUpdateCount:0,requiredBetaUpdates:2});
  }

  const caller=await adminCaller(req);
  if(!caller)return res.status(401).json({error:"Administrator username and password required",code:"NOT_SIGNED_IN"});
  const q=await db.query("SELECT released,phase,release_number,beta_update_count FROM gblocks_studio_release WHERE id=1");
  const r=q.rows[0]||{released:false,phase:"development",release_number:0,beta_update_count:0};
  if(!r.released || r.phase!=="beta"){
    return res.status(409).json({error:"Studio is not currently in the Beta Tester release phase."});
  }
  const completed=Number(r.beta_update_count)+1;
  const phase=completed>=2 ? "general" : "beta";
  await db.query(
    "UPDATE gblocks_studio_release SET beta_update_count=$1,phase=$2,updated_at=NOW() WHERE id=1",
    [completed,phase]
  );
  return res.json({ok:true,released:true,phase,betaUpdateCount:completed,requiredBetaUpdates:2});
}