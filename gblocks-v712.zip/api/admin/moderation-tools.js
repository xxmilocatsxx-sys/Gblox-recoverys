import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import { clientIp, hashIp } from "../../lib/ip-restrictions.js";
import { sendConfiguredDiscordEvent } from "../../lib/discord-webhooks.js";
export const access = "public";
export const methods = ["GET", "POST", "DELETE"];
const text = (v,n=1000)=>String(v??"").trim().slice(0,n);
async function audit(actor, action, targetId, username, reason, details={}) {
  await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",
    [action,targetId||null,username||null,String(actor.user_id||actor.admin_id),text(actor.username,100),text(reason,1000),JSON.stringify(details)]);
}
function validIp(ip) {
  if (!ip || ip.length>64 || /[,\s]/.test(ip)) return false;
  const s=ip.toLowerCase().replace(/^::ffff:/,"");
  const v4=s.split(".");
  if(v4.length===4) return v4.every(x=>/^\d{1,3}$/.test(x)&&Number(x)>=0&&Number(x)<=255);
  return s.includes(":") && /^[0-9a-f:]+$/.test(s) && s.split(":").length<=8;
}
export default async function(req,res){
  const actor=await adminCaller(req);
  if(!actor) return res.status(401).json({error:"Administrator login required."});
  if(actor.is_bot) return res.status(403).json({error:"Bot accounts cannot use bulk moderation tools."});
  const method=String(req.method||"GET").toUpperCase();
  const body=req.body||{};
  const action=text(body.action||req.query?.action,50).toLowerCase();
  if(action==="ip_list"){
    const result=await db.query("SELECT ip_hash,ip_label,reason,created_by_username,created_at,expires_at FROM gblox_ip_restrictions WHERE revoked_at IS NULL AND (expires_at IS NULL OR expires_at>NOW()) ORDER BY created_at DESC LIMIT 200");
    return res.json({ok:true,restrictions:result.rows.map(x=>({...x,ip_hash:undefined}))});
  }
  if(method==="GET" || action==="preview"){
    const result=await db.query("SELECT user_id,username,display_name,moderation_status FROM gblocks_players ORDER BY username LIMIT 2000");
    return res.json({ok:true,accounts:result.rows});
  }
  if(action==="ip_ban"){
    const ip=text(body.ip,64).toLowerCase().replace(/^::ffff:/,"");
    const reason=text(body.reason,1000), expires=text(body.expires_at,80);
    if(!validIp(ip)) return res.status(400).json({error:"Enter a valid IPv4 or IPv6 address."});
    if(!reason) return res.status(400).json({error:"A reason is required."});
    const expiry=expires?new Date(expires):null;
    if(expires&&(!expiry||!Number.isFinite(expiry.getTime())||expiry<=new Date())) return res.status(400).json({error:"Expiration must be a future date."});
    const ipHash=await hashIp(ip);
    const sessions=await db.query("SELECT DISTINCT user_id FROM gblox_login_ip_history WHERE ip_hash=$1",[ipHash]);
    const userIds=sessions.rows.map(x=>String(x.user_id));
    const username=String(actor.username||actor.user_id||"administrator");
    await db.query("INSERT INTO gblox_ip_restrictions(ip_hash,ip_label,reason,created_by_user_id,created_by_username,expires_at,revoked_at) VALUES($1,$2,$3,$4,$5,$6,NULL) ON CONFLICT(ip_hash) DO UPDATE SET ip_label=EXCLUDED.ip_label,reason=EXCLUDED.reason,created_by_user_id=EXCLUDED.created_by_user_id,created_by_username=EXCLUDED.created_by_username,created_at=NOW(),expires_at=EXCLUDED.expires_at,revoked_at=NULL,revoked_by_user_id=NULL",[ipHash,ip,reason,String(actor.user_id||actor.admin_id),username,expiry]);
    // Preview the shared-network impact and terminate only currently known sessions; never permanently ban each account.
    for(const uid of userIds){
      await db.query("DELETE FROM account_sessions WHERE user_id=$1",[uid]).catch(()=>{});
      await db.query("DELETE FROM gblocks_sessions WHERE user_id=$1",[uid]).catch(()=>{});
    }
    await audit(actor,"IP_RESTRICT",null,null,reason,{ipHash,affectedSessionsRevoked:userIds.length,expiresAt:expiry?.toISOString()||null});
    return res.json({ok:true,affectedSessionsRevoked:userIds.length,warning:"IP restriction applies to this network address. Shared-network users may be affected; accounts were not permanently banned."});
  }
  if(action==="ip_unban"){
    const ip=text(body.ip,64).toLowerCase().replace(/^::ffff:/,"");
    if(!validIp(ip)) return res.status(400).json({error:"Enter a valid IPv4 or IPv6 address."});
    const ipHash=await hashIp(ip);
    await db.query("UPDATE gblox_ip_restrictions SET revoked_at=NOW(),revoked_by_user_id=$2 WHERE ip_hash=$1 AND revoked_at IS NULL",[ipHash,String(actor.user_id||actor.admin_id)]);
    await audit(actor,"IP_UNRESTRICT",null,null,text(body.reason||"IP restriction removed"),{ipHash});
    return res.json({ok:true,message:"IP restriction removed."});
  }
  if(action==="mass_unban"){
    const ids=[...new Set((Array.isArray(body.user_ids)?body.user_ids:[]).map(x=>text(x,120)).filter(Boolean))].slice(0,10);
    if(!ids.length) return res.status(400).json({error:"Select at least one account to restore."});
    if(ids.includes(String(actor.user_id||actor.admin_id))) return res.status(400).json({error:"Your own account cannot be targeted."});
    const players=await db.query("SELECT user_id,username,moderation_status FROM gblocks_players WHERE user_id=ANY($1::text[])",[ids]);
    const profiles=await db.query("SELECT user_id,username,role,banned,terminated,is_bot FROM profiles WHERE user_id=ANY($1::text[])",[ids]);
    const byId=new Map();
    for(const p of [...profiles.rows,...players.rows]) { const id=String(p.user_id); byId.set(id,{...(byId.get(id)||{}),...p}); }
    const found=ids.filter(id=>byId.has(id));
    const protectedRows=[],eligible=[];
    for(const id of found){
      const p=byId.get(id),name=String(p.username||"");
      const isClaudeTestAccount=/^ClaudeBot(?:_\d+)?$/i.test(name);
      if(name.toLowerCase()==="claude" || p.role==="administrator" || name.toLowerCase()==="gblox" || (p.is_bot===true && !isClaudeTestAccount)){
        protectedRows.push({user_id:id,username:p.username,ok:false,error:"Protected account"});
      } else if(!isClaudeTestAccount) {
        protectedRows.push({user_id:id,username:p.username,ok:false,error:"Bulk restore is limited to generated ClaudeBot test accounts"});
      } else eligible.push({user_id:id,username:name});
    }
    const successes=[];
    for(const target of eligible){
      try{
        await db.transaction([
          {sql:"UPDATE gblocks_players SET moderation_status='active',moderation_note='',temp_ban_until=NULL,username_reset_on_unban=false WHERE user_id=$1",params:[target.user_id]},
          {sql:"UPDATE profiles SET banned=false,terminated=false,ban_note='',temp_ban_until=NULL,username_reset_on_unban=false WHERE user_id=$1",params:[target.user_id]},
          {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES('UNBAN',$1,$2,$3,$4,'Bulk restore ClaudeBot test account',$5::jsonb)",params:[target.user_id,target.username,String(actor.user_id||actor.admin_id),text(actor.username,100),JSON.stringify({bulk:true,source:"mass_unban"})]}
        ]);
        successes.push({...target,ok:true,action:"active"});
      }catch(e){
        protectedRows.push({...target,ok:false,error:"Restore failed: "+text(e?.message||e,160)});
      }
    }
    let discordSent=0,discordFailed=0;
    for(const target of successes){
      try{
        const result=await sendConfiguredDiscordEvent("UNBAN",{title:"GBLOX LOGS • MASS UNBAN",color:0x22c55e,fields:[
          {name:"Username",value:String(target.username).slice(0,256)},
          {name:"User ID",value:"GBlocks User #"+String(target.user_id)},
          {name:"Moderator",value:text(actor.username||actor.user_id,256)},
          {name:"Status",value:"UNBANNED / ACTIVE"}
        ],timestamp:new Date().toISOString(),footer:{text:"GBLOX Logs • Bulk restore"}});
        discordSent+=Number(result?.sent||0);discordFailed+=Number(result?.failed||0);
      }catch(e){discordFailed++;console.error("GBLOX mass unban Discord log failed",text(e?.message||e,180));}
    }
    const results=[...successes,...protectedRows];
    return res.json({ok:protectedRows.length===0,requested:ids.length,processed:results.length,successes:successes.length,failures:protectedRows,results,discord:{sent:discordSent,failed:discordFailed}});
  }
  if(action==="mass_ban" || action==="mass_terminate" || action==="terminate_linked"){
    // Keep each request below the project DB query budget; the admin UI submits mass bans in small sequential batches.
    const ids=[...new Set((Array.isArray(body.user_ids)?body.user_ids:[]).map(x=>text(x,120)).filter(Boolean))].slice(0,10);
    if(action==="terminate_linked" && !ids.length) return res.status(400).json({error:"Choose a primary account."});
    if(!ids.length) return res.status(400).json({error:"Select at least one account."});
    const reason=text(body.reason,1000);
    if(!reason) return res.status(400).json({error:"A moderation reason is required."});
    const primary=ids[0];
    let targets=ids;
    if(action==="terminate_linked"){
      const linked=await db.query("SELECT DISTINCT linked_account_id AS user_id FROM gblox_account_links WHERE account_id=$1 UNION SELECT DISTINCT account_id AS user_id FROM gblox_account_links WHERE linked_account_id=$1",[primary]);
      targets=[...new Set([primary,...linked.rows.map(x=>String(x.user_id))])].slice(0,100);
    }
    if(targets.includes(String(actor.user_id||actor.admin_id))) return res.status(400).json({error:"Your own account cannot be targeted."});
    const players=await db.query("SELECT user_id,username,moderation_status FROM gblocks_players WHERE user_id=ANY($1::text[])",[targets]);
    const profiles=await db.query("SELECT user_id,username,role,banned,terminated,is_bot FROM profiles WHERE user_id=ANY($1::text[])",[targets]);
    const byId=new Map();
    for(const p of [...profiles.rows,...players.rows]) { const id=String(p.user_id); byId.set(id,{...(byId.get(id)||{}),...p}); }
    const found=targets.filter(id=>byId.has(id));
    if(!found.length) return res.status(404).json({error:"No matching player accounts found."});
    if(action==="terminate_linked" && body.preview===true){
      return res.json({ok:true,targets:found.map(id=>({user_id:id,username:byId.get(id)?.username||id})),count:found.length});
    }
    const isTerminate=action==="terminate_linked" || action==="mass_terminate";
    const status=isTerminate?"terminated":"banned";
    const until=(!isTerminate && Number.isInteger(Number(body.duration_days)) && Number(body.duration_days)>0)?new Date(Date.now()+Math.min(365,Number(body.duration_days))*86400000):null;
    const durationDays=isTerminate?0:(until?Math.max(1,Number(body.duration_days)):0);
    const protectedRows=[],eligible=[];
    for(const id of found){
      const p=byId.get(id),name=String(p.username||"");
      const isClaudeTestAccount=/^ClaudeBot(?:_\d+)?$/i.test(name);
      if(name.toLowerCase()==="claude" || p.role==="administrator" || name.toLowerCase()==="gblox" || (p.is_bot===true && !isClaudeTestAccount)){
        protectedRows.push({user_id:id,username:p.username,ok:false,error:"Protected account"});
      } else eligible.push({user_id:id,username:p.username||null,hasPlayer:players.rows.some(x=>String(x.user_id)===id),hasProfile:profiles.rows.some(x=>String(x.user_id)===id)});
    }
    if(!eligible.length){
      return res.json({ok:false,requested:targets.length,processed:protectedRows.length,successes:0,failures:protectedRows,results:protectedRows});
    }
    const eligibleIds=eligible.map(x=>x.user_id);
    const actorId=String(actor.user_id||actor.admin_id);
    const actorName=text(actor.username,100);
    const auditAction=isTerminate?"TERMINATE":"BAN";
    const auditDetails=JSON.stringify({bulk:true,moderationTool:action,expiresAt:until?.toISOString()||null});
    // Use set-based SQL: a batch now needs a fixed number of queries, not several queries per account.
    const writes=[
      {sql:"UPDATE gblocks_players SET moderation_status=$1,moderation_note=$2,temp_ban_until=$3,moderation_last_action=NOW(),moderation_violation_count=moderation_violation_count+1,last_ban_duration_days=$4 WHERE user_id=ANY($5::text[])",params:[status,reason,until,durationDays,eligibleIds]},
      {sql:"UPDATE profiles SET banned=$1,terminated=$2,ban_note=$3,temp_ban_until=$4,verified=false,last_ban_duration_days=$5 WHERE user_id=ANY($6::text[])",params:[!isTerminate,isTerminate,reason,until,durationDays,eligibleIds]},
      {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) SELECT $1,x.user_id,x.username,$2,$3,$4,$5::jsonb FROM jsonb_to_recordset($6::jsonb) AS x(user_id text,username text)",params:[auditAction,actorId,actorName,reason,auditDetails,JSON.stringify(eligible)]}
    ];
    try {
      await db.transaction(writes);
    } catch(e) {
      const msg=String(e?.message||e).slice(0,180);
      const failures=[...protectedRows,...eligible.map(x=>({...x,ok:false,error:"Database update failed: "+msg}))];
      return res.status(500).json({ok:false,requested:targets.length,processed:failures.length,successes:0,failures,results:failures});
    }
    // Optional legacy cleanup is bulked and best-effort; absent legacy tables must not undo the status update.
    if(isTerminate){
      const named=eligible.filter(x=>x.username);
      if(named.length){
        await db.query("INSERT INTO username_history(username,user_id) SELECT x.username,x.user_id FROM jsonb_to_recordset($1::jsonb) AS x(username text,user_id text) WHERE NOT EXISTS (SELECT 1 FROM username_history h WHERE LOWER(h.username)=LOWER(x.username) AND h.user_id=x.user_id)",[JSON.stringify(named)]).catch(()=>null);
        await db.query("INSERT INTO username_reservations(username,reserved_for_user_id,reason) SELECT x.username,x.user_id,'terminated_account' FROM jsonb_to_recordset($1::jsonb) AS x(username text,user_id text) ON CONFLICT(username) DO NOTHING",[JSON.stringify(named)]).catch(()=>null);
      }
      await db.query("DELETE FROM account_sessions WHERE user_id=ANY($1::text[])",[eligibleIds]).catch(()=>null);
      await db.query("DELETE FROM gblocks_sessions WHERE user_id=ANY($1::text[])",[eligibleIds]).catch(()=>null);
    } else {
      await db.query("DELETE FROM account_sessions WHERE user_id=ANY($1::text[])",[eligibleIds]).catch(()=>null);
      await db.query("DELETE FROM gblocks_sessions WHERE user_id=ANY($1::text[])",[eligibleIds]).catch(()=>null);
    }
    // Send one Discord event per account so mass moderation is visible in the same channel as single-account actions.
    let discordSent=0,discordFailed=0;
    for(const target of eligible){
      try {
        const event=isTerminate?"TERMINATE":"BAN";
        const result=await sendConfiguredDiscordEvent(event,{
          title:isTerminate?"GBLOX • MASS TERMINATE":"GBLOX • MASS BAN",
          color:isTerminate?0xFF334F:0xFF6B35,
          fields:[
            {name:"Username",value:String(target.username||target.user_id||"Unknown").slice(0,256)},
            {name:"User ID",value:"GBlocks User #"+String(target.user_id)},
            {name:"Moderator",value:String(actorName||"Administrator").slice(0,256)},
            {name:"Status",value:isTerminate?"TERMINATED":(until?"TEMPORARILY BANNED":"BANNED")},
            {name:"Reason",value:String(reason||"GBLOX rules violation").slice(0,1000)},
            {name:"Duration",value:isTerminate?"Permanent termination":(until?String(durationDays)+" day(s)":"Permanent ban")}
          ],timestamp:new Date().toISOString(),footer:{text:"GBLOX Logs • Bulk moderation"}
        });
        discordSent+=Number(result?.sent||0); discordFailed+=Number(result?.failed||0);
      } catch(e) { discordFailed++; console.error("GBLOX mass moderation Discord log failed",String(e?.message||e).slice(0,180)); }
    }
    const successes=eligible.map(x=>({...x,ok:true,action:status}));
    const results=[...successes,...protectedRows];
    return res.json({ok:protectedRows.length===0,requested:targets.length,processed:results.length,successes:successes.length,failures:protectedRows,results,discord:{sent:discordSent,failed:discordFailed}});
  }
  return res.status(400).json({error:"Unsupported moderation tool action."});
}