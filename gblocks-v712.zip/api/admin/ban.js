import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import { checkModerationUsername } from "../../lib/moderation-policy.js";
import { sendConfiguredDiscordEvent } from "../../lib/discord-webhooks.js";

async function logSuccessfulUnban(player, admin, newUsername) {
 const wasModerated = player?.banned === true || player?.terminated === true || ["banned","terminated"].includes(String(player?.moderation_status||"").toLowerCase());
 if (!wasModerated) return;
 try {
  const countRow = await db.query("INSERT INTO gblocks_unban_counts(user_id,unban_count,updated_at) VALUES($1,1,NOW()) ON CONFLICT(user_id) DO UPDATE SET unban_count=gblocks_unban_counts.unban_count+1,updated_at=NOW() RETURNING unban_count",[String(player.user_id)]);
  const profile = (await db.query("SELECT user_number FROM profiles WHERE user_id=$1 LIMIT 1",[String(player.user_id)])).rows[0] || {};
  const publicId = String(profile.user_number || player.user_number || player.user_id);
  const profileUrl = "https://gblocks.hatchable.site/profile.html?userid=" + encodeURIComponent(String(player.user_id));
  const count = Number(countRow.rows[0]?.unban_count || 1);
  const embed = {title:"GBLOCKS LOGS • UNBAN",color:0x22c55e,fields:[
   {name:"Username",value:"["+String(newUsername||player.username||"Unknown").slice(0,180)+"](<"+profileUrl+">)",inline:false},
   {name:"User ID",value:"GBlocks User #"+publicId,inline:false},
   {name:"Moderator",value:String(admin.username||admin.user_id||"Unknown").slice(0,256),inline:false},
   {name:"Status",value:"UNBANNED",inline:false},
   {name:"Unban Count",value:"Unban "+count,inline:false}
  ],timestamp:new Date().toISOString(),footer:{text:"GBLOCKS Logs"}};
  await sendConfiguredDiscordEvent("UNBAN",embed);
 } catch (err) { console.error("Managed Discord UNBAN log failed",String(err?.message||err).slice(0,200)); }
}

export const access="public";
export const methods=["POST"];

function safeDays(v){
 const n=Number(v);
 return Number.isInteger(n)&&n>=2&&n<=7?n:3;
}

export default async function(req,res){
 const admin=await adminCaller(req);
 if(!admin)return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});
 const isCheckerBot=admin.is_bot===true;
 const targetUserId=String(req.body?.target_user_id||"").trim();
 const username=String(req.body?.username||"").trim();
 const action=String(req.body?.action||"banned").toLowerCase();
 if(!targetUserId&&!username)return res.status(400).json({error:"Select a GBlocks player account."});

 let target={rows:[]};
 let p=null;
 if(targetUserId){
   target=await db.query("SELECT * FROM gblocks_players WHERE user_id=$1 LIMIT 1",[targetUserId]);
   if(target.rows[0]) p=target.rows[0];
   if(!p){
     const legacy=await db.query("SELECT * FROM profiles WHERE user_id=$1 LIMIT 1",[targetUserId]);
     if(legacy.rows[0]) p={...legacy.rows[0],_legacy:true};
   }
 }
 // Always allow the username to rescue a stale/mismatched numeric ID.
 if(!p&&username){
   target=await db.query("SELECT * FROM gblocks_players WHERE LOWER(username)=LOWER($1) LIMIT 1",[username]);
   if(target.rows[0]) p=target.rows[0];
   if(!p){
     const legacy=await db.query("SELECT * FROM profiles WHERE LOWER(username)=LOWER($1) LIMIT 1",[username]);
     if(legacy.rows[0]) p={...legacy.rows[0],_legacy:true};
   }
 }
 if(!p)return res.status(404).json({error:"GBlocks player account not found."});
 if(String(p.user_id)===String(admin.user_id))return res.status(400).json({error:"You cannot moderate your own account."});
 const moderatorNote=String(req.body?.moderator_note||"").trim().slice(0,2000);
 if(action!=="unbanned"&&action!=="unban"&&action!=="restore"&&!isCheckerBot&&!moderatorNote)return res.status(400).json({error:"A moderator note is required for ban, time ban, and termination actions."});

 // A future start time creates a scheduled moderation action. The account
 // remains active until the scheduled time, then the scheduler applies it.
 const requestedStart=String(req.body?.starts_at||"").trim();
 const scheduledStart=requestedStart?new Date(requestedStart):new Date();
 const isFutureStart=Number.isFinite(scheduledStart.getTime()) && scheduledStart.getTime()>Date.now()+1000;
 if(isFutureStart && (action==="banned"||action==="terminated")){
   const reason=String(req.body?.ban_note||req.body?.note||req.body?.violation_type||"GBlocks rules violation").trim().slice(0,2000);
   const moderatorNote=String(req.body?.moderator_note||"").trim().slice(0,2000);
   const requestedEnd=String(req.body?.ends_at||"").trim();
   const endDate=requestedEnd?new Date(requestedEnd):null;
   if(requestedEnd && (!endDate||!Number.isFinite(endDate.getTime())||endDate<=scheduledStart))return res.status(400).json({error:"Ban end time must be after the future start time."});
   const requestedDays=safeDays(req.body?.duration_days);
   const durationDays=action==="terminated"?0:(endDate?Math.max(1,Math.ceil((endDate.getTime()-scheduledStart.getTime())/86400000)):requestedDays);
   await db.query("INSERT INTO scheduled_bans(target_user_id,target_username,action,reason,starts_at,ends_at,duration_days,created_by_user_id,created_by_username,moderator_note) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)",[
     String(p.user_id),String(p.username),action,reason,scheduledStart,endDate,durationDays,String(admin.user_id),String(admin.username||admin.user_id),moderatorNote
   ]);
   return res.json({ok:true,scheduled:true,action:action.toUpperCase(),username:p.username,starts_at:scheduledStart.toISOString(),ends_at:endDate?endDate.toISOString():null,duration_days:durationDays,message:(action==="banned"?"Ban":"Termination")+" scheduled for "+scheduledStart.toISOString()+"."});
 }

 if(p._legacy){
   if(action==="unbanned"||action==="unban"||action==="restore"){
     let newName=p.username;
     if(p.username_reset_on_unban){
       const candidate=await db.query("SELECT 'GBLOCKS_User_'||user_number::text AS username FROM profiles WHERE user_id=$1 AND user_number IS NOT NULL",[p.user_id]);
       if(candidate.rows[0]){
         newName=candidate.rows[0].username;
         await db.query("INSERT INTO username_history (username,user_id) VALUES ($1,$2)",[p.username,p.user_id]);
         await db.query("INSERT INTO username_reservations (username,reserved_for_user_id,reason) VALUES ($1,$2,$3) ON CONFLICT (username) DO NOTHING",[p.username,p.user_id,"username_history"]);
         await db.query("UPDATE gblocks_credentials SET username=$1,updated_at=NOW() WHERE user_id=$2",[newName,p.user_id]).catch(()=>{});
       }
     }
     await db.query("UPDATE profiles SET banned=false,terminated=false,ban_note='',temp_ban_until=NULL,username=$1,display_name=$1,username_reset_on_unban=false WHERE user_id=$2",[newName,p.user_id]);
     await logSuccessfulUnban(p,admin,newName);
     return res.json({ok:true,action:"UNBAN",username:newName,banned:false,terminated:false,usernameReset:p.username_reset_on_unban});
   }
   const terminated=action==="terminated"||action==="terminate";
   const permanentBan=action==="permanent_ban"||action==="ban";
   const requestedDays=safeDays(req.body?.duration_days);
   const repeatAfterSeven=Number(p.last_ban_duration_days||0)>=7 && Number(p.moderation_violation_count||0)>0;
   const durationDays=terminated||permanentBan?0:(repeatAfterSeven?183:requestedDays);
   const until=terminated||permanentBan?null:new Date(Date.now()+durationDays*86400000);
   const reason=String(req.body?.ban_note||req.body?.note||req.body?.violation_type||"GBlocks rules violation").trim().slice(0,2000);
   const bioFlag=/murder|kill|massacre|theft|stolen|steal|bully|harass|threat|violence/i.test(String(p.bio||""));
   const nameFlag=checkModerationUsername(p.username).flagged || !!req.body?.username_violation;
   const usernameReason=/^Your username\\b/i.test(reason);
   const resetOnUnban=!terminated && (nameFlag || usernameReason);
   const newName=p.username;
   await db.query("UPDATE profiles SET banned=$1,terminated=$2,verified=false,ban_note=$3,temp_ban_until=$4,moderation_violation_count=moderation_violation_count+1,last_ban_duration_days=$5,bio=CASE WHEN $6 THEN '[content Deleted]' ELSE bio END,bio_deleted_by_moderation=bio_deleted_by_moderation OR $6,username_reset_on_unban=$7 WHERE user_id=$8",[!terminated,terminated,reason,until,durationDays,bioFlag,resetOnUnban,p.user_id]);
   if(terminated){
     await db.query("INSERT INTO username_history (username,user_id) SELECT $1,$2 WHERE NOT EXISTS (SELECT 1 FROM username_history WHERE LOWER(username)=LOWER($1) AND user_id=$2)",[p.username,p.user_id]);
     await db.query("INSERT INTO username_reservations (username,reserved_for_user_id,reason) VALUES ($1,$2,$3) ON CONFLICT (username) DO NOTHING",[p.username,p.user_id,"terminated_account"]);
   } else {
     const online=await db.query("SELECT last_seen_at FROM profiles WHERE user_id=$1 LIMIT 1",[String(p.user_id)]);
     const lastSeen=online.rows[0]?.last_seen_at;
     if(lastSeen && Date.now()-new Date(lastSeen).getTime()<=5*60*1000){
       const achievementKey=String(admin.username||"").toLowerCase().includes("add_me_get_ban")?"banned_by_add_me_get_ban":"banned_by_moderator";
       await db.query("INSERT INTO gblocks_user_achievements(user_id,achievement_key) VALUES($1,$2) ON CONFLICT(user_id,achievement_key) DO NOTHING",[String(p.user_id),achievementKey]);
     }
   }
   await sendConfiguredDiscordEvent(terminated?"TERMINATE":"BAN",{title:"GBLOCKS • TERMINATE/BAN",color:terminated?0xFF334F:0xFF6B35,fields:[{name:"Username",value:String(newName||"Unknown").slice(0,256)},{name:"User ID",value:"GBlocks User #"+String(p.user_number||p.user_id)},{name:"Moderator",value:String(admin.username||admin.user_id||"Unknown").slice(0,256)},{name:"Status",value:terminated?"TERMINATED":"BANNED"},{name:"Reason",value:String(reason||"GBlocks rules violation").slice(0,1000)},{name:"Administrator Note",value:String(moderatorNote||"—").slice(0,1000)}]}).catch(()=>{});
   return res.json({ok:true,action:terminated?"TERMINATE":"BAN",username:newName,banned:!terminated,terminated,temp_ban_until:until?until.toISOString():null,duration_days:durationDays,bioDeleted:bioFlag,usernameResetOnUnban:resetOnUnban});
 }

 if(action==="unbanned"||action==="unban"||action==="restore"){
   let newUsername=p.username;
   if(p.username_reset_on_unban){
     const candidate=await db.query("SELECT 'GBLOCKS_User_'||user_number::text AS username FROM profiles WHERE user_id=$1 AND user_number IS NOT NULL",[p.user_id]);
     if(candidate.rows[0]){
       newUsername=candidate.rows[0].username;
       await db.query("INSERT INTO username_history (username,user_id) VALUES ($1,$2)",[p.username,p.user_id]);
       await db.query("INSERT INTO username_reservations (username,reserved_for_user_id,reason) VALUES ($1,$2,$3) ON CONFLICT (username) DO NOTHING",[p.username,p.user_id,"username_history"]);
       await db.query("UPDATE gblocks_credentials SET username=$1,updated_at=NOW() WHERE user_id=$2",[newUsername,p.user_id]).catch(()=>{});
     }
   }
   const updated=await db.query("UPDATE gblocks_players SET moderation_status='active',moderation_note='',temp_ban_until=NULL,username=$1,username_reset_on_unban=false WHERE user_id=$2 RETURNING user_id,username,display_name,bio,moderation_status",[newUsername,p.user_id]);
   // Keep the legacy profile/session moderation record in sync. GBlocks login
   // and the moderation gate still read profiles for these player accounts.
   await db.query("UPDATE profiles SET banned=false,terminated=false,ban_note='',temp_ban_until=NULL,username=$1,display_name=COALESCE(display_name,$1),username_reset_on_unban=false,verified=false WHERE user_id=$2",[newUsername,p.user_id]).catch(()=>{});
   await logSuccessfulUnban(p,admin,newUsername);
   return res.json({ok:true,action:"UNBAN",...updated.rows[0],usernameReset:p.username_reset_on_unban});
 }

 const terminated=action==="terminated"||action==="terminate";
 const permanentBan=action==="permanent_ban"||action==="ban";
 const violationType=String(req.body?.violation_type||"").trim().toLowerCase();
 const note=String(req.body?.ban_note||req.body?.note||"").trim().slice(0,2000);
 const requestedDays=safeDays(req.body?.duration_days);
 const repeatAfterSeven=Number(p.last_ban_duration_days||0)>=7 && Number(p.moderation_violation_count||0)>0;
 const requestedEnd=String(req.body?.ends_at||"").trim();
 const customEnd=requestedEnd?new Date(requestedEnd):null;
 if(!terminated&&requestedEnd&&(!customEnd||!Number.isFinite(customEnd.getTime())||customEnd<=new Date()))return res.status(400).json({error:"Ban end time must be in the future."});
 const durationDays=terminated||permanentBan?0:(customEnd?Math.max(1,Math.ceil((customEnd.getTime()-Date.now())/86400000)):(repeatAfterSeven?183:requestedDays));
 const until=terminated||permanentBan?null:(customEnd||new Date(Date.now()+durationDays*86400000));
 const shouldDeleteBio=/murder|kill|massacre|theft|stolen|steal|bully|harass|threat|violence/i.test(String(p.bio||""));
 const usernameCheck=checkModerationUsername(p.username);
 const shouldResetUsername=usernameCheck.flagged || !!req.body?.username_violation;
 const profileNumber=Number(p.user_number||0)||Number((await db.query("SELECT user_number FROM profiles WHERE user_id=$1 LIMIT 1",[p.user_id])).rows[0]?.user_number||0);
 const newUsername=shouldResetUsername&&profileNumber?("GBLOCKS_User_"+String(profileNumber)):p.username;
 const newStatus=terminated?"terminated":"banned";
 const reason=note||violationType||"GBlocks rules violation";

 await db.query(
  "UPDATE gblocks_players SET moderation_status=$1,moderation_note=$2,temp_ban_until=$3,moderation_violation_count=moderation_violation_count+1,moderation_last_action=NOW(),last_ban_duration_days=$4,bio=CASE WHEN $5 THEN '[content Deleted]' ELSE bio END,bio_deleted_by_moderation=bio_deleted_by_moderation OR $5,username=CASE WHEN $6 THEN $7 ELSE username END WHERE user_id=$8",
  [newStatus,reason,until,durationDays,shouldDeleteBio,shouldResetUsername,newUsername,p.user_id]
 );
 // Mirror moderation state into profiles so existing login/session checks,
 // profile pages, and account moderation gates immediately see the action.
 await db.query(
  "UPDATE profiles SET banned=$1,terminated=$2,verified=false,ban_note=$3,temp_ban_until=$4,moderation_violation_count=moderation_violation_count+1,last_ban_duration_days=$5,bio=CASE WHEN $6 THEN '[content Deleted]' ELSE bio END,bio_deleted_by_moderation=bio_deleted_by_moderation OR $6,username=CASE WHEN $7 THEN $8 ELSE username END WHERE user_id=$9",
  [!terminated,terminated,reason,until,durationDays,shouldDeleteBio,shouldResetUsername,newUsername,p.user_id]
 );
 if(shouldResetUsername)await db.query("UPDATE gblocks_credentials SET username=$1,updated_at=NOW() WHERE user_id=$2",[newUsername,p.user_id]);
 if(terminated){
   await db.query("INSERT INTO username_history (username,user_id) SELECT $1,$2 WHERE NOT EXISTS (SELECT 1 FROM username_history WHERE LOWER(username)=LOWER($1) AND user_id=$2)",[p.username,p.user_id]);
   await db.query("INSERT INTO username_reservations (username,reserved_for_user_id,reason) VALUES ($1,$2,$3) ON CONFLICT (username) DO NOTHING",[p.username,p.user_id,"terminated_account"]);
 }
 const auditAction=terminated?"TERMINATE":"BAN";
 const auditDetails={violationType,durationDays,bioDeleted:shouldDeleteBio,usernameReset:shouldResetUsername,unbanAt:until?until.toISOString():null,moderatorNote};
 await db.query(
  "INSERT INTO audit_logs (action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)",
  [auditAction,String(p.user_id),p.username,admin.user_id,admin.username,reason,JSON.stringify(auditDetails)]
 ).catch(()=>{});
 // Route every new BAN/TERMINATE event through the same configured Discord webhook
 // manager used by the Admin Webhook Manager, with a project-secret fallback.
 const expireLabel=terminated||permanentBan?"Never":durationDays>=30&&durationDays%30===0?(durationDays/30)+" month"+(durationDays===30?"":"s"):durationDays+" day"+(durationDays===1?"":"s");
 const gblocksUserId="GBlocks_User_"+String(p.user_number||p.user_id||"Unknown");
 const discordEmbed={
  title:terminated?"GBLOCKS LOGS • TERMINATION":"GBLOCKS LOGS • BAN",
  color:terminated?0xFF334F:0xFF6B35,
  fields:[
   {name:"User",value:String(p.username||"Unknown").slice(0,256),inline:false},
   {name:"User ID",value:(gblocksUserId+" (user ID "+String(p.user_id||"Unknown")+")").slice(0,256),inline:false},
   {name:"Reason",value:String(reason||"GBlocks rules violation").slice(0,1000),inline:false},
   {name:"Administrator Note",value:String(moderatorNote||"—").slice(0,1000),inline:false},
   {name:"Expire",value:expireLabel,inline:false},
   {name:"Moderator",value:String(admin.username||admin.user_id||"Unknown").slice(0,256),inline:false}
  ],
  timestamp:new Date().toISOString(),
  footer:{text:"GBLOCKS Logs"}
 };
 let discordResult={sent:0,failed:0};
 try { discordResult=await sendConfiguredDiscordEvent(terminated?"TERMINATE":"BAN",discordEmbed); }
 catch(err) { console.error("Discord moderation logging failed",String(err?.message||err).slice(0,200)); }
 await db.query("INSERT INTO audit_logs (action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)",["DISCORD_LOG",String(p.user_id),p.username,admin.user_id,admin.username,discordResult.sent?"Discord moderation log sent":"Discord moderation log failed",JSON.stringify({sourceAction:auditAction,discordSent:discordResult.sent>0,discordSentCount:discordResult.sent,discordFailedCount:discordResult.failed})]).catch(()=>{});

 return res.json({
  ok:true,action:terminated?"TERMINATE":"BAN",username:newUsername,display_name:p.display_name,
  moderation_status:newStatus,temp_ban_until:until?until.toISOString():null,duration_days:durationDays,
  bio:shouldDeleteBio?"[content Deleted]":p.bio,bioDeleted:shouldDeleteBio,usernameReset:shouldResetUsername,
  message:terminated?"This account was Terminated.":permanentBan?"This account was permanently banned.":"This account was banned until "+until.toISOString()+"."
 });
}