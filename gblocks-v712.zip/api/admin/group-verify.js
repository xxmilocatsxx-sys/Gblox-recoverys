import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import { refreshGroupVerification } from "../../lib/verification.js";

export const access = "public";
export const methods = ["POST"];

export default async function(req,res){
  const admin = await adminCaller(req);
  if(!admin) return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});

  const rawId = String(req.body?.id || "").trim();
  const name = String(req.body?.name || "").trim();
  const verified = req.body?.verified === true || req.body?.verified === "true";

  if(!rawId && !name) return res.status(400).json({error:"Community ID or name is required."});

  try {
    const target = rawId
      ? await db.query("SELECT id,name,verified FROM groups WHERE id=$1 LIMIT 1",[rawId])
      : await db.query("SELECT id,name,verified FROM groups WHERE LOWER(name)=LOWER($1) ORDER BY created_at DESC LIMIT 1",[name]);

    if(!target.rows[0]) return res.status(404).json({error:"Community not found."});

    const targetId=target.rows[0].id;
    console.log(JSON.stringify({action:"GROUP_VERIFICATION_REQUEST",admin:admin.username,requested_id:rawId||null,requested_name:name||null,target_id:targetId,old_verified:target.rows[0].verified,new_verified:verified}));
    const updated = await db.query(
      "UPDATE groups SET manual_verified=$1 WHERE id=$2 RETURNING id,name,verified",
      [verified,targetId]
    );

    if(updated.rowCount!==1 || !updated.rows[0]){
      console.error(JSON.stringify({action:"GROUP_VERIFICATION_UPDATE_FAILED",admin:admin.username,target_id:targetId,row_count:updated.rowCount}));
      return res.status(500).json({error:"Community verification could not be saved; the database updated 0 rows."});
    }

    const saved=await refreshGroupVerification(targetId);
    console.log(JSON.stringify({action:"GROUP_VERIFICATION_SAVED",admin:admin.username,target_id:targetId,verified:saved?.verified,manualVerified:verified}));

    return res.json({
      ok:true,
      id:targetId,
      name:updated.rows[0].name,
      verified:!!saved?.verified,
      autoVerified:!!saved?.auto_verified,
      message:verified?"Community verified successfully.":"Community verification removed successfully."
    });
  } catch(e) {
    console.error(JSON.stringify({action:"GROUP_VERIFICATION_ERROR",admin:admin.username,error:String(e?.message||e)}));
    return res.status(500).json({error:"Community verification failed to save."});
  }

  }