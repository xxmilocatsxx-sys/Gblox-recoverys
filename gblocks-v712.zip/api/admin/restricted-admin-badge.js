import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access="public";
export const methods=["GET","POST"];
export default async function(req,res){
 const admin=await adminCaller(req); if(!admin)return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});
 if(req.method==='GET'){const q=await db.query("SELECT username,badge_name,badge_icon,applied_by,applied_at FROM restricted_admin_badges ORDER BY applied_at DESC");return res.json({ok:true,badges:q.rows});}
 const username=String(req.body?.username||'').trim();
 if(!username||username.length<3||username.length>100)return res.status(400).json({error:"Enter a valid username."});
 const existing=await db.query("SELECT username FROM restricted_admin_badges WHERE username_key=LOWER($1) LIMIT 1",[username]);
 if(existing.rows[0])return res.json({ok:true,username:existing.rows[0].username,badge:"⚠️",alreadyApplied:true,message:"Restricted Admin badge is already permanently applied to this username."});
 await db.query("INSERT INTO restricted_admin_badges(username_key,username,badge_name,badge_icon,applied_by) VALUES(LOWER($1),$1,'Restricted Admin','⚠️',$2)",[username,String(admin.username||admin.admin_id||'Administrator')]);
 return res.json({ok:true,username,badge:"⚠️",alreadyApplied:false,message:"Restricted Admin badge permanently applied to this username. It survives permanent account deletion and Reset All Gblocks Accounts."});
}