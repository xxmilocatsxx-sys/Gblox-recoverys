import { storage, db, admin } from 'hatchable';
import crypto from 'node:crypto';
export const access = 'admin';
export const methods = ['GET','POST','DELETE'];
const slots = new Set(['verified','admin','premium','restricted-admin','creator','creator-alt','gobux']);
const allowed = new Set(['image/png','image/jpeg']);
export default async function(req,res){
 if(!(await admin.check(req))) return res.status(401).json({error:'Administrator sign-in required.'});
 try {
  if(req.method==='GET'){
   const r=await db.query('SELECT slot, filename, storage_key, content_type, bytes, updated_at FROM badge_image_assets ORDER BY slot');
   const items=await Promise.all(r.rows.map(async x=>({...x,url:await storage.url(x.storage_key)})));
   return res.json({items});
  }
  if(req.method==='DELETE'){
   const slot=String(req.body?.slot||''); if(!slots.has(slot)) return res.status(400).json({error:'Choose a valid badge slot.'});
   const r=await db.query('SELECT storage_key FROM badge_image_assets WHERE slot=$1',[slot]);
   if(r.rows[0]) await storage.del(r.rows[0].storage_key);
   await db.query('DELETE FROM badge_image_assets WHERE slot=$1',[slot]);
   return res.json({ok:true,message:'Badge image removed.'});
  }
  const slot=String(req.body?.slot||'');
  if(!slots.has(slot)) return res.status(400).json({error:'Choose a valid badge or Gobux image slot.'});
  const file=(req.files||[]).find(f=>f.field==='file');
  if(!file) return res.status(400).json({error:'Choose an image to upload.'});
  if(file.buffer.length>2*1024*1024) return res.status(413).json({error:'Image must be 2 MB or smaller.'});
  if(!allowed.has(file.contentType)) return res.status(415).json({error:'Only PNG and JPG/JPEG images are supported.'});
  const b=file.buffer;
  const png=b.length>=8&&b[0]===137&&b[1]===80&&b[2]===78&&b[3]===71;
  const jpg=b.length>=3&&b[0]===255&&b[1]===216&&b[2]===255;
  if(!(png||jpg)) return res.status(415).json({error:'The file contents do not match a PNG or JPEG image.'});
  const ext=png?'png':'jpg'; const key=`images/badges/${slot}-${crypto.randomUUID()}.${ext}`;
  await storage.put(key,b,png?'image/png':'image/jpeg');
  const old=await db.query('SELECT storage_key FROM badge_image_assets WHERE slot=$1',[slot]);
  await db.query('INSERT INTO badge_image_assets(slot,filename,storage_key,content_type,bytes,updated_at) VALUES($1,$2,$3,$4,$5,now()) ON CONFLICT(slot) DO UPDATE SET filename=EXCLUDED.filename,storage_key=EXCLUDED.storage_key,content_type=EXCLUDED.content_type,bytes=EXCLUDED.bytes,updated_at=now()',[slot,file.filename||`${slot}.${ext}`,key,png?'image/png':'image/jpeg',b.length]);
  if(old.rows[0]?.storage_key) await storage.del(old.rows[0].storage_key);
  return res.json({ok:true,message:'Badge image uploaded and saved.',slot,filename:file.filename||`${slot}.${ext}`,url:await storage.url(key)});
 } catch(e){ console.error('badge-images error',e); return res.status(500).json({error:'Image operation failed. Please try again.'}); }
}