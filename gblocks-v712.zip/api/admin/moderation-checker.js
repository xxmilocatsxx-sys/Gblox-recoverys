import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";

export const access = "public";
export const methods = ["GET"];

export default async function(req, res) {
  const admin = await adminCaller(req);
  if (!admin) return res.status(401).json({ error: "Administrator login required.", code: "NOT_SIGNED_IN" });

  const raw = String(req.query?.user_id || req.query?.userid || req.query?.username || "").trim().slice(0, 160);
  if (!raw) return res.status(400).json({ error: "Enter a player user ID or username." });

  const looksLikeId = raw.length > 24 || raw.includes("-");
  const profileResult = await db.query(
    "SELECT user_id,user_number,username,display_name,bio,role,banned,terminated,created_at,last_seen_at,bio_moderation_status,bio_moderation_last_reviewed_at,bio_deleted_by_moderation FROM profiles WHERE " +
      (looksLikeId ? "user_id=$1" : "LOWER(username)=LOWER($1)") + " LIMIT 1",
    [raw]
  );
  const profile = profileResult.rows[0];
  if (!profile) return res.status(404).json({ error: "Player account not found. Try its permanent user ID." });

  const [auditResult, bioResult, namesResult] = await Promise.all([
    db.query(
      "SELECT id,action,target_user_id,target_username,actor_user_id,actor_username,reason,details,created_at FROM audit_logs WHERE target_user_id=$1 ORDER BY created_at DESC LIMIT 100",
      [String(profile.user_id)]
    ),
    db.query(
      "SELECT id,action,original_bio,resulting_bio,actor_admin_username,reason,created_at FROM bio_moderation_history WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100",
      [String(profile.user_id)]
    ),
    db.query(
      "SELECT username,changed_at FROM username_history WHERE user_id=$1 ORDER BY changed_at DESC LIMIT 100",
      [String(profile.user_id)]
    )
  ]);

  return res.json({
    ok: true,
    checked_by: admin.username,
    profile: {
      user_id: String(profile.user_id),
      user_number: profile.user_number,
      username: profile.username,
      display_name: profile.display_name,
      bio: profile.bio_deleted_by_moderation ? "[Content Deleted]" : profile.bio,
      role: profile.role,
      banned: Boolean(profile.banned),
      terminated: Boolean(profile.terminated),
      created_at: profile.created_at,
      last_seen_at: profile.last_seen_at,
      bio_moderation_status: profile.bio_moderation_status || (profile.bio_deleted_by_moderation ? "content_deleted" : "not_reviewed"),
      bio_moderation_last_reviewed_at: profile.bio_moderation_last_reviewed_at
    },
    moderation_history: bioResult.rows,
    username_history: namesResult.rows,
    activity: auditResult.rows,
    activity_note: "Activity shows recorded moderation/audit events only. It is not a full history of every page view or click."
  });
}