import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access="public";
export const methods=["POST"];
export default async function(req,res){
 const admin=await adminCaller(req);
 if(!admin)return res.status(401).json({error:"Administrator login required."});
 const userId=String(req.body?.user_id||"").trim();
 const years=Number(req.body?.years);
 if(!userId)return res.status(400).json({error:"Choose a player account."});
 if(!Number.isInteger(years)||years<1||years>257)return res.status(400).json({error:"Choose a value from 1 to 257."});
 const q=await db.query("SELECT user_id,username,role FROM profiles WHERE user_id=$1 LIMIT 1",[userId]);
 const target=q.rows[0];
 if(!target)return res.status(404).json({error:"Player not found."});
 if(!["admin","administrator"].includes(String(target.role||"").toLowerCase()))return res.status(403).json({error:"257 Year Account is only available to administrator player accounts."});
 const key="admin_257_year_"+years;
 await db.query("INSERT INTO gblocks_user_achievements(user_id,achievement_key) VALUES($1,$2) ON CONFLICT(user_id,achievement_key) DO NOTHING",[userId,key]);
 await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES('achievement_granted',$1,$2,$3,$4,'Admin-only 257 Year Account achievement',$5::jsonb)",[userId,target.username,String(admin.admin_id||admin.user_id||""),String(admin.username||""),JSON.stringify({achievement_key:key,years})]);
 return res.json({ok:true,username:target.username,achievement:"257 Year Account",years});
}