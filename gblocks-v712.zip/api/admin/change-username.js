import { db } from 'hatchable';
import { adminCaller } from '../../lib/admin-auth.js';

export const access = 'public';
export const methods = ['POST'];

export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({error:'Administrator login required.',code:'NOT_SIGNED_IN'});

  const currentUserId=String(req.body?.currentUserId||'').trim();
  const current=String(req.body?.currentUsername||req.body?.username||'').trim();
  const newDisplayName=String(req.body?.newDisplayName??req.body?.newUsername??'').trim();
  if(!currentUserId&&!current)return res.status(400).json({error:'Select the GBlocks player account to change.'});
  if(!newDisplayName)return res.status(400).json({error:'Enter the new display name.'});
  if(newDisplayName.length>60)return res.status(400).json({error:'Display names must be 60 characters or fewer.'});

  // Target by immutable user ID so a stale or duplicate username can never
  // cause the administrator tool to edit the wrong account.
  const target=currentUserId
    ? await db.query('SELECT user_id,username,display_name FROM profiles WHERE user_id=$1',[currentUserId])
    : await db.query('SELECT user_id,username,display_name FROM profiles WHERE LOWER(username)=LOWER($1) ORDER BY user_id LIMIT 1',[current]);
  if(!target.rows[0])return res.status(404).json({error:'GBlocks player account not found.'});
  const account=target.rows[0];
  const oldDisplayName=String(account.display_name||account.username||'');
  if(newDisplayName===oldDisplayName)return res.status(400).json({error:'That is already the display name.'});

  // This tool changes display names only. Usernames, credentials, username
  // history/reservations, IDs, roles, Premium, balances and moderation stay intact.
  await db.transaction([
    {sql:'UPDATE profiles SET display_name=$1 WHERE user_id=$2',params:[newDisplayName,String(account.user_id)]},
    {sql:'UPDATE gblocks_players SET display_name=$1,updated_at=NOW() WHERE user_id=$2',params:[newDisplayName,String(account.user_id)]}
  ]);
  await db.query(
    'INSERT INTO audit_logs (action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)',
    ['ADMIN_DISPLAY_NAME_CHANGE',String(account.user_id),String(account.username),String(admin.admin_id||admin.user_id||''),admin.username,'Administrator changed the GBlocks display name',JSON.stringify({username:account.username,oldDisplayName,newDisplayName,adminPanelFormat:true})]
  );
  return res.json({
    ok:true,userId:String(account.user_id),username:account.username,
    oldDisplayName,newDisplayName,
    message:'Changed display name from '+oldDisplayName+' to '+newDisplayName+'. The @username was not changed.'
  });
}