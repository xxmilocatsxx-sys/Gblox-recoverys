import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";

export const access = "public";
export const methods = ["GET"];

export default async function (req, res) {
  const admin = await adminCaller(req);
  if (!admin) return res.status(401).json({ error: "Administrator login required.", code: "NOT_SIGNED_IN" });
  const userId = String(req.query?.user_id || "").trim();
  if (!userId) return res.status(400).json({ error: "user_id is required." });
  const result = await db.query("SELECT id,username,action,original_bio,resulting_bio,actor_admin_username,reason,created_at FROM bio_moderation_history WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100", [userId]);
  return res.json({ ok: true, history: result.rows });
}