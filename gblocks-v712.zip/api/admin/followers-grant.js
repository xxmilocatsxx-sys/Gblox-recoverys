import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import { refreshPlayerVerification } from "../../lib/verification.js";
export const access="public";
export const methods=["POST"];
export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});
  const username=String(req.body?.username||"").trim();
  const amount=Number(req.body?.amount);
  if(!username)return res.status(400).json({error:"Enter a username."});
  if(!Number.isSafeInteger(amount)||amount<1)return res.status(400).json({error:"Enter a whole follower amount of at least 1."});
  const target=await db.query("SELECT user_id,username FROM profiles WHERE lower(username)=lower($1) LIMIT 1",[username]);
  if(!target.rows.length)return res.status(404).json({error:"GBLOCKS user not found."});
  const q=await db.query("UPDATE profiles SET follower_bonus=LEAST(9007199254740991,follower_bonus+$1) WHERE user_id=$2 RETURNING follower_bonus",[amount,target.rows[0].user_id]);
  const verification=await refreshPlayerVerification(target.rows[0].user_id);
  res.json({ok:true,username:target.rows[0].username,added:amount,followerBonus:Number(q.rows[0].follower_bonus),verified:!!verification?.verified});
}