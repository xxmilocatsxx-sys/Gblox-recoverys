import { db } from 'hatchable';
import { adminCaller } from '../../lib/admin-auth.js';

export const access = 'public';
export const methods = ['POST'];

const CONFIRMATION = 'RESET ALL GBLOCKS ACCOUNTS';
const BOT_ROLE = 'bot';

const PLAYER_GUARD = (table, id='user_id') =>
  ` ${table}.${id} <> $1
    AND NOT EXISTS (SELECT 1 FROM profiles b WHERE b.user_id=${table}.${id} AND b.role='bot')
    AND NOT EXISTS (SELECT 1 FROM admin_accounts a WHERE a.admin_id=${table}.${id})`;

async function writeFailureAudit(admin, error, attemptedCounts = {}) {
  try {
    await db.query(
      "INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",
      [
        'RESET_ALL_GBLOCKS_ACCOUNTS', null, 'ALL PLAYER ACCOUNTS',
        String(admin?.admin_id || admin?.user_id || ''), String(admin?.username || 'Unknown'),
        'RESET ALL GBLOCKS ACCOUNTS failed; player reset was not completed atomically.',
        JSON.stringify({
          resetAuditId: crypto.randomUUID(), status: 'FAILED',
          playerAccountsAffected: 0, botAccountsAffected: 0,
          botsPreserved: true, administratorsPreserved: true,
          attemptedCounts, error: String(error?.message || error || 'Unknown error').slice(0, 1000)
        })
      ]
    );
  } catch {}
}

export default async function(req, res) {
  const confirmation = String(req.body?.confirmation || '').trim();
  if (confirmation !== CONFIRMATION) {
    return res.status(400).json({ error: `Type exactly: ${CONFIRMATION}` });
  }

  const admin = await adminCaller(req);
  if (!admin) return res.status(401).json({ error: 'Administrator login required.', code: 'NOT_SIGNED_IN' });

  const ownerId = String(admin.admin_id || admin.user_id || '');

  try {
    const counts = await db.query(
      `SELECT
        (SELECT COUNT(*) FROM profiles p
          WHERE p.user_id <> $1
            AND COALESCE(p.role,'user') <> 'bot'
            AND NOT EXISTS (SELECT 1 FROM admin_accounts a WHERE a.admin_id=p.user_id))::int AS players,
        (SELECT COUNT(*) FROM profiles p WHERE COALESCE(p.role,'user') = 'bot')::int AS bots,
        (SELECT COUNT(*) FROM admin_accounts)::int AS administrators`,
      [ownerId]
    );

    const before = counts.rows[0] || {};
    const playerCount = Number(before.players || 0);
    const botCount = Number(before.bots || 0);
    const administratorCount = Number(before.administrators || 0);

    const statements = [
      { sql: `DELETE FROM passkey_challenges WHERE${PLAYER_GUARD('passkey_challenges')}`, params: [ownerId] },
      { sql: `DELETE FROM passkey_credentials WHERE${PLAYER_GUARD('passkey_credentials')}`, params: [ownerId] },
      { sql: `DELETE FROM account_sessions WHERE${PLAYER_GUARD('account_sessions')}`, params: [ownerId] },
      { sql: `DELETE FROM gblocks_sessions WHERE${PLAYER_GUARD('gblocks_sessions')}`, params: [ownerId] },
      { sql: `DELETE FROM account_credentials WHERE${PLAYER_GUARD('account_credentials')}`, params: [ownerId] },
      { sql: `DELETE FROM gblocks_credentials WHERE${PLAYER_GUARD('gblocks_credentials')}`, params: [ownerId] },
      { sql: `DELETE FROM administrator_credentials WHERE${PLAYER_GUARD('administrator_credentials')}`, params: [ownerId] },
      { sql: `DELETE FROM follows WHERE follower_id <> $1 AND following_id <> $1
          AND NOT EXISTS (SELECT 1 FROM profiles b WHERE b.user_id=follows.follower_id AND b.role='bot')
          AND NOT EXISTS (SELECT 1 FROM profiles b WHERE b.user_id=follows.following_id AND b.role='bot')
          AND NOT EXISTS (SELECT 1 FROM admin_accounts a WHERE a.admin_id=follows.follower_id)
          AND NOT EXISTS (SELECT 1 FROM admin_accounts a WHERE a.admin_id=follows.following_id)`, params: [ownerId] },
      { sql: `DELETE FROM user_settings WHERE${PLAYER_GUARD('user_settings')}`, params: [ownerId] },
      { sql: `DELETE FROM gobux_accounts WHERE${PLAYER_GUARD('gobux_accounts')}`, params: [ownerId] },
      { sql: `DELETE FROM username_reservations WHERE reserved_for_user_id <> $1
          AND NOT EXISTS (SELECT 1 FROM profiles b WHERE b.user_id=username_reservations.reserved_for_user_id AND b.role='bot')
          AND NOT EXISTS (SELECT 1 FROM admin_accounts a WHERE a.admin_id=username_reservations.reserved_for_user_id)`, params: [ownerId] },
      { sql: `DELETE FROM username_history WHERE${PLAYER_GUARD('username_history')}`, params: [ownerId] },
      { sql: `DELETE FROM gblocks_players WHERE${PLAYER_GUARD('gblocks_players')}`, params: [ownerId] },
      { sql: `DELETE FROM profiles WHERE user_id <> $1
          AND COALESCE(role,'user') <> 'bot'
          AND NOT EXISTS (SELECT 1 FROM admin_accounts a WHERE a.admin_id=profiles.user_id)`, params: [ownerId] }
    ];

    const resetAuditId = crypto.randomUUID();
    statements.push({
      sql: "INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",
      params: [
        'RESET_ALL_GBLOCKS_ACCOUNTS', null, 'ALL PLAYER ACCOUNTS', ownerId,
        String(admin.username || 'Administrator'),
        'RESET ALL GBLOCKS ACCOUNTS completed. Normal player accounts were reset; bot accounts and all administrator accounts were preserved.',
        JSON.stringify({
          resetAuditId, status: 'SUCCESS', playerAccountsAffected: playerCount,
          botAccountsAffected: 0, botAccountsDetectedBeforeReset: botCount,
          administratorsDetectedBeforeReset: administratorCount,
          botsPreserved: true, administratorsPreserved: true,
          preservedBotRule: "profiles.role = 'bot'",
          administratorPreservationRule: 'admin_accounts.admin_id',
          immutable: true, completedAt: new Date().toISOString()
        })
      ]
    });

    await db.transaction(statements);

    return res.json({
      ok: true, resetAuditId,
      deleted: { accounts: playerCount },
      preserved: { botAccounts: botCount, botAccountsAffected: 0, systemBotsUntouched: true, administrators: administratorCount, administratorAccountsUntouched: true },
      audit: { action: 'RESET ALL GBLOCKS ACCOUNTS', status: 'SUCCESS', immutable: true, recordedServerSide: true }
    });
  } catch (error) {
    await writeFailureAudit(admin, error);
    return res.status(500).json({ error: 'Reset failed. No player-account reset was committed. A FAILED reset audit entry was recorded.', code: 'RESET_FAILED' });
  }
}