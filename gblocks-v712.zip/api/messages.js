import { db } from "hatchable";
export const access="public";
export const methods=["GET","POST"];
const enc=new TextEncoder();
const b64=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
async function h(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function token(req){if(req.cookies?.groblox_session)return req.cookies.groblox_session;return String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1]||""}
async function me(req){const t=token(req);if(!t)return null;const r=await db.query("SELECT p.user_id,p.username,p.display_name,p.banned,p.terminated,p.deactivated_at FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await h(t)]);return r.rows[0]||null}
export default async function(req,res){
 const u=await me(req);if(!u)return res.status(401).json({error:"Log in first."});
 if(u.banned||u.terminated||u.deactivated_at)return res.status(403).json({error:"Messaging is unavailable for this account."});
 if(req.method==="GET"){
   const q=await db.query("SELECT m.id,m.sender_id,m.receiver_id,m.message,m.read_at,m.created_at,CASE WHEN COALESCE(sp.deactivated_at,sgp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE sp.username END AS sender_username,CASE WHEN COALESCE(rp.deactivated_at,rgp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE rp.username END AS receiver_username FROM direct_messages m JOIN profiles sp ON sp.user_id=m.sender_id JOIN profiles rp ON rp.user_id=m.receiver_id LEFT JOIN gblocks_players sgp ON sgp.user_id=sp.user_id LEFT JOIN gblocks_players rgp ON rgp.user_id=rp.user_id WHERE m.sender_id=$1 OR m.receiver_id=$1 ORDER BY m.created_at DESC LIMIT 200",[u.user_id]);
   return res.json({messages:q.rows.reverse(),username:u.username});
 }
 const recipient=String(req.body?.username||"").trim();
 const message=String(req.body?.message||"").trim().slice(0,1000);
 if(!recipient)return res.status(400).json({error:"Enter the username to message."});
 if(!message)return res.status(400).json({error:"Enter a message."});
 if(message.length>1000)return res.status(400).json({error:"Message is too long."});
 const target=(await db.query("SELECT p.user_id,p.username,p.display_name,p.banned,p.terminated,COALESCE(p.deactivated_at,gp.deactivated_at) AS deactivated_at FROM profiles p LEFT JOIN gblocks_players gp ON gp.user_id=p.user_id WHERE LOWER(p.username)=LOWER($1) LIMIT 1",[recipient])).rows[0];
 if(!target)return res.status(404).json({error:"Player not found."});
 if(target.user_id===u.user_id)return res.status(400).json({error:"You cannot message yourself."});
 if(target.banned||target.terminated||target.deactivated_at)return res.status(403).json({error:"That player cannot receive messages right now."});
 const r=await db.query("INSERT INTO direct_messages(sender_id,receiver_id,message) VALUES($1,$2,$3) RETURNING id,created_at",[u.user_id,target.user_id,message]);
 const notificationTitle=`New message from @${u.username}`;
 await db.query("INSERT INTO gblocks_notifications(user_id,actor_user_id,actor_username,type,title,body) VALUES($1,$2,$3,'message',$4,$5)",[target.user_id,u.user_id,u.username,notificationTitle,message]);
 res.status(201).json({ok:true,id:r.rows[0].id,created_at:r.rows[0].created_at,recipient:target.username});
}