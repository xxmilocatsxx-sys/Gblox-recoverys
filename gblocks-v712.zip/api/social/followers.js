import { db } from "hatchable";
export const access = "public";
export const methods = ["GET"];
export default async function(req,res){
  const id=String(req.query?.userid||"").trim();
  if(!id) return res.status(400).json({error:"userid is required"});
  const target=await db.query("SELECT user_id,username,follower_bonus FROM profiles WHERE user_id=$1",[id]);
  if(!target.rows[0]) return res.status(404).json({error:"Player not found"});
  const page=Math.max(1,Number.parseInt(String(req.query?.page||"1"),10)||1);
  const limit=Math.min(50,Math.max(1,Number.parseInt(String(req.query?.limit||"25"),10)||25));
  const offset=(page-1)*limit;
  const real=await db.query("SELECT p.user_id,p.username,p.display_name,p.verified FROM follows f JOIN profiles p ON p.user_id=f.follower_id WHERE f.following_id=$1 ORDER BY f.created_at DESC LIMIT $2 OFFSET $3",[id,limit,offset]);
  const count=await db.query("SELECT COUNT(*)::bigint AS count FROM follows WHERE following_id=$1",[id]);
  const aiCount=Math.max(0,Number(target.rows[0].follower_bonus||0));
  const ai=[];
  for(let n=offset+1;n<=Math.min(aiCount,offset+limit);n++) ai.push({id:"ai-"+n,username:"AI"+n,display_name:"AI"+n,is_ai:true});
  res.json({follower_count:aiCount+Number(count.rows[0].count||0),ai_follower_count:aiCount,real_follower_count:Number(count.rows[0].count||0),page,limit,ai_followers:ai,real_followers:real.rows.map(x=>({...x,is_ai:false}))});
}