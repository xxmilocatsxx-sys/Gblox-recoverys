import { db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function tokenHash(t){ return b64(await crypto.subtle.digest("SHA-256", enc.encode(t))); }
function cookie(req){ return String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1] || null; }

export default async function(req,res){
  const targetId=String(req.query?.userid||req.query?.userId||"").trim();
  if(!targetId) return res.status(400).json({error:"userid is required"});

  // Everything needed for the profile social summary is fetched in one DB call.
  // This keeps profile polling below the project's DB gateway rate limit.
  const token=cookie(req);
  const tokenHashValue=token?await tokenHash(token):null;

  const q=await db.query(
    `WITH me AS (
       SELECT s.user_id
       FROM account_sessions s
       WHERE $2::text IS NOT NULL
         AND s.token_hash=$2
         AND s.expires_at>NOW()
       LIMIT 1
     )
     SELECT
       p.user_id,
       p.follower_bonus,
       (SELECT COUNT(*) FROM follows f WHERE f.following_id=p.user_id) AS real_followers,
       (SELECT COUNT(*) FROM follows f WHERE f.follower_id=p.user_id) AS following_count,
       (SELECT COUNT(*) FROM friend_requests fr WHERE fr.status='accepted'
          AND (fr.sender_id=p.user_id OR fr.receiver_id=p.user_id)) AS friends,
       EXISTS(
         SELECT 1 FROM follows f
         WHERE f.follower_id=(SELECT user_id FROM me)
           AND f.following_id=p.user_id
       ) AS following,
       COALESCE((
         SELECT status FROM friend_requests fr
         WHERE (fr.sender_id=(SELECT user_id FROM me) AND fr.receiver_id=p.user_id)
            OR (fr.sender_id=p.user_id AND fr.receiver_id=(SELECT user_id FROM me))
         ORDER BY fr.updated_at DESC LIMIT 1
       ), 'none') AS friend_status,
       EXISTS(SELECT 1 FROM me) AS signed_in,
       COALESCE((
         SELECT jsonb_agg(jsonb_build_object(
           'user_id',fp.user_id,'username',CASE WHEN COALESCE(fp.deactivated_at,fgp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE fp.username END,
           'display_name',CASE WHEN COALESCE(fp.deactivated_at,fgp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE fp.display_name END,'verified',CASE WHEN COALESCE(fp.deactivated_at,fgp.deactivated_at) IS NOT NULL THEN false ELSE fp.verified END
         ) ORDER BY f.created_at DESC)
         FROM follows f JOIN profiles fp ON fp.user_id=f.following_id LEFT JOIN gblocks_players fgp ON fgp.user_id=fp.user_id
         WHERE f.follower_id=p.user_id
         LIMIT 50
       ), '[]'::jsonb) AS followings,
       COALESCE((
         SELECT jsonb_agg(jsonb_build_object(
           'user_id',fp.user_id,'username',CASE WHEN COALESCE(fp.deactivated_at,fgp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE fp.username END,
           'display_name',CASE WHEN COALESCE(fp.deactivated_at,fgp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE fp.display_name END,'verified',CASE WHEN COALESCE(fp.deactivated_at,fgp.deactivated_at) IS NOT NULL THEN false ELSE fp.verified END
         ) ORDER BY fr.updated_at DESC)
         FROM friend_requests fr
         JOIN profiles fp ON fp.user_id=CASE
           WHEN fr.sender_id=p.user_id THEN fr.receiver_id ELSE fr.sender_id END
         LEFT JOIN gblocks_players fgp ON fgp.user_id=fp.user_id
         WHERE fr.status='accepted'
           AND (fr.sender_id=p.user_id OR fr.receiver_id=p.user_id)
       ), '[]'::jsonb) AS friends_list
     FROM profiles p
     WHERE p.user_id=$1
     LIMIT 1`,
    [targetId, tokenHashValue]
  );

  if(!q.rows[0]) return res.status(404).json({error:"Player not found"});

  const row=q.rows[0];
  res.json({
    followers:Number(row.real_followers||0)+Number(row.follower_bonus||0),
    followingCount:Number(row.following_count||0),
    friends:Number(row.friends||0),
    following:!!row.following,
    friendStatus:row.friend_status||"none",
    userCanAct:!!row.signed_in,
    followings:row.followings||[],
    friendsList:row.friends_list||[]
  });
}