import { db } from "hatchable";

export const access = "scheduler";
export const methods = ["POST"];

export default async function(req, res) {
  const eligible = await db.query(
    "SELECT p.user_id,CASE WHEN (p.role IN ('admin','administrator') AND ps.user_id IS NOT NULL AND ps.active=true AND (ps.is_permanent=true OR ps.expires_at>NOW())) THEN 'admin+premium' WHEN p.role IN ('admin','administrator') THEN 'admin' ELSE 'premium' END AS source FROM profiles p LEFT JOIN premium_subscriptions ps ON ps.user_id=p.user_id AND ps.active=true AND (ps.is_permanent=true OR ps.expires_at>NOW()) WHERE p.role IN ('admin','administrator') OR ps.user_id IS NOT NULL"
  );

  let enrolled = 0;
  for (const row of eligible.rows) {
    const r = await db.query(
      "INSERT INTO gblocks_beta_testers (user_id,source,active,updated_at) VALUES ($1,$2,true,NOW()) ON CONFLICT (user_id) DO UPDATE SET source=EXCLUDED.source,active=true,updated_at=NOW() RETURNING user_id",
      [row.user_id, row.source]
    );
    if (r.rows[0]) enrolled++;
  }

  const off = await db.query(
    "UPDATE gblocks_beta_testers t SET active=false,updated_at=NOW() WHERE t.active=true AND NOT EXISTS (SELECT 1 FROM profiles p LEFT JOIN premium_subscriptions ps ON ps.user_id=p.user_id AND ps.active=true AND (ps.is_permanent=true OR ps.expires_at>NOW()) WHERE p.user_id=t.user_id AND (p.role IN ('admin','administrator') OR ps.user_id IS NOT NULL))"
  );

  return res.json({ ok:true, eligible:eligible.rows.length, enrolled, deactivated:off.rowCount||0 });
}