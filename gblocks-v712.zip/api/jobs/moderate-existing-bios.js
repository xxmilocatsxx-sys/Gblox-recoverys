import { db } from "hatchable";
import { checkBio } from "../../lib/moderation-policy.js";
export const access="scheduler";
export const methods=["POST"];
const DELETED="[Content Deleted]";
const BATCH_SIZE=25;
export default async function(req,res){
  const profiles=await db.query("SELECT user_id,username,bio,moderation_violation_count FROM profiles WHERE COALESCE(TRIM(bio),'')<>'' AND bio_moderation_status='not_reviewed' AND bio_deleted_by_moderation=false AND user_number<>23 ORDER BY user_id LIMIT $1",[BATCH_SIZE]);
  let checked=0,deleted=0,banned=0;
  for(const row of profiles.rows){
    checked++;
    const result=checkBio(row.bio);
    if(!result.flagged){
      await db.query("UPDATE profiles SET bio_moderation_status='reviewed',bio_moderation_last_reviewed_at=NOW() WHERE user_id=$1 AND bio_moderation_status='not_reviewed'",[row.user_id]);
      continue;
    }
    const until=new Date(Date.now()+5*60*1000);
    await db.transaction([
      {sql:"INSERT INTO bio_moderation_history(user_id,username,action,original_bio,resulting_bio,reason) VALUES($1,$2,'AUTOMATIC_DELETE',$3,$4,'Automatic GBlocks Community Standards bio moderation match.')",params:[row.user_id,row.username,row.bio,DELETED]},
      {sql:"UPDATE profiles SET bio=$1,bio_moderation_status='content_deleted',bio_moderation_last_reviewed_at=NOW(),bio_deleted_by_moderation=true,banned=true,terminated=false,temp_ban_until=$2,ban_note=$3,moderation_violation_count=moderation_violation_count+1,last_ban_duration_days=0 WHERE user_id=$4 AND bio_deleted_by_moderation=false",params:[DELETED,until,"GBlocks Community Standards: profile bio violation.",row.user_id]},
      {sql:"UPDATE gblocks_players SET bio=$1,bio_deleted_by_moderation=true WHERE user_id=$2",params:[DELETED,row.user_id]}
    ]);
    deleted++; banned++;
  }
  res.json({ok:true,checked,deleted,banned,message:"GBlocks now checks bios against its Community Standards and applies a 5-minute moderation ban when a violation is found. The rules are informed by Roblox's publicly documented Community Standards, but GBlocks is an independent platform."});
}