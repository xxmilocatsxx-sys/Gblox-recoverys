import { db } from "hatchable";
import { checkBio, checkModerationUsername } from "../../lib/moderation-policy.js";
import { awardBotReward } from "../../lib/bot-rewards.js";

export const access = "scheduler";
export const methods = ["POST"];

const DELETED = "[Content Deleted]";
const BOT_USERNAME = "GblocksBot";

async function nextUsername() {
  const r = await db.query(`
    SELECT 'Gblocks_User_' || n::text AS username
    FROM generate_series(1,1000000) n
    WHERE NOT EXISTS (SELECT 1 FROM profiles p WHERE LOWER(p.username)=LOWER('Gblocks_User_'||n::text))
      AND NOT EXISTS (SELECT 1 FROM username_reservations u WHERE LOWER(u.username)=LOWER('Gblocks_User_'||n::text))
      AND NOT EXISTS (SELECT 1 FROM gblocks_credentials c WHERE LOWER(c.username)=LOWER('Gblocks_User_'||n::text))
    ORDER BY n LIMIT 1
  `);
  return r.rows[0]?.username || null;
}

export default async function(req,res){
  const day = new Date().getUTCDay();
  if(day === 5 || day === 6){
    return res.json({ok:true,bot:BOT_USERNAME,status:"sleeping",online:false,day});
  }

  const bot = await db.query(
    "SELECT user_id,username FROM profiles WHERE LOWER(username)=LOWER($1) LIMIT 1",
    [BOT_USERNAME]
  );
  if(!bot.rows[0]) return res.status(503).json({error:"GblocksBot account is missing."});

  // Add_me_and_get_Ban is handled only by api/social/action.js when the bot
  // explicitly accepts a request. The patrol must never mass-ban every accepted
  // request or ban accounts merely because a request exists.

  const rows = await db.query(
    "SELECT user_id,username,display_name,bio,bio_deleted_by_moderation FROM profiles WHERE banned=false AND terminated=false AND user_id<>$1 AND user_number<>23 ORDER BY user_id",
    [bot.rows[0].user_id]
  );

  let scanned=0, usernamesReset=0, biosReset=0;
  const results=[];

  for(const row of rows.rows){
    scanned++;
    const usernameCheck=checkModerationUsername(row.username);
    const bioCheck=row.bio_deleted_by_moderation ? {flagged:false} : checkBio(row.bio);
    if(!usernameCheck.flagged && !bioCheck.flagged) continue;

    const oldUsername=String(row.username);
    let newUsername=oldUsername;

    try {
      await db.transaction([
        {sql:"SELECT user_id FROM profiles WHERE user_id=$1 FOR UPDATE",params:[String(row.user_id)]}
      ]);

      if(usernameCheck.flagged){
        newUsername=await nextUsername();
        if(!newUsername) throw new Error("No available reset username.");
        await db.transaction([
          {sql:"INSERT INTO username_history(username,user_id) VALUES($1,$2)",params:[oldUsername,String(row.user_id)]},
          {sql:"INSERT INTO username_reservations(username,reserved_for_user_id,reason) VALUES($1,$2,'bot_patrol_username_violation') ON CONFLICT(username) DO NOTHING",params:[oldUsername,String(row.user_id)]},
          {sql:"UPDATE profiles SET username=$1,display_name=$1 WHERE user_id=$2",params:[newUsername,String(row.user_id)]},
          {sql:"UPDATE gblocks_credentials SET username=$1,updated_at=NOW() WHERE user_id=$2",params:[newUsername,String(row.user_id)]},
          {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",params:["BOT_USERNAME_RESET",String(row.user_id),newUsername,String(bot.rows[0].user_id),BOT_USERNAME,"GblocksBot patrol detected a username violation.",JSON.stringify({oldUsername,newUsername})]}
        ]);
        usernamesReset++;
      }

      if(bioCheck.flagged){
        await db.transaction([
          {sql:"INSERT INTO bio_moderation_history(user_id,username,action,original_bio,resulting_bio,reason) VALUES($1,$2,'AUTOMATIC_DELETE',$3,$4,'GblocksBot patrol detected a bio violation.')",params:[String(row.user_id),newUsername,row.bio,DELETED]},
          {sql:"UPDATE profiles SET bio=$1,bio_moderation_status='content_deleted',bio_moderation_last_reviewed_at=NOW(),bio_deleted_by_moderation=true WHERE user_id=$2",params:[DELETED,String(row.user_id)]},
          {sql:"UPDATE gblocks_players SET bio=$1,bio_deleted_by_moderation=true WHERE user_id=$2",params:[DELETED,String(row.user_id)]},
          {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",params:["BOT_BIO_RESET",String(row.user_id),newUsername,String(bot.rows[0].user_id),BOT_USERNAME,"GblocksBot patrol detected a bio violation.",JSON.stringify({username:newUsername})]}
        ]);
        biosReset++;
      }

      const rewardEvent = "gblocks-patrol:" + String(row.user_id) + ":" + (usernameCheck.flagged ? "username" : "bio") + ":" + new Date().toISOString().slice(0,10);
      const reward = await awardBotReward(bot.rows[0].user_id, "GblocksBot found suspicious content during patrol.", rewardEvent, String(row.user_id));
      results.push({userId:String(row.user_id),oldUsername,newUsername,usernameReset:usernameCheck.flagged,bioReset:bioCheck.flagged,reward6000:reward.awarded});
    } catch(e) {
      results.push({userId:String(row.user_id),error:"Patrol could not safely complete this account."});
    }
  }

  return res.json({ok:true,bot:BOT_USERNAME,scanned,usernamesReset,biosReset,results});
}