import { db } from "hatchable";
export const access="scheduler";
export const schedule="15 3 * * *";
export default async function(req,res){
 if(req.headers?.["x-hatchable-trigger"]!=="cron")return res.status(403).json({error:"Scheduler only."});
 const a=await db.query("UPDATE profiles SET legacy_status='legacy_review',legacy_reviewed_at=NOW() WHERE deactivated_at IS NOT NULL AND recovery_deadline<=NOW() AND legacy_status='deactivated' RETURNING user_id");
 const b=await db.query("UPDATE gblocks_players SET legacy_status='legacy_review',legacy_reviewed_at=NOW(),updated_at=NOW() WHERE deactivated_at IS NOT NULL AND recovery_deadline<=NOW() AND legacy_status='deactivated' RETURNING user_id");
 return res.json({ok:true,profiles_review_eligible:a.rowCount||0,players_review_eligible:b.rowCount||0,automatic_termination:false});
}