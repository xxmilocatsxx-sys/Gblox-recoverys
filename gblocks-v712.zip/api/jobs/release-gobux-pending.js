import {db} from "hatchable";
export const access="scheduler"; export const methods=["POST"];
const MAX="500000000000000000000000000000000000000000000000000000000000000000000000000000000";
export const schedule="0 * * * *";
export default async function(req,res){
 const q=await db.query("SELECT transaction_id,recipient_user_id,amount FROM gobux_pending_credits WHERE status='pending' AND available_at<=NOW() ORDER BY available_at ASC LIMIT 200");
 let released=0,failed=0;
 for(const p of q.rows){try{
   await db.query("INSERT INTO gobux_accounts(user_id,balance,gobux_infinite) VALUES($1,0,false) ON CONFLICT(user_id) DO NOTHING",[p.recipient_user_id]);
   const w=await db.query("UPDATE gobux_accounts SET balance=CASE WHEN gobux_infinite THEN balance ELSE LEAST($1::numeric,balance+$2::numeric) END,updated_at=NOW() WHERE user_id=$3 RETURNING balance,gobux_infinite",[MAX,String(p.amount),p.recipient_user_id]);
   if(!w.rows.length)throw new Error("wallet update failed");
   await db.query("UPDATE gobux_pending_credits SET status='released',released_at=NOW() WHERE transaction_id=$1 AND status='pending'",[p.transaction_id]);
   await db.query("UPDATE gobux_transactions SET status='completed' WHERE (transaction_id=$1 OR transaction_id=$2) AND status='pending'",[p.transaction_id,`PEND-${p.transaction_id}`]);
   released++;
 }catch(e){failed++;console.error("Gobux pending release failed",p.transaction_id,e)}}
 res.json({ok:true,released,failed,checked:q.rows.length});
}