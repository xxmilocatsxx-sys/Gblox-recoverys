import { db } from "hatchable";

export const access = "scheduler";
export const methods = ["POST"];

export default async function (req, res) {
  // Scheduler access already gates this route; run_function uses the scheduler tier without the cron header.

  const due = await db.query("SELECT id,user_id,weekly_amount,expires_at FROM premium_subscriptions WHERE active=true AND next_payout_at<=NOW() AND expires_at>NOW() ORDER BY id LIMIT 500");
  let paid = 0;

  for (const row of due.rows) {
    const result = await db.transaction([
      {
        sql: "UPDATE premium_subscriptions SET next_payout_at=next_payout_at+interval '7 days',updated_at=now() WHERE id=$1 AND active=true AND next_payout_at<=NOW() AND expires_at>NOW() RETURNING user_id,weekly_amount",
        params: [row.id]
      },
      {
        sql: "INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,$2,NULL,false) ON CONFLICT (user_id) DO UPDATE SET balance=gobux_accounts.balance+$2,updated_at=now()",
        params: [row.user_id, row.weekly_amount]
      }
    ]);
    if (result.results?.[0]?.rows?.[0]) paid++;
  }

  await db.query("UPDATE premium_subscriptions SET active=false,updated_at=now() WHERE active=true AND expires_at<=NOW()");
  res.json({ ok: true, paid, checked: due.rows.length });
}