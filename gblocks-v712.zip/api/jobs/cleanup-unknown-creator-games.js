import { db } from "hatchable";
export const access="scheduler";
export const methods=["POST"];
export const schedule="0 * * * *";
export default async function(req,res){
  try{
    const r=await db.query("UPDATE games g SET moderation_deleted=TRUE, moderation_reason='Creator profile missing or unknown', moderation_updated_at=NOW() WHERE g.moderation_deleted=FALSE AND (g.creator_id IS NULL OR NOT EXISTS (SELECT 1 FROM profiles p WHERE p.user_id=g.creator_id)) RETURNING g.id,g.name");
    console.log(JSON.stringify({event:"UNKNOWN_CREATOR_GAMES_CLEANUP",hidden_count:r.rowCount||r.rows?.length||0,game_ids:(r.rows||[]).map(x=>x.id)}));
    return res.json({ok:true,removedFromListings:r.rowCount||r.rows?.length||0});
  }catch(e){console.error("unknown creator game cleanup failed",String(e?.message||e));return res.status(500).json({error:"Unknown-creator game cleanup failed."});}
}