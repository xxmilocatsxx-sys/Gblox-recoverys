import { db } from "hatchable";

export const access = "scheduler";
export const methods = ["POST"];
export const schedule = "10 8 * * *";

const CALENDAR_EVENTS = {
  "01-01": ["New Year Celebration","Happy New Year from GBLOX! A fresh year means fresh games, new memories, and new adventures. 🎉"],
  "02-14": ["Valentine's Day","Celebrate friendship, kindness, and community on GBLOX today. 💙"],
  "03-08": ["International Women's Day","Today is International Women's Day. GBLOX celebrates the achievements and contributions of women around the world."],
  "04-22": ["Earth Day","It's Earth Day! Let's celebrate our planet and remember to care for the world we share. 🌍"],
  "05-01": ["May Day","Happy May Day! Take a moment to celebrate community, creativity, and the people who make things better."],
  "06-05": ["World Environment Day","Today is World Environment Day. Small actions can help protect our planet. 🌱"],
  "09-21": ["GBLOX Anniversary 🎉","Happy GBLOX Anniversary! Today marks another year of GBLOX. Thank you to every player who has helped the community grow — celebrate with us! 💙 It is also the International Day of Peace, so spread kindness and help make GBLOX welcoming for everyone. 🕊️"],
  "10-31": ["Halloween Event","It's Halloween! Time for spooky fun, seasonal games, and limited-time surprises on GBLOX. 🎃"],
  "12-25": ["Holiday Celebration","Warm holiday wishes from GBLOX! We hope your day brings fun, kindness, and great memories. ✨"]
};

export default async function(req,res){
  const botQ=await db.query("SELECT user_id,username FROM profiles WHERE LOWER(username)='gbloxbuilder' AND role='bot' AND banned=false AND terminated=false LIMIT 1");
  const bot=botQ.rows[0];
  if(!bot) return res.status(503).json({error:"GbloxBuilder bot profile is missing or unavailable."});

  // Keep the official Gblox following list restricted to Milo and tubers93.
  const gbloxQ=await db.query("SELECT user_id FROM profiles WHERE LOWER(username)='gblox' LIMIT 1");
  if(gbloxQ.rows[0]){
    const gbloxId=String(gbloxQ.rows[0].user_id);
    await db.query("DELETE FROM follows WHERE follower_id=$1 AND following_id NOT IN (SELECT user_id FROM profiles WHERE LOWER(username) IN ('milo','tubers93'))",[gbloxId]);
    await db.query("INSERT INTO follows(follower_id,following_id) SELECT $1,p.user_id FROM profiles p WHERE LOWER(p.username) IN ('milo','tubers93') AND p.user_id<>$1 ON CONFLICT DO NOTHING",[gbloxId]);
  }

  // Friend requests are intentionally ignored; keep GbloxBuilder at zero friends.
  await db.query("DELETE FROM friend_requests WHERE sender_id=$1 OR receiver_id=$1",[String(bot.user_id)]);

  // Top up follows to at most 100 active existing players, and continue filling as the site grows.
  const countQ=await db.query("SELECT COUNT(*)::int AS count FROM follows WHERE follower_id=$1",[String(bot.user_id)]);
  const remaining=Math.max(0,100-Number(countQ.rows[0]?.count||0));
  let followed=0;
  if(remaining>0){
    const inserted=await db.query(
      "INSERT INTO follows(follower_id,following_id) SELECT $1,p.user_id FROM profiles p WHERE p.user_id<>$1 AND p.banned=false AND p.terminated=false AND p.deactivated_at IS NULL AND NOT EXISTS(SELECT 1 FROM follows f WHERE f.follower_id=$1 AND f.following_id=p.user_id) ORDER BY p.user_number NULLS LAST,p.created_at,p.username LIMIT $2 ON CONFLICT DO NOTHING RETURNING following_id",
      [String(bot.user_id),remaining]
    );
    followed=inserted.rowCount||inserted.rows?.length||0;
  }

  const todayQ=await db.query("SELECT TO_CHAR(CURRENT_DATE,'MM-DD') AS month_day, EXTRACT(YEAR FROM CURRENT_DATE)::int AS year, CURRENT_DATE AS today");
  const {month_day,year,today}=todayQ.rows[0];
  const event=CALENDAR_EVENTS[month_day];
  let eventCreated=false;
  if(event){
    const inserted=await db.query(
      "INSERT INTO gblox_bot_events(event_key,title,body,event_date,created_by) VALUES($1,$2,$3,$4,$5) ON CONFLICT(event_key) DO NOTHING RETURNING id",
      [month_day+"-"+year,event[0],event[1],today,String(bot.user_id)]
    );
    eventCreated=(inserted.rowCount||inserted.rows?.length||0)>0;
  }

  return res.json({ok:true,bot:"GbloxBuilder",followingCount:Number(countQ.rows[0]?.count||0)+followed,followedToday:followed,friendRequestsIgnored:true,friendCount:0,eventCreated,eventDate:today});
}