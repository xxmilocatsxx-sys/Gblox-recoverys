import { db } from "hatchable";

export const access = "scheduler";
export const methods = ["POST"];

const BOT_USERNAME = "GblocksBot";
const BUILDER_USERNAME = "GbloxBuilder";
const WEEKLY_AMOUNT = 10;
const PURCHASE_PRICE = 10;

export default async function(req,res){
  const week = await db.query("SELECT date_trunc('week', NOW()) AS week_start");
  const weekStart = week.rows[0].week_start;

  const bot = await db.query("SELECT user_id,username FROM profiles WHERE lower(username)=lower($1) AND banned=false AND terminated=false LIMIT 1",[BOT_USERNAME]);
  if(!bot.rows[0]) return res.status(503).json({error:"GblocksBot account is missing."});

  const alt = await db.query("SELECT user_id,username FROM profiles WHERE lower(username)=lower($1) AND banned=false AND terminated=false LIMIT 1",[BUILDER_USERNAME]);
  if(!alt.rows[0]) return res.status(503).json({error:"Builder account is missing."});

  const marker = await db.query("INSERT INTO gblocks_bot_weekly_runs (week_start,amount) VALUES ($1,$2) ON CONFLICT (week_start) DO NOTHING RETURNING week_start",[weekStart,WEEKLY_AMOUNT]);
  if(!marker.rows.length) return res.json({ok:true,already_processed:true,week_start:weekStart,amount:WEEKLY_AMOUNT});

  try{
    const results = await db.transaction([
      {sql:"INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,0,NULL,false) ON CONFLICT (user_id) DO NOTHING",params:[String(bot.rows[0].user_id)]},
      {sql:"INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,0,NULL,false) ON CONFLICT (user_id) DO NOTHING",params:[String(alt.rows[0].user_id)]},
      {sql:"UPDATE gobux_accounts SET balance=balance+$1,updated_at=NOW() WHERE user_id=$2",params:[WEEKLY_AMOUNT,String(bot.rows[0].user_id)]},
      {sql:"UPDATE gobux_accounts SET balance=balance-$1,updated_at=NOW() WHERE user_id=$2 AND (gobux_infinite OR balance >= $1) RETURNING balance",params:[WEEKLY_AMOUNT,String(bot.rows[0].user_id)]},
      {sql:"UPDATE gobux_accounts SET balance=balance+$1,updated_at=NOW() WHERE user_id=$2",params:[WEEKLY_AMOUNT,String(alt.rows[0].user_id)]},
      {sql:"INSERT INTO gobux_game_purchases (transaction_id,buyer_user_id,recipient_user_id,amount) VALUES (gen_random_uuid()::text,$1,$2,$3)",params:[String(bot.rows[0].user_id),String(alt.rows[0].user_id),PURCHASE_PRICE]}
    ]);
    const debit=results.results[3]?.rows?.[0];
    if(!debit) throw new Error("Bot Gobux balance was insufficient after weekly grant.");
    res.json({ok:true,already_processed:false,week_start:weekStart,granted:WEEKLY_AMOUNT,spent:WEEKLY_AMOUNT,purchases:1,recipient:alt.rows[0].username,recipient_user_id:String(alt.rows[0].user_id)});
  }catch(e){
    await db.query("DELETE FROM gblocks_bot_weekly_runs WHERE week_start=$1",[weekStart]);
    return res.status(500).json({error:"Weekly GblocksBot Gobux cycle failed safely. No completed purchase cycle was recorded."});
  }
}