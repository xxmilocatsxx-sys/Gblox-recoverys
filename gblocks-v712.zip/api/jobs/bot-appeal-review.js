import { db } from "hatchable";
export const access="scheduler"; export const methods=["POST"];
const BOT="APP";
export default async function(req,res){
 const q=await db.query("SELECT * FROM moderation_appeals WHERE status='pending' ORDER BY created_at ASC LIMIT 50");
 let processed=0;
 for(const a of q.rows){
   // Bot Roblox performs a completeness review only: a substantive appeal is accepted;
   // an empty/near-empty submission is denied. The decision is logged.
   const text=String(a.appeal_text||"").trim();
   const accepted=text.length>=20;
   const decision=accepted?"accepted":"denied";
   const target=await db.query("SELECT user_id,username,moderation_status FROM gblocks_players WHERE user_id=$1 LIMIT 1",[a.user_id]);
   if(!target.rows[0]||!["banned","terminated"].includes(target.rows[0].moderation_status)){
     await db.query("UPDATE moderation_appeals SET status='closed',decision='closed',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",[BOT,a.id]); continue;
   }
   // Terminated accounts may submit an appeal, but a termination appeal is denied and the termination remains in place.
   if(target.rows[0].moderation_status==="terminated"){
     await db.transaction([
       {sql:"UPDATE moderation_appeals SET status='decided',decision='denied',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",params:[BOT,a.id]},
       {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6::jsonb)",params:["APPEAL_DENIED",a.user_id,target.rows[0].username,BOT,"Termination appeal denied; account remains permanently terminated.",JSON.stringify({appealId:a.id,permanent:true})]}
     ]);
     processed++; continue;
   }
   if(accepted){
     const until=new Date(Date.now()+86400000);
     await db.transaction([
       {sql:"UPDATE gblocks_players SET moderation_status='banned',temp_ban_until=$1,moderation_note=$2,last_ban_duration_days=1,moderation_last_action=NOW() WHERE user_id=$3",params:[until,"Appeal accepted by Bot Roblox.",a.user_id]},
       {sql:"UPDATE moderation_appeals SET status='decided',decision='accepted',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",params:[BOT,a.id]},
       {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6::jsonb)",params:["APPEAL_ACCEPTED",a.user_id,target.rows[0].username,BOT,"Appeal accepted; account placed on a 1-day ban.",JSON.stringify({appealId:a.id,unbanAt:until.toISOString()})]}
     ]);
   }else{
     await db.transaction([
       {sql:"UPDATE gblocks_players SET moderation_status='terminated',temp_ban_until=NULL,moderation_note=$1,verified=false,moderation_last_action=NOW() WHERE user_id=$2",params:["Appeal denied by Bot Roblox; account permanently terminated.",a.user_id]},
       {sql:"UPDATE moderation_appeals SET status='decided',decision='denied',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",params:[BOT,a.id]},
       {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6::jsonb)",params:["APPEAL_DENIED",a.user_id,target.rows[0].username,BOT,"Appeal denied; account permanently terminated.",JSON.stringify({appealId:a.id})]}
     ]);
   }
   processed++;
 }
 return res.json({ok:true,bot:BOT,checked:q.rows.length,processed});
}