import { db } from "hatchable";
import { refreshGroupVerification } from "../../lib/verification.js";

export const access = "scheduler";
export const methods = ["POST"];

export default async function(req, res) {
  const community = await db.query(
    "SELECT id FROM groups WHERE lower(name)=lower('Beta Testers') AND owner_id='1' ORDER BY created_at ASC LIMIT 1"
  );
  if (!community.rows[0]) return res.status(500).json({ error: "Beta Testers community is missing." });

  const groupId = String(community.rows[0].id);

  const eligible = await db.query(
    "SELECT p.user_id,p.role FROM profiles p LEFT JOIN premium_subscriptions ps ON ps.user_id=p.user_id AND ps.active=true AND (ps.is_permanent=true OR ps.expires_at>NOW()) WHERE p.role IN ('admin','administrator') OR ps.user_id IS NOT NULL"
  );

  let joined = 0;
  for (const row of eligible.rows) {
    const role = row.user_id === '1' ? 'owner' : (["admin","administrator"].includes(row.role) ? 'beta_testers_plus' : 'beta_testers');
    const r = await db.query(
      "INSERT INTO group_members (group_id,user_id,role) VALUES ($1,$2,$3) ON CONFLICT (group_id,user_id) DO UPDATE SET role=CASE WHEN group_members.role='owner' THEN 'owner' ELSE EXCLUDED.role END RETURNING user_id",
      [groupId,String(row.user_id),role]
    );
    if (r.rows[0]) joined++;
  }

  const removed = await db.query(
    "DELETE FROM group_members gm USING profiles p WHERE gm.group_id=$1 AND gm.user_id=p.user_id AND gm.user_id<>'1' AND p.role NOT IN ('admin','administrator') AND NOT EXISTS (SELECT 1 FROM premium_subscriptions ps WHERE ps.user_id=gm.user_id AND ps.active=true AND (ps.is_permanent=true OR ps.expires_at>NOW())) RETURNING gm.user_id",
    [groupId]
  );
  await refreshGroupVerification(groupId);

  return res.json({ ok:true, communityId:groupId, eligible:eligible.rows.length, synced:joined, removedExpired:removed.rows.length });
}