import { db } from "hatchable";
import { syncVerifiedRole } from "../../lib/discord.js";

export const access = "scheduler";
export const methods = ["POST"];

export default async function(req, res) {
  // Re-check the live profile badge for every active link. The helper removes the role
  // whenever the authoritative GBLOX profile is no longer eligible.
  const links = await db.query(
    "SELECT discord_user_id FROM gblox_discord_links WHERE revoked_at IS NULL ORDER BY linked_at ASC LIMIT 500"
  );
  const counts = { checked: 0, assigned: 0, not_eligible: 0, not_in_server: 0, not_configured: 0, failed: 0, unlinked: 0 };
  for (const row of links.rows) {
    const result = await syncVerifiedRole(row.discord_user_id);
    counts.checked++;
    if (Object.prototype.hasOwnProperty.call(counts, result.status)) counts[result.status]++;
    else counts.failed++;
  }
  return res.json({ ok: true, ...counts });
}