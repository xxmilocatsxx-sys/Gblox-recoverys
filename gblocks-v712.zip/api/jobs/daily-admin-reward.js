import { db } from "hatchable";
export const access="scheduler";
export const methods=["POST"];
export default async function(req,res){
  // access="scheduler" already restricts this route to the scheduler.

  // Administrators receive 500 Gobux once per day.
  const admins=await db.query("UPDATE gobux_accounts g SET balance=g.balance+500,updated_at=NOW(),last_daily_at=NOW() FROM profiles p WHERE p.user_id=g.user_id AND p.role='administrator' AND (p.daily_admin_reward_at IS NULL OR p.daily_admin_reward_at < date_trunc('day',NOW())) RETURNING g.user_id,g.balance");
  await db.query("UPDATE profiles SET daily_admin_reward_at=NOW() WHERE role='administrator' AND (daily_admin_reward_at IS NULL OR daily_admin_reward_at < date_trunc('day',NOW()))");

  // Players with the Creator Role receive 500 Gobux once per day.
  await db.query("INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) SELECT p.user_id,0,NULL,false FROM profiles p WHERE p.creator_role='creator' ON CONFLICT (user_id) DO NOTHING");
  const creators=await db.query("UPDATE gobux_accounts g SET balance=g.balance+500,updated_at=NOW(),last_daily_at=NOW() FROM profiles p WHERE p.user_id=g.user_id AND p.creator_role='creator' AND (p.daily_creator_reward_at IS NULL OR p.daily_creator_reward_at < date_trunc('day',NOW())) RETURNING g.user_id,g.balance");
  await db.query("UPDATE profiles SET daily_creator_reward_at=NOW() WHERE creator_role='creator' AND (daily_creator_reward_at IS NULL OR daily_creator_reward_at < date_trunc('day',NOW()))");

  res.json({ok:true,awarded:admins.rowCount||0,creator_awarded:creators.rowCount||0,amount:500});
}