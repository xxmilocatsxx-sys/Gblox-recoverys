import { db } from "hatchable";
import { accrueBotGobux } from "../../lib/bot-gobux-accrual.js";

export const access = "scheduler";
export const methods = ["POST"];

export default async function(req, res) {
  const settingsResult = await db.query("SELECT enabled,reward_amount FROM gobux_hourly_reward_settings WHERE id=1");
  const settings = settingsResult.rows[0];
  if (!settings) return res.status(503).json({ok:false,error:"Bot Gobux reward settings are not initialized."});
  if (!settings.enabled) return res.json({ok:true,enabled:false,accounts_processed:0,accounts_credited:0});

  const eligible = await db.query(
    "SELECT user_id,username FROM profiles WHERE banned=false AND terminated=false AND deactivated_at IS NULL AND (LOWER(username)='gblox' OR (role='bot' AND is_bot=true)) ORDER BY user_id"
  );
  let accountsCredited = 0;
  let totalTicks = 0;
  let totalAmount = 0n;
  for (const user of eligible.rows) {
    const result = await accrueBotGobux(user.user_id);
    if (result.credited) {
      accountsCredited += 1;
      totalTicks += result.ticks;
      totalAmount += BigInt(result.amount);
    }
  }
  return res.json({
    ok:true,
    enabled:true,
    reward_per_20_seconds:"50000000",
    accounts_processed:eligible.rows.length,
    accounts_credited:accountsCredited,
    reward_ticks_credited:totalTicks,
    total_gobux_credited:totalAmount.toString(),
    offline_accrual:true
  });
}