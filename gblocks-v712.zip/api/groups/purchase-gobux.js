import {db} from "hatchable";
export const access="public"; export const methods=["POST"];
const enc=new TextEncoder();const b64=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");async function h(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function c(req,n){const m=String(req.headers?.cookie||"").match(new RegExp("(?:^|;\\s*)"+n+"=([^;]*)"));return m?.[1]||null}
export default async function(req,res){
 const t=c(req,"gblocks_session")||c(req,"groblox_session");if(!t)return res.status(401).json({error:"Log in first."});
 const table=c(req,"gblocks_session")?"gblocks_sessions":"account_sessions";const u=(await db.query(`SELECT p.user_id,p.username,p.banned,p.terminated FROM ${table} s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1`,[await h(t)])).rows[0];if(!u||u.banned||u.terminated)return res.status(403).json({error:"Account unavailable."});
 const groupId=String(req.body?.group_id||""),amount=String(req.body?.amount||"");if(!groupId||!/^[0-9]+$/.test(amount)||amount==="0")return res.status(400).json({error:"Invalid group Gobux purchase."});
 const g=(await db.query("SELECT id,name FROM groups WHERE id=$1",[groupId])).rows[0];if(!g)return res.status(404).json({error:"Community not found."});
 const alt=(await db.query("SELECT user_id FROM profiles WHERE user_id=$1 LIMIT 1",["c66afd7c-03ea-42bc-b771-69b836f7049f"])).rows[0];if(!alt)return res.status(503).json({error:"Builder account not found."});
 const tx="GROUP-"+crypto.randomUUID();await db.query("INSERT INTO gobux_accounts(user_id,balance,gobux_infinite) VALUES($1,0,false) ON CONFLICT(user_id) DO NOTHING",[u.user_id]);
 const debit=await db.query("UPDATE gobux_accounts SET balance=CASE WHEN gobux_infinite THEN balance ELSE balance-$1::numeric END,updated_at=NOW() WHERE user_id=$2 AND (gobux_infinite=true OR balance >= $1::numeric) RETURNING balance,gobux_infinite",[amount,u.user_id]);if(!debit.rows.length)return res.status(402).json({error:"Not enough Gobux."});
 await db.query("INSERT INTO group_gobux_purchases(transaction_id,group_id,buyer_user_id,recipient_user_id,amount,status) VALUES($1,$2,$3,$4,$5,'pending')",[tx,groupId,u.user_id,alt.user_id,amount]);
 await db.query("INSERT INTO gobux_pending_credits(transaction_id,recipient_user_id,source_type,source_id,amount,available_at) VALUES($1,$2,'group_purchase',$3,$4,NOW()+INTERVAL '5 days')",[tx,alt.user_id,groupId,amount]);
 await db.query("INSERT INTO gobux_transactions(transaction_id,user_id,counterparty_user_id,amount,direction,source_type,status,pending_until) VALUES($1,$2,$3,$4,'debit','group_purchase','completed',NULL)",[tx,u.user_id,alt.user_id,amount]);
 await db.query("INSERT INTO gobux_transactions(transaction_id,user_id,counterparty_user_id,amount,direction,source_type,status,pending_until) VALUES($1,$2,$3,$4,'credit','group_purchase','pending',NOW()+INTERVAL '5 days')",[`PEND-${tx}`,alt.user_id,u.user_id,amount]);
 res.json({ok:true,transaction_id:tx,group:g.name,recipient:"Builder",amount,pending:true,pending_days:5});
}