import { db } from "hatchable";
export const access="public";
export const methods=["POST"];
const enc=new TextEncoder();
const b64=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function hash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function cookie(req,n){const m=String(req.headers?.cookie||"").match(new RegExp("(?:^|;\\s*)"+n+"=([^;]*)"));return m?decodeURIComponent(m[1]):null}
export default async function(req,res){
 const token=cookie(req,"gblocks_session")||cookie(req,"groblox_session");
 if(!token)return res.status(401).json({error:"Log in to collect gifts."});
 const th=await hash(token);
 let q=await db.query("SELECT p.user_id,p.username,p.banned,p.terminated,p.deactivated_at FROM gblocks_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[th]);
 if(!q.rows.length)q=await db.query("SELECT p.user_id,p.username,p.banned,p.terminated,p.deactivated_at FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[th]);
 const u=q.rows[0];
 if(!u)return res.status(401).json({error:"Session expired. Log in again."});
 if(u.banned||u.terminated||u.deactivated_at)return res.status(403).json({error:"This account cannot collect gifts."});
 const action=String(req.body?.action||"");
 const now=new Date();
 let type,period,amount;
 if(action==="daily"){type="daily";period=now.toISOString().slice(0,10);amount=5;}
 else if(action==="play_minute"){
   const gameId=String(req.body?.game_id||"").trim();
   if(!/^[0-9a-f-]{36}$/i.test(gameId))return res.status(400).json({error:"A valid game is required."});
   const game=await db.query("SELECT id FROM games WHERE id=$1 AND COALESCE(moderation_deleted,false)=false LIMIT 1",[gameId]);
   if(!game.rows.length)return res.status(404).json({error:"Game not found."});
   const recent=await db.query("SELECT 1 FROM gblocks_gift_reward_ledger WHERE user_id=$1 AND reward_type='play_minute' AND created_at>NOW()-INTERVAL '55 seconds' LIMIT 1",[String(u.user_id)]);
   if(recent.rows.length)return res.status(429).json({error:"A play-minute gift was already awarded recently."});
   type="play_minute";period=gameId+":"+Math.floor(Date.now()/60000);amount=1;
 } else return res.status(400).json({error:"Unknown gift reward."});
 await db.query("INSERT INTO gblocks_gift_wallets(user_id,balance) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING",[String(u.user_id)]);
 const tx=await db.query("INSERT INTO gblocks_gift_reward_ledger(user_id,reward_type,period_key,amount) VALUES($1,$2,$3,$4) ON CONFLICT(user_id,reward_type,period_key) DO NOTHING RETURNING id",[String(u.user_id),type,period,amount]);
 if(tx.rows.length)await db.query("UPDATE gblocks_gift_wallets SET balance=balance+$1,updated_at=NOW() WHERE user_id=$2",[amount,String(u.user_id)]);
 const wallet=await db.query("SELECT balance FROM gblocks_gift_wallets WHERE user_id=$1",[String(u.user_id)]);
 return res.json({ok:true,claimed:!!tx.rows.length,amount:tx.rows.length?amount:0,balance:Number(wallet.rows[0]?.balance||0),message:tx.rows.length?(type==="daily"?"You received 5 daily gifts!":"You earned 1 gift for a minute of play."):"This gift reward was already collected."});
}