import { db } from "hatchable";
export const access = "public";
export const methods = ["GET"];
export default async function (req, res) {
  const { rows } = await db.query(`SELECT g.id, g.name, g.description, g.players, g.icon, g.kit, g.game_data, g.created_at, g.updated_at, g.visits, g.creator_id,
    COALESCE(p.username, p.display_name, 'Unknown Creator') AS creator, COALESCE(p.verified,false) AS creator_verified
    FROM games g LEFT JOIN profiles p ON p.user_id = g.creator_id
    WHERE COALESCE(g.moderation_deleted,FALSE)=FALSE AND g.creator_id IS NOT NULL AND p.user_id IS NOT NULL
    ORDER BY g.created_at DESC`);
  res.json(rows);
}