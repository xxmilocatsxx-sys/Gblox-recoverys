import { db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

export default async function(req,res){
  try{
    const userId=String(req.query?.userid||"").trim();
    if(!userId) return res.status(400).json({error:"Missing userid."});
    const r=await db.query(
      "SELECT g.id,g.name,g.description,g.owner_id,g.created_at,g.is_private,g.verified,gm.role,COUNT(allm.user_id)::int AS member_count FROM group_members gm JOIN groups g ON g.id=gm.group_id LEFT JOIN group_members allm ON allm.group_id=g.id WHERE gm.user_id=$1 GROUP BY g.id,g.name,g.description,g.owner_id,g.created_at,g.is_private,g.verified,gm.role,gm.joined_at ORDER BY gm.joined_at DESC",
      [userId]
    );
    res.json({communities:r.rows});
  }catch(e){
    console.error("profile-communities error:",e);
    res.status(500).json({error:"Could not load communities."});
  }
}