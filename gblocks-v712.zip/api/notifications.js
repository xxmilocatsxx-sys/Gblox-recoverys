import { db } from "hatchable";
export const access="public";
export const methods=["GET","POST"];
const enc=new TextEncoder();
const b64=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
async function h(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function token(req){if(req.cookies?.groblox_session)return req.cookies.groblox_session;return String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1]||""}
async function me(req){const t=token(req);if(!t)return null;const r=await db.query("SELECT p.user_id FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await h(t)]);return r.rows[0]||null}
export default async function(req,res){
 const u=await me(req);if(!u)return res.status(401).json({error:"Log in first."});
 if(req.method==="POST"){await db.query("UPDATE gblocks_notifications SET read_at=NOW() WHERE user_id=$1 AND read_at IS NULL",[u.user_id]);return res.json({ok:true})}
 const q=await db.query("SELECT n.id,CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE n.actor_username END AS actor_username,n.type,CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL AND n.type='message' THEN 'New message — Account Deactivated' ELSE n.title END AS title,n.body,n.read_at,n.created_at FROM gblocks_notifications n LEFT JOIN profiles p ON p.user_id=n.actor_user_id LEFT JOIN gblocks_players gp ON gp.user_id=n.actor_user_id WHERE n.user_id=$1 ORDER BY n.created_at DESC LIMIT 100",[u.user_id]);
 const unread=q.rows.filter(x=>!x.read_at).length;res.json({notifications:q.rows,unread});
}