import { db } from "hatchable";
import { checkUsername } from "../lib/username-policy.js";
import { checkBio } from "../lib/moderation-policy.js";
const USERNAME_CHANGE_COST = 100;
export const access = "public";
export const methods = ["GET","POST"];
const enc=new TextEncoder();const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");async function tokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}function cookie(req){return String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1]||null}async function caller(req){const t=cookie(req);if(!t)return null;const q=await db.query("SELECT p.user_id,p.user_number,p.username,p.display_name,p.bio,p.avatar,p.verified,p.role,p.banned,p.terminated FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()",[await tokenHash(t)]);return q.rows[0]||null}
export default async function(req,res){
  const user=await caller(req);if(!user)return res.status(401).json({error:"Log in with your GBLOCKS username and password first."});
  if(user.terminated)return res.status(403).json({error:"This GBLOCKS account has been terminated."});
  if(user.banned)return res.status(403).json({error:"This GBLOCKS account is banned."});
  if(req.method==='GET')return res.json({signedIn:true,user:{user_number:user.user_number,username:user.username,display_name:user.display_name},profile:{user_number:user.user_number,username:user.username,display_name:user.display_name,bio:user.bio,avatar:user.avatar,verified:user.verified,role:user.role,banned:user.banned}});
  const username=req.body?.username===undefined?user.username:String(req.body.username).trim();
  if(!/^[A-Za-z0-9_]{3,24}$/.test(username))return res.status(400).json({error:'Username must be 3–24 characters and use only letters, numbers, and _.',code:'INVALID_USERNAME'});
  const changingUsername=username.toLowerCase()!==user.username.toLowerCase();
  if(changingUsername){
    const policy=checkUsername(username);
    const adminBrandName=username.toLowerCase()==='gblocks' && user.role==='administrator';
    if(policy.flagged && !adminBrandName)return res.status(400).json({error:policy.reason||'Username is reserved.',code:'USERNAME_RESERVED'});
    const taken=await db.query("SELECT user_id FROM profiles WHERE LOWER(username)=LOWER($1) AND user_id<>$2",[username,user.user_id]);
    if(taken.rows[0])return res.status(409).json({error:'That username is already taken.',code:'USERNAME_TAKEN'});
    const reserved=await db.query("SELECT reserved_for_user_id FROM username_reservations WHERE LOWER(username)=LOWER($1) LIMIT 1",[username]);
    if(reserved.rows[0] && String(reserved.rows[0].reserved_for_user_id)!==String(user.user_id))return res.status(409).json({error:'That username is reserved.',code:'USERNAME_RESERVED'});
  }
  const displayName=String(req.body?.display_name||user.display_name||username).trim().slice(0,40);
  const bio=String(req.body?.bio||'').trim().slice(0,160);
  const avatar=req.body?.avatar&&typeof req.body.avatar==='object'?req.body.avatar:{};
  let moderatedBio=bio;
  let bioDeleted=false;
  const localBioCheck=checkBio(bio);
  if(localBioCheck.flagged){ moderatedBio='[Content Deleted]'; bioDeleted=true; }
  if(changingUsername){
    const charge=await db.query("UPDATE gobux_accounts SET balance=balance-$1,updated_at=now() WHERE user_id=$2 AND balance>=$1 RETURNING balance",[USERNAME_CHANGE_COST,user.user_id]);
    if(!charge.rows[0]){const bal=await db.query("SELECT balance FROM gobux_accounts WHERE user_id=$1",[user.user_id]);return res.status(402).json({error:'You need '+USERNAME_CHANGE_COST+' Gobux to change your username.',code:'INSUFFICIENT_GOBUX',balance:Number(bal.rows[0]?.balance||0),cost:USERNAME_CHANGE_COST});}
    // Keep the old name permanently attached to this account so nobody else can claim it.
    await db.query("INSERT INTO username_reservations (username,reserved_for_user_id,reason) VALUES ($1,$2,$3) ON CONFLICT (username) DO UPDATE SET reserved_for_user_id=EXCLUDED.reserved_for_user_id",[user.username,user.user_id,'previous_username']);
    await db.query("INSERT INTO username_history (username,user_id) VALUES ($1,$2)",[user.username,user.user_id]);
  }
  await db.query("UPDATE profiles SET username=$1,display_name=$2,bio=$3,avatar=$4,bio_deleted_by_moderation=$5,bio_moderation_status=$6,bio_moderation_last_reviewed_at=NOW() WHERE user_id=$7",[username,displayName,moderatedBio,JSON.stringify(avatar),bioDeleted,bioDeleted?'content_deleted':'reviewed',user.user_id]);
  await db.query("UPDATE gblocks_players SET username=$1,bio=$2,bio_deleted_by_moderation=$3,avatar=$4::jsonb,gender=COALESCE($5,gender) WHERE user_id=$6",[username,moderatedBio,bioDeleted,JSON.stringify(avatar),avatar?.custom?.gender||avatar?.gender||null,user.user_id]);
  return res.json({ok:true,charged:changingUsername?USERNAME_CHANGE_COST:0,bio_deleted:bioDeleted,moderation_message:bioDeleted?'Your bio was removed for violating GBlocks content rules.':null,profile:{username,display_name:displayName,bio:moderatedBio,avatar}});
}