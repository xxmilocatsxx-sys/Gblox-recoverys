import { db } from "hatchable";
export const access="public";
export const methods=["GET"];
const catalog=[
 {key:"joined",name:"Welcome to GBlocks",description:"Created a GBlocks player account."},
 {key:"creator",name:"Creator",description:"Earned a Creator role on GBlocks."},
 {key:"verified",name:"Verified Player",description:"Reached GBlocks verification eligibility."},
 {key:"veteran",name:"GBlocks Veteran",description:"Your GBlocks account is at least 30 days old."},
 {key:"admin_257_year",name:"257 Year Account",description:"An administrator-only account-age achievement.",adminOnly:true},
 {key:"secret_gblox",name:"Secret Gblox",description:"A hidden GBLOX secret achievement.",secret:true},
 {key:"banned_by_moderator",name:"Banned By Moderator [ GBLOX ]",description:"You were online when a GBLOX moderator banned your account.",secret:true},
 {key:"banned_by_add_me_get_ban",name:"Add_Me_Get_Ban",description:"You were online when Add_Me_Get_Ban moderated your account.",secret:true}
];
export default async function(req,res){
 const id=String(req.query?.userid||req.query?.userId||"").trim();
 if(!id)return res.status(400).json({error:"userid is required"});
 const q=await db.query("SELECT user_id,username,role,created_at,creator_role,verified,deactivated_at FROM profiles WHERE user_id=$1 LIMIT 1",[id]);
 const p=q.rows[0];
 if(!p)return res.status(404).json({error:"Player not found."});
 if(p.deactivated_at)return res.json({achievements:[],deactivated:true});
 const earned=[];
 if(p.user_id)earned.push("joined");
 if(p.creator_role==="creator"||p.creator_role==="creator_alt")earned.push("creator");
 if(p.verified)earned.push("verified");
 if(p.created_at&&new Date(p.created_at).getTime()<=Date.now()-30*24*60*60*1000)earned.push("veteran");
 if(String(p.username||"").toLowerCase()==="gblox")earned.push("secret_gblox");
 if(["admin","administrator"].includes(String(p.role||"").toLowerCase())) { const adminYears=await db.query("SELECT achievement_key FROM gblocks_user_achievements WHERE user_id=$1 AND achievement_key LIKE 'admin_257_year_%'",[p.user_id]); }
 for(const key of earned)await db.query("INSERT INTO gblocks_user_achievements(user_id,achievement_key) VALUES($1,$2) ON CONFLICT(user_id,achievement_key) DO NOTHING",[p.user_id,key]);
 const rows=await db.query("SELECT achievement_key,unlocked_at FROM gblocks_user_achievements WHERE user_id=$1",[p.user_id]);
 const dates=new Map(rows.rows.map(x=>[x.achievement_key,x.unlocked_at]));
 const isAdmin=["admin","administrator"].includes(String(p.role||"").toLowerCase()); const hasAdminYear=Array.from(dates.keys()).some(k=>/^admin_257_year_\d{1,3}$/.test(k)); const achievements=catalog.filter(a=>(!a.secret||dates.has(a.key)||a.key==="secret_gblox"&&String(p.username||"").toLowerCase()==="gblox")&&(!a.adminOnly||isAdmin&&!hasAdminYear)).map(a=>({...a,earned:dates.has(a.key),unlocked_at:dates.get(a.key)||null}));
 for(const [key,unlocked_at] of dates) { const m=key.match(/^admin_257_year_(\d{1,3})$/); if(m) achievements.push({key,name:"257 Year Account",description:"Administrator-only account-age achievement.",years:Number(m[1]),adminOnly:true,earned:true,unlocked_at}); }
 return res.json({achievements});
}