import { db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

export default async function(req,res){
  const q=await db.query("SELECT beta_updates_completed,current_update_number,phase FROM gblocks_beta_release_cycle WHERE id=1");
  const r=q.rows[0]||{beta_updates_completed:0,current_update_number:1,phase:"beta"};
  return res.json({
    ok:true,
    updateNumber:Number(r.current_update_number),
    betaUpdatesCompleted:Number(r.beta_updates_completed),
    phase:r.phase,
    testerAudience:"Administrators and active Premium members",
    generalAudience:r.phase==="general" ? "All Gblocks users" : "After two beta-tested updates"
  });
}