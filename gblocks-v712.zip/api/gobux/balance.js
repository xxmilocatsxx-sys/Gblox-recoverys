import { db } from "hatchable";
import { accrueBotGobux } from "../../lib/bot-gobux-accrual.js";
export const access = "public";
export const methods = ["GET"];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function tokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function getCookie(req,name){const c=String(req.headers?.cookie||"");const m=c.match(new RegExp("(?:^|;\\s*)"+name+"=([^;]*)"));return m?m[1]:null}
export default async function(req,res){
  const raw=getCookie(req,"gblocks_session") || getCookie(req,"groblox_session");
  if(!raw)return res.status(401).json({signedIn:false,error:"Log in to view Gobux."});
  const th=await tokenHash(raw);
  const sessionTable=getCookie(req,"gblocks_session")?"gblocks_sessions":"account_sessions";
  const q=await db.query(`SELECT p.user_id,p.username,p.banned,p.terminated,p.role,p.is_bot,g.gobux_infinite,g.balance,ps.plan AS premium_plan,ps.weekly_amount AS premium_weekly_amount,ps.expires_at AS premium_expires_at,ps.active AS premium_active,ps.is_permanent AS premium_permanent FROM ${sessionTable} s JOIN profiles p ON p.user_id=s.user_id LEFT JOIN gobux_accounts g ON g.user_id=p.user_id LEFT JOIN premium_subscriptions ps ON ps.user_id=p.user_id AND ps.active=true WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1`,[th]);
  if(!q.rows[0])return res.status(401).json({signedIn:false,error:"Log in to view Gobux."});
  const u=q.rows[0];
  if(u.banned||u.terminated)return res.status(403).json({signedIn:false,error:"Account is not active."});
  const isRewardBot = String(u.username).toLowerCase()==="gblox" || (u.role==="bot" && u.is_bot===true);
  if (isRewardBot) {
    const settings = await db.query("SELECT enabled FROM gobux_hourly_reward_settings WHERE id=1");
    if (settings.rows[0]?.enabled) {
      await accrueBotGobux(u.user_id);
      const refreshed = await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1",[String(u.user_id)]);
      if (refreshed.rows[0]) { u.balance=refreshed.rows[0].balance; u.gobux_infinite=refreshed.rows[0].gobux_infinite; }
    }
  }
  return res.json({signedIn:true,username:u.username,infinite:Boolean(u.gobux_infinite),balance:u.gobux_infinite?"∞":Number(u.balance||0),premium:Boolean(u.premium_active && (u.premium_permanent || (u.premium_expires_at && new Date(u.premium_expires_at).getTime()>Date.now()))),premiumPlan:u.premium_active?u.premium_plan:null,premiumName:u.premium_active?(u.premium_plan==='500_years'?'Premium Plus':'Premium'):null,premiumWeeklyAmount:u.premium_active?Number(u.premium_weekly_amount||0):0,premiumExpiresAt:u.premium_active?u.premium_expires_at:null});
}