import {db} from "hatchable";
export const access="public";
export const methods=["GET"];
const enc=new TextEncoder();const b64=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
async function hash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function cookie(req,n){const c=String(req.headers?.cookie||"");const m=c.match(new RegExp("(?:^|;\\s*)"+n+"=([^;]*)"));return m?.[1]||null}
export default async function(req,res){
 const t=cookie(req,"gblocks_session")||cookie(req,"groblox_session");if(!t)return res.status(401).json({error:"Log in to view GBlocks transactions."});
 const table=cookie(req,"gblocks_session")?"gblocks_sessions":"account_sessions";
 const q=await db.query(`SELECT p.user_id,p.username FROM ${table} s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1`,[await hash(t)]);
 if(!q.rows[0])return res.status(401).json({error:"Session expired."});
 const uid=String(q.rows[0].user_id);
 const wallet=await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1",[uid]);
 const pending=await db.query("SELECT COALESCE(SUM(amount),0) AS pending FROM gobux_pending_credits WHERE recipient_user_id=$1 AND status='pending'",[uid]);
 const rows=await db.query("SELECT transaction_id,counterparty_user_id,amount,direction,source_type,status,pending_until,created_at FROM gobux_transactions WHERE user_id=$1 OR counterparty_user_id=$1 ORDER BY created_at DESC LIMIT 200",[uid]);
 res.json({username:q.rows[0].username,balance:wallet.rows[0]?.gobux_infinite?"∞":String(wallet.rows[0]?.balance||"0"),pending:String(pending.rows[0]?.pending||"0"),transactions:rows.rows});
}