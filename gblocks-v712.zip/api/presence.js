import { db } from "hatchable";
export const access="public"; export const methods=["GET","POST"];
const te=new TextEncoder(); const b64=b=>btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function hash(t){return b64(await crypto.subtle.digest("SHA-256",te.encode(t)))}
function token(req){let t=req.headers?.["x-gblocks-session"]||req.headers?.["X-Gblocks-Session"];if(t)return String(t);const a=req.headers?.authorization||req.headers?.Authorization;if(a&&/^Bearer\s+/i.test(String(a)))return String(a).replace(/^Bearer\s+/i,"").trim();const cookies=req.cookies||{};if(cookies.groblox_session)return String(cookies.groblox_session);if(cookies.gblocks_session)return String(cookies.gblocks_session);const raw=String(req.headers?.cookie||"");const m=raw.match(/(?:^|;\s*)(?:gblocks|groblox)_session=([^;]*)/i);return m?decodeURIComponent(m[1]):null}
export default async function(req,res){
 const t=token(req); if(!t)return res.status(401).json({error:"Not signed in."});
 const tokenHash=await hash(t);
 const q=await db.query("SELECT user_id FROM gblocks_sessions WHERE token_hash=$1 AND expires_at>NOW() UNION ALL SELECT user_id FROM account_sessions WHERE token_hash=$1 AND expires_at>NOW()",[tokenHash]);
 if(!q.rows[0])return res.status(401).json({error:"Not signed in."});
 const id=String(q.rows[0].user_id);
 if(req.method==="POST") await db.query("UPDATE profiles SET last_seen_at=NOW() WHERE user_id=$1",[id]);
 res.json({ok:true,online:true});
}