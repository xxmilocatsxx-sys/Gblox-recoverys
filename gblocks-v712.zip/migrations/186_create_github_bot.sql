INSERT INTO profiles (user_id, username, display_name, bio, avatar, verified, banned, terminated, role, user_number, always_online)
SELECT gen_random_uuid()::text, 'GitHub', 'GitHub', 'Gblocks automated bot account.', '{}'::jsonb, false, false, false, 'bot', COALESCE(MAX(user_number), 0) + 1, true
FROM profiles
WHERE NOT EXISTS (SELECT 1 FROM profiles WHERE username = 'GitHub')
RETURNING user_id;