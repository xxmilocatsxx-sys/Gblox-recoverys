CREATE TABLE IF NOT EXISTS gobux_transactions (
  transaction_id text PRIMARY KEY,
  user_id text NOT NULL,
  counterparty_user_id text,
  direction text NOT NULL,
  amount numeric(80,0) NOT NULL CHECK (amount > 0),
  source_type text NOT NULL,
  status text NOT NULL DEFAULT 'completed',
  pending_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
)