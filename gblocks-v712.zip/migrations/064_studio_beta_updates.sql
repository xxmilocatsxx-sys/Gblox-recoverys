CREATE TABLE IF NOT EXISTS gblocks_studio_beta_updates (
  release_number integer NOT NULL,
  user_id text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  PRIMARY KEY (release_number,user_id)
);