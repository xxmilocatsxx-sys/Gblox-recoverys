CREATE TABLE IF NOT EXISTS gobux_hourly_reward_settings (
  id smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled boolean NOT NULL DEFAULT true,
  reward_amount numeric NOT NULL DEFAULT 50000000 CHECK (reward_amount > 0),
  updated_by text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO gobux_hourly_reward_settings (id, enabled, reward_amount)
VALUES (1, true, 50000000)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS gobux_hourly_reward_runs (
  period_start timestamptz PRIMARY KEY,
  status text NOT NULL DEFAULT 'running',
  accounts_paid integer NOT NULL DEFAULT 0,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  note text NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS gobux_hourly_reward_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  username text NOT NULL,
  period_start timestamptz NOT NULL,
  amount numeric NOT NULL CHECK (amount > 0),
  status text NOT NULL DEFAULT 'pending',
  transaction_id text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  credited_at timestamptz,
  UNIQUE (user_id, period_start)
);

CREATE INDEX IF NOT EXISTS gobux_hourly_reward_ledger_period_idx
  ON gobux_hourly_reward_ledger (period_start, status);
CREATE INDEX IF NOT EXISTS gobux_hourly_reward_ledger_user_idx
  ON gobux_hourly_reward_ledger (user_id, period_start DESC);