-- Intentionally no-op in fresh forks: this legacy seed migration targeted
-- specific production accounts and a friend_requests table not present in
-- the fresh schema. User-specific relationships are not copied into forks.
SELECT 1;