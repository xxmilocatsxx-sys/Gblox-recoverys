CREATE TABLE IF NOT EXISTS game_visit_receipts (
  user_id text NOT NULL,
  game_id bigint NOT NULL,
  visited_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(user_id, game_id)
);
CREATE INDEX IF NOT EXISTS game_visit_receipts_recent_idx ON game_visit_receipts(game_id, visited_at DESC);
CREATE TABLE IF NOT EXISTS player_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id text NOT NULL,
  target_user_id text NOT NULL,
  reason text NOT NULL,
  details text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS player_reports_status_idx ON player_reports(status, created_at DESC);