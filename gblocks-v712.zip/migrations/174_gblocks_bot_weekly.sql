CREATE TABLE IF NOT EXISTS gblocks_bot_weekly_runs (
  week_start timestamptz PRIMARY KEY,
  amount integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
)