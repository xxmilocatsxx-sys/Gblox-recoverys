INSERT INTO groups (id,name,description,owner_id,is_private)
SELECT 'beta-testers', 'Beta Testers', 'A community for GBlocks Beta Testers+ — active Premium members and administrators.', '1', false
WHERE NOT EXISTS (
  SELECT 1 FROM groups WHERE lower(name)=lower('Beta Testers') AND owner_id='1'
);

INSERT INTO group_members (group_id,user_id,role)
SELECT g.id,'1','owner'
FROM groups g
WHERE lower(g.name)=lower('Beta Testers') AND g.owner_id='1'
ON CONFLICT (group_id,user_id) DO UPDATE SET role='owner';