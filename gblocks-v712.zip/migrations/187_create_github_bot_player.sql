INSERT INTO gblocks_players (user_id, username, display_name, bio, avatar, gobux, moderation_status, moderation_note)
SELECT p.user_id, p.username, p.display_name, p.bio, p.avatar, 100, 'active', ''
FROM profiles p
WHERE p.username = 'GitHub'
  AND p.role = 'bot'
  AND NOT EXISTS (SELECT 1 FROM gblocks_players gp WHERE gp.user_id = p.user_id)
RETURNING user_id;