-- Create the APP moderation bot account and give it administrator + verified badges.
INSERT INTO profiles (user_id,username,display_name,bio,avatar,verified,role,banned,terminated,user_number,always_online)
SELECT gen_random_uuid()::text,'APP','APP','Gblocks appeal moderation bot. Controls and reviews account appeals.','{}'::jsonb,true,'administrator',false,false,COALESCE((SELECT MAX(user_number) FROM profiles),0)+1,true
WHERE NOT EXISTS (SELECT 1 FROM profiles WHERE lower(username)=lower('APP'));

INSERT INTO gblocks_players (user_id,username,display_name,bio,avatar,gobux,moderation_status)
SELECT p.user_id,p.username,p.display_name,p.bio,p.avatar,0,'active'
FROM profiles p
WHERE lower(p.username)=lower('APP')
  AND NOT EXISTS (SELECT 1 FROM gblocks_players gp WHERE gp.user_id=p.user_id);