CREATE TABLE IF NOT EXISTS gblox_login_ip_history (
  user_id TEXT NOT NULL,
  ip_hash TEXT NOT NULL,
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, ip_hash)
);
CREATE INDEX IF NOT EXISTS gblox_login_ip_history_hash_idx ON gblox_login_ip_history(ip_hash, last_seen_at DESC);
CREATE TABLE IF NOT EXISTS gblox_ip_restrictions (
  ip_hash TEXT PRIMARY KEY,
  ip_label TEXT NOT NULL DEFAULT '',
  reason TEXT NOT NULL,
  created_by_user_id TEXT NOT NULL,
  created_by_username TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ NULL,
  revoked_at TIMESTAMPTZ NULL,
  revoked_by_user_id TEXT NULL
);
CREATE INDEX IF NOT EXISTS gblox_ip_restrictions_active_idx ON gblox_ip_restrictions(expires_at, revoked_at);
CREATE TABLE IF NOT EXISTS gblox_account_links (
  account_id TEXT NOT NULL,
  linked_account_id TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'admin_verified',
  created_by_user_id TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (account_id, linked_account_id),
  CHECK (account_id <> linked_account_id)
);
CREATE INDEX IF NOT EXISTS gblox_account_links_linked_idx ON gblox_account_links(linked_account_id);