CREATE TABLE IF NOT EXISTS gblocks_discord_webhooks (
 id BIGSERIAL PRIMARY KEY,
 name TEXT NOT NULL,
 webhook_url TEXT NOT NULL,
 events TEXT[] NOT NULL DEFAULT ARRAY['MODERATION ACTIONS']::TEXT[],
 enabled BOOLEAN NOT NULL DEFAULT TRUE,
 created_by TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS gblocks_discord_webhooks_enabled_idx ON gblocks_discord_webhooks (enabled);
CREATE TABLE IF NOT EXISTS gblocks_unban_counts (
 user_id TEXT PRIMARY KEY,
 unban_count INTEGER NOT NULL DEFAULT 0 CHECK (unban_count >= 0),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);