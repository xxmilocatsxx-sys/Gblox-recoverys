CREATE TABLE IF NOT EXISTS gobux_accounts (
  user_id text PRIMARY KEY,
  balance bigint NOT NULL DEFAULT 0,
  last_daily_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  gobux_infinite boolean NOT NULL DEFAULT false
);

CREATE TABLE IF NOT EXISTS gobux_game_purchases (
  transaction_id text PRIMARY KEY,
  buyer_user_id text NOT NULL,
  recipient_user_id text NOT NULL,
  amount bigint NOT NULL CHECK (amount = 10),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS gobux_game_purchases_buyer_idx
ON gobux_game_purchases (buyer_user_id, created_at DESC);

ALTER TABLE gobux_accounts
ADD CONSTRAINT gobux_accounts_balance_non_negative CHECK (balance >= 0);