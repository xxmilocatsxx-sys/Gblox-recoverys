UPDATE groups g
SET auto_verified = ((SELECT COUNT(*) FROM group_members gm WHERE gm.group_id = g.id) >= 10),
    verified = (g.manual_verified OR ((SELECT COUNT(*) FROM group_members gm WHERE gm.group_id = g.id) >= 10));