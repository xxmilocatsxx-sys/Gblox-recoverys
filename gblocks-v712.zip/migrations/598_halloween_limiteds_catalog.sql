CREATE TABLE IF NOT EXISTS gblox_catalog_event_items (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  cat TEXT NOT NULL DEFAULT 'Halloween Limiteds',
  price BIGINT NOT NULL CHECK (price >= 0),
  icon TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  event_key TEXT NOT NULL DEFAULT 'halloween-2026',
  sale_end_at TIMESTAMPTZ NOT NULL,
  is_on_sale BOOLEAN NOT NULL DEFAULT TRUE,
  stock_limit INTEGER,
  stock_sold INTEGER NOT NULL DEFAULT 0 CHECK (stock_sold >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (stock_limit IS NULL OR stock_limit >= 0)
);
CREATE INDEX IF NOT EXISTS gblox_catalog_event_items_sale_idx
  ON gblox_catalog_event_items (event_key, is_on_sale, sale_end_at);
INSERT INTO gblox_catalog_event_items (id,name,cat,price,icon,description,event_key,sale_end_at,is_on_sale)
VALUES ('halloween-headless','Halloween Headless','Halloween Limiteds',1000,'👻','An original ghostly headless-inspired avatar accessory.','halloween-2026','2026-10-31 19:00:00+00',TRUE)
ON CONFLICT (id) DO NOTHING;
INSERT INTO gblox_catalog_event_items (id,name,cat,price,icon,description,event_key,sale_end_at,is_on_sale)
VALUES ('pumpkin-head','Pumpkin Head','Halloween Limiteds',250,'🎃','A carved pumpkin avatar head with a warm spooky glow.','halloween-2026','2026-10-31 19:00:00+00',TRUE)
ON CONFLICT (id) DO NOTHING;
INSERT INTO gblox_catalog_event_items (id,name,cat,price,icon,description,event_key,sale_end_at,is_on_sale)
VALUES ('haunted-ghost-hood','Haunted Ghost Hood','Halloween Limiteds',350,'👻','A misty hood from the GBLOX haunted collection.','halloween-2026','2026-10-31 19:00:00+00',TRUE)
ON CONFLICT (id) DO NOTHING;
INSERT INTO gblox_catalog_event_items (id,name,cat,price,icon,description,event_key,sale_end_at,is_on_sale)
VALUES ('vampire-cape','Vampire Cape','Halloween Limiteds',400,'🦇','A dramatic midnight cape for a vampire-inspired look.','halloween-2026','2026-10-31 19:00:00+00',TRUE)
ON CONFLICT (id) DO NOTHING;
INSERT INTO gblox_catalog_event_items (id,name,cat,price,icon,description,event_key,sale_end_at,is_on_sale)
VALUES ('witch-hat','Witch Hat','Halloween Limiteds',200,'🧙','A classic crooked witch hat with neon trim.','halloween-2026','2026-10-31 19:00:00+00',TRUE)
ON CONFLICT (id) DO NOTHING;
INSERT INTO gblox_catalog_event_items (id,name,cat,price,icon,description,event_key,sale_end_at,is_on_sale)
VALUES ('spooky-bat-wings','Spooky Bat Wings','Halloween Limiteds',500,'🦇','A pair of shadowy bat wings for your avatar.','halloween-2026','2026-10-31 19:00:00+00',TRUE)
ON CONFLICT (id) DO NOTHING;
INSERT INTO gblox_catalog_event_items (id,name,cat,price,icon,description,event_key,sale_end_at,is_on_sale)
VALUES ('glowing-pumpkin-face','Glowing Pumpkin Face','Halloween Limiteds',300,'🎃','A bright pumpkin face with an eerie green-orange glow.','halloween-2026','2026-10-31 19:00:00+00',TRUE)
ON CONFLICT (id) DO NOTHING;
INSERT INTO gblox_catalog_event_items (id,name,cat,price,icon,description,event_key,sale_end_at,is_on_sale)
VALUES ('phantom-crown','Phantom Crown','Halloween Limiteds',750,'👑','A spectral crown forged for the Halloween night.','halloween-2026','2026-10-31 19:00:00+00',TRUE)
ON CONFLICT (id) DO NOTHING;