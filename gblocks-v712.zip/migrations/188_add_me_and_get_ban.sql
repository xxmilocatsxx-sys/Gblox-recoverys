INSERT INTO profiles (user_id, username, display_name, bio, avatar, verified, role, banned, terminated, user_number, always_online)
SELECT gen_random_uuid()::text, 'Add_me_and_get_Ban', 'Add_me_and_get_Ban', 'Gblocks bot: sending this account a friend request results in a temporary ban.', '{}'::jsonb, false, 'bot', false, false, COALESCE(MAX(user_number), 0) + 1, true
FROM profiles
WHERE NOT EXISTS (SELECT 1 FROM profiles WHERE LOWER(username)=LOWER('Add_me_and_get_Ban'))