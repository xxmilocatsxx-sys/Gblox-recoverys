ALTER TABLE profiles ADD COLUMN IF NOT EXISTS deactivated_at TIMESTAMPTZ;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS recovery_deadline TIMESTAMPTZ;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS legacy_status TEXT NOT NULL DEFAULT 'active';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS legacy_reviewed_at TIMESTAMPTZ;
ALTER TABLE gblocks_players ADD COLUMN IF NOT EXISTS recovery_deadline TIMESTAMPTZ;
ALTER TABLE gblocks_players ADD COLUMN IF NOT EXISTS reactivated_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS profiles_deactivation_recovery_idx ON profiles (deactivated_at, recovery_deadline, legacy_status);
CREATE INDEX IF NOT EXISTS gblocks_players_recovery_idx ON gblocks_players (deactivated_at, recovery_deadline, legacy_status);
CREATE TABLE IF NOT EXISTS gblocks_account_deactivation_history (
 id BIGSERIAL PRIMARY KEY,
 user_id TEXT NOT NULL,
 action TEXT NOT NULL CHECK (action IN ('deactivated','reactivated','legacy_reviewed')),
 username_snapshot TEXT NOT NULL DEFAULT '',
 display_name_snapshot TEXT NOT NULL DEFAULT '',
 deactivated_at TIMESTAMPTZ,
 recovery_deadline TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS gblocks_deactivation_history_user_idx ON gblocks_account_deactivation_history (user_id, created_at DESC);