CREATE TABLE gobux_earnings_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id text NOT NULL UNIQUE REFERENCES gobux_purchase_ledger(transaction_id),
  user_id text NOT NULL,
  gross_amount_cents integer NOT NULL,
  provider_fee_cents integer NOT NULL DEFAULT 0,
  net_amount_cents integer NOT NULL,
  currency text NOT NULL DEFAULT 'usd',
  status text NOT NULL DEFAULT 'awaiting_payout',
  payout_reference text,
  payout_note text,
  earned_at timestamptz NOT NULL DEFAULT now(),
  paid_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
)