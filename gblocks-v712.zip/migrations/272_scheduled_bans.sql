CREATE TABLE IF NOT EXISTS scheduled_bans (
  id BIGSERIAL PRIMARY KEY,
  target_user_id TEXT NOT NULL,
  target_username TEXT NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('banned','terminated')),
  reason TEXT NOT NULL DEFAULT '',
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NULL,
  duration_days INTEGER NOT NULL DEFAULT 0,
  created_by_user_id TEXT NOT NULL,
  created_by_username TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled','applied','cancelled','failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  applied_at TIMESTAMPTZ NULL
);
CREATE INDEX IF NOT EXISTS scheduled_bans_due_idx ON scheduled_bans(status, starts_at);