CREATE OR REPLACE FUNCTION gblocks_auto_ban_at_three_moderations()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF OLD.moderation_violation_count < 3
     AND NEW.moderation_violation_count >= 3
     AND NEW.banned = false
     AND NEW.terminated = false THEN
    NEW.banned := true;
    NEW.temp_ban_until := NOW() + INTERVAL '3 days';
    NEW.last_ban_duration_days := 3;
    NEW.ban_note := CASE
      WHEN COALESCE(NEW.ban_note, '') <> '' THEN NEW.ban_note
      ELSE 'Automatic ban: account reached 3 moderation violations.'
    END;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE TRIGGER profiles_auto_ban_at_three_moderations
BEFORE UPDATE OF moderation_violation_count ON profiles
FOR EACH ROW
EXECUTE FUNCTION gblocks_auto_ban_at_three_moderations();