CREATE TABLE IF NOT EXISTS gblox_discord_links (
  discord_user_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL UNIQUE,
  discord_username TEXT NOT NULL DEFAULT '',
  verified_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  linked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  role_status TEXT NOT NULL DEFAULT 'not_configured',
  role_error TEXT,
  revoked_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS gblox_discord_links_user_idx ON gblox_discord_links(user_id);
CREATE TABLE IF NOT EXISTS gblox_discord_oauth_states (
  state_hash TEXT PRIMARY KEY,
  mode TEXT NOT NULL CHECK (mode IN ('signup','login','link')),
  user_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS gblox_discord_pending (
  ticket_hash TEXT PRIMARY KEY,
  discord_user_id TEXT NOT NULL,
  discord_username TEXT NOT NULL DEFAULT '',
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS gblox_discord_pending_identity_idx ON gblox_discord_pending(discord_user_id);
CREATE TABLE IF NOT EXISTS gblox_signup_rate_limits (
  id BIGSERIAL PRIMARY KEY,
  ip_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS gblox_signup_rate_limits_ip_created_idx ON gblox_signup_rate_limits(ip_hash, created_at);