CREATE TABLE IF NOT EXISTS restricted_admin_badges (
  username_key text PRIMARY KEY,
  username text NOT NULL,
  badge_name text NOT NULL DEFAULT 'Restricted Admin',
  badge_icon text NOT NULL DEFAULT '⚠️',
  applied_by text,
  applied_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS restricted_admin_badges_username_idx ON restricted_admin_badges (username_key);
INSERT INTO restricted_admin_badges (username_key,username,badge_name,badge_icon,applied_by)
VALUES ('tubers93','tubers93','Restricted Admin','⚠️','system')
ON CONFLICT (username_key) DO NOTHING;