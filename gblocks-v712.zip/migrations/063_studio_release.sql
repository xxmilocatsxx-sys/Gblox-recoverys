CREATE TABLE IF NOT EXISTS gblocks_studio_release (
  id integer PRIMARY KEY DEFAULT 1,
  released boolean NOT NULL DEFAULT false,
  phase text NOT NULL DEFAULT 'development',
  release_number integer NOT NULL DEFAULT 0,
  beta_update_count integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT NOW()
);

INSERT INTO gblocks_studio_release (id,released,phase,release_number,beta_update_count)
VALUES (1,false,'development',0,0)
ON CONFLICT (id) DO NOTHING;