INSERT INTO gblocks_players (user_id,username,display_name,bio,avatar,gobux,moderation_status)
SELECT p.user_id,p.username,p.display_name,p.bio,p.avatar,0,'active'
FROM profiles p
WHERE lower(p.username)=lower('GblocksBot')
  AND NOT EXISTS (SELECT 1 FROM gblocks_players gp WHERE gp.user_id=p.user_id)