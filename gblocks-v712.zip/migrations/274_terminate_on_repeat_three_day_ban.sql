CREATE OR REPLACE FUNCTION gblocks_terminate_on_repeat_three_day_ban()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF OLD.moderation_status = 'banned'
     AND COALESCE(OLD.last_ban_duration_days, 0) = 3
     AND NEW.moderation_status = 'banned' THEN
    NEW.moderation_status := 'terminated';
    NEW.temp_ban_until := NULL;
    NEW.moderation_note := CASE
      WHEN COALESCE(NEW.moderation_note, '') <> '' THEN NEW.moderation_note || ' | Account terminated after receiving another 3-day ban.'
      ELSE 'Account terminated after receiving another 3-day ban.'
    END;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS gblocks_terminate_on_repeat_three_day_ban ON gblocks_players;

CREATE TRIGGER gblocks_terminate_on_repeat_three_day_ban
BEFORE UPDATE OF moderation_status, last_ban_duration_days ON gblocks_players
FOR EACH ROW
EXECUTE FUNCTION gblocks_terminate_on_repeat_three_day_ban();