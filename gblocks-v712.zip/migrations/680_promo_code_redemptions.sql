CREATE TABLE IF NOT EXISTS promo_code_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  code_key text NOT NULL,
  code_label text NOT NULL,
  reward_amount numeric(40,0) NOT NULL CHECK (reward_amount >= 0),
  redeemed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, code_key)
);
CREATE INDEX IF NOT EXISTS promo_code_redemptions_user_time_idx ON promo_code_redemptions (user_id, redeemed_at DESC);