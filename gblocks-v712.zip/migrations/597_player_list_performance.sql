-- Speed up the public player list's active-account filter and oldest-first ordering.
CREATE INDEX IF NOT EXISTS gblocks_players_active_created_user_idx
ON gblocks_players (moderation_status, created_at, user_id);

-- Keep the profile join efficient when listing player badges and presence.
CREATE INDEX IF NOT EXISTS profiles_user_id_player_list_idx
ON profiles (user_id)
INCLUDE (verified, role, creator_role, last_seen_at, always_online);