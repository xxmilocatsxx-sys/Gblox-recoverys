CREATE TABLE IF NOT EXISTS moderation_appeals (
  id BIGSERIAL PRIMARY KEY,
  user_id TEXT NOT NULL,
  username TEXT NOT NULL,
  ban_reason TEXT NOT NULL DEFAULT '',
  appeal_text TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  decision TEXT,
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS moderation_appeals_user_idx ON moderation_appeals(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS moderation_appeals_pending_idx ON moderation_appeals(status,created_at);