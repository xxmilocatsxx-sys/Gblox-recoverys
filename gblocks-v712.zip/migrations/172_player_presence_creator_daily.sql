ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_seen_at TIMESTAMPTZ;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS creator_role TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS daily_admin_reward_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS profiles_last_seen_idx ON profiles(last_seen_at);