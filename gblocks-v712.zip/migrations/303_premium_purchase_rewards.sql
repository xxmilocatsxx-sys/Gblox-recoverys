CREATE TABLE IF NOT EXISTS premium_purchase_rewards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id BIGINT NOT NULL UNIQUE REFERENCES premium_subscriptions(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  reward_amount BIGINT NOT NULL CHECK (reward_amount > 0),
  transaction_id TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS premium_purchase_rewards_user_idx
ON premium_purchase_rewards(user_id, created_at DESC);