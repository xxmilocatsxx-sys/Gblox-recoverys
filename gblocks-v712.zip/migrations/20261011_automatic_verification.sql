ALTER TABLE profiles ADD COLUMN IF NOT EXISTS auto_verified boolean NOT NULL DEFAULT false;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS manual_verified boolean NOT NULL DEFAULT false;
ALTER TABLE groups ADD COLUMN IF NOT EXISTS auto_verified boolean NOT NULL DEFAULT false;
ALTER TABLE groups ADD COLUMN IF NOT EXISTS manual_verified boolean NOT NULL DEFAULT false;

UPDATE profiles p
SET auto_verified = (NOT p.banned AND NOT p.terminated AND ((SELECT COUNT(*) FROM follows f WHERE f.following_id=p.user_id) + COALESCE(p.follower_bonus,0)) >= 500),
    manual_verified = p.verified,
    verified = p.verified OR (NOT p.banned AND NOT p.terminated AND ((SELECT COUNT(*) FROM follows f WHERE f.following_id=p.user_id) + COALESCE(p.follower_bonus,0)) >= 500);

UPDATE groups g
SET auto_verified = ((SELECT COUNT(*) FROM group_members gm WHERE gm.group_id=g.id) >= 20),
    manual_verified = g.verified,
    verified = g.verified OR ((SELECT COUNT(*) FROM group_members gm WHERE gm.group_id=g.id) >= 20);